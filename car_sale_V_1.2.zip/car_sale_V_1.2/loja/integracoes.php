<?php
require_once __DIR__ . '/../config/bootstrap.php';
exigirPerfil('lojista');

$user_id = $_SESSION['user_id'];
$erro = "";
$sucesso = "";

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $standId = trim($_POST['standvirtual_stand_id'] ?? '');
    $token   = trim($_POST['standvirtual_api_token'] ?? '');

    $pdo->prepare("UPDATE utilizadores SET standvirtual_stand_id = ?, standvirtual_api_token = ? WHERE id = ?")
        ->execute([$standId ?: null, $token ?: null, $user_id]);

    $sucesso = "Credenciais guardadas.";
}

$stmt = $pdo->prepare("SELECT standvirtual_stand_id, standvirtual_api_token FROM utilizadores WHERE id = ?");
$stmt->execute([$user_id]);
$loja = $stmt->fetch(PDO::FETCH_ASSOC);

require BASE_PATH . '/includes/header.php';
?>

<div class="register-container">
    <h2>Divulgação externa — Standvirtual / OLX</h2>

    <p class="lojista-fields-nota">
        O ID do stand e o token de API são fornecidos pela Standvirtual depois de
        contratares um <a href="https://profissionais.standvirtual.com/" target="_blank" rel="noopener">plano profissional</a>
        (secção "Integração de anúncios via API"). Publicar na Standvirtual publica
        automaticamente também no OLX — não é preciso configurar nada em separado
        para o OLX.
    </p>

    <?php if (!empty($erro)): ?><p class="erro"><?= htmlspecialchars($erro) ?></p><?php endif; ?>
    <?php if (!empty($sucesso)): ?><p class="sucesso"><?= htmlspecialchars($sucesso) ?></p><?php endif; ?>

    <form method="POST" action="<?= BASE_URL ?>/loja/integracoes.php" class="register-form">
        <input type="text" name="standvirtual_stand_id" placeholder="ID do stand na Standvirtual"
               value="<?= htmlspecialchars($loja['standvirtual_stand_id'] ?? '') ?>">

        <input type="text" name="standvirtual_api_token" placeholder="Token de API da Standvirtual"
               value="<?= htmlspecialchars($loja['standvirtual_api_token'] ?? '') ?>">

        <button type="submit">Guardar</button>
    </form>
</div>

<?php require BASE_PATH . '/includes/footer.php'; ?>
