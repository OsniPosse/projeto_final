/*
|--------------------------------------------------------------------------
| Car Sale AI
|--------------------------------------------------------------------------
*/
console.log("BASE_URL =", BASE_URL);

document.addEventListener("DOMContentLoaded", () => {

    const btnTitulo = document.getElementById("btnGerarTitulo");
    const btnDescricao = document.getElementById("btnGerarDescricao");

    /*
    |--------------------------------------------------------------------------
    | Gerar título
    |--------------------------------------------------------------------------
    */

    if (btnTitulo) {

        btnTitulo.addEventListener("click", gerarTitulo);

    }

    /*
    |--------------------------------------------------------------------------
    | Gerar descrição
    |--------------------------------------------------------------------------
    */

    if (btnDescricao) {

        btnDescricao.addEventListener("click", gerarDescricao);

    }

});

/*
|--------------------------------------------------------------------------
| Ler formulário
|--------------------------------------------------------------------------
*/

function obterDadosFormulario() {

    return {

        tipo_veiculo: valor("selectTipo"),

        marca: valor("selectMarca"),

        modelo: valor("inputModelo"),

        ano: valor("ano"),

        quilometragem: valor("quilometragem"),

        combustivel: valor("combustivel"),

        estado: valor("estado")

    };

}

/*
|--------------------------------------------------------------------------
| Gerar título
|--------------------------------------------------------------------------
*/

async function gerarTitulo() {

    const botao = document.getElementById("btnGerarTitulo");

    botao.disabled = true;

    botao.innerText = "A gerar...";

    try {

        const resposta = await fetch(BASE_URL + "/App/api/generate_title.php", {

            method: "POST",

            headers: {

                "Content-Type": "application/json"

            },

            body: JSON.stringify(

                obterDadosFormulario()

            )

        });

        const json = await resposta.json();

        if (!json.ok) {

            alert(json.erro);

            return;

        }

        document.getElementById("titulo").value =

            json.texto ?? "";

    }

    catch (e) {

        alert(e.message);

    }

    finally {

        botao.disabled = false;

        botao.innerText = "Gerar Título";

    }

}

/*
|--------------------------------------------------------------------------
| Gerar descrição
|--------------------------------------------------------------------------
*/

async function gerarDescricao() {

    const botao = document.getElementById("btnGerarDescricao");

    botao.disabled = true;

    botao.innerText = "A gerar...";

    try {

        const resposta = await fetch(BASE_URL + "/App/api/generate_description.php", {

            method: "POST",

            headers: {

                "Content-Type": "application/json"

            },

            body: JSON.stringify(

                obterDadosFormulario()

            )

        });

        const json = await resposta.json();

        if (!json.ok) {

            alert(json.erro);

            return;

        }

        document.getElementById("descricao").value =

            json.descricao ?? json.texto;

    }

    catch (e) {

        alert(e.message);

    }

    finally {

        botao.disabled = false;

        botao.innerText = "Gerar Descrição";

    }

}

/*
|--------------------------------------------------------------------------
| Auxiliar
|--------------------------------------------------------------------------
*/

function valor(id) {

    const campo = document.getElementById(id);

    if (!campo) {

        return "";

    }

    return campo.value;

}