<?php

declare(strict_types=1);



class Gemini
{
    private string $apiKey;
    private string $model;
    private string $endpoint;

    public function __construct()
    {
        $config = require BASE_PATH . '/config/ai.php';

        $this->apiKey = $config['api_key'] ?? '';
        $this->model = $config['model'] ?? 'gemini-3.1-flash-lite';

        $this->endpoint =
            "https://generativelanguage.googleapis.com/v1beta/models/" .
            $this->model .
            ":generateContent?key=" .
            $this->apiKey;
    }

    /**
     * Envia um pedido ao Gemini.
     */
    public function generate(string $prompt, array $images = []): array
    {
        if (empty($this->apiKey)) {
            return [
                'ok' => false,
                'erro' => 'A chave GEMINI_API_KEY não está configurada.'
            ];
        }

        $parts = [];

        $parts[] = [
            'text' => $prompt
        ];

        foreach ($images as $image) {

            if (
                empty($image['data']) ||
                empty($image['media_type'])
            ) {
                continue;
            }

            $parts[] = [

                "inline_data" => [

                    "mime_type" => $image['media_type'],

                    "data" => $image['data']

                ]

            ];
        }

        $payload = [

            "contents" => [

                [

                    "parts" => $parts

                ]

            ]

        ];

        $ch = curl_init($this->endpoint);

        curl_setopt_array($ch, [

            CURLOPT_POST => true,

            CURLOPT_RETURNTRANSFER => true,

            CURLOPT_HTTPHEADER => [

                'Content-Type: application/json'

            ],

            CURLOPT_POSTFIELDS => json_encode($payload),

            CURLOPT_TIMEOUT => 60

        ]);

        $response = curl_exec($ch);

        $http = curl_getinfo($ch, CURLINFO_HTTP_CODE);

        $error = curl_error($ch);

        curl_close($ch);

        if ($response === false) {

            return [

                'ok' => false,

                'erro' => $error

            ];

        }

        $json = json_decode($response, true);

        if ($http != 200) {

            return [

                'ok' => false,

                'erro' => $json['error']['message'] ?? 'Erro desconhecido.'

            ];

        }

        $text = $json['candidates'][0]['content']['parts'][0]['text'] ?? '';

        if ($text == '') {

            return [

                'ok' => false,

                'erro' => 'O Gemini não devolveu qualquer resposta.'

            ];

        }

        return [

            'ok' => true,

            'texto' => trim($text)

        ];
    }

    /**
     * Gera descrição do anúncio.
     */
    public function gerarDescricao(array $dados, array $imagens = []): array
    {

        $prompt = "

Escreve uma descrição profissional para um anúncio automóvel.

Idioma: Português de Portugal.

Dados:

Marca: {$dados['marca']}

Modelo: {$dados['modelo']}

Ano: {$dados['ano']}

Quilómetros: {$dados['quilometragem']}

Combustível: {$dados['combustivel']}

Estado: {$dados['estado']}

Regras:

- Entre 60 e 100 palavras.
- Não inventes equipamento.
- Não inventes histórico.
- Linguagem comercial.
- Apenas devolve a descrição.

";

        return $this->generate($prompt, $imagens);

    }

    /**
     * Gera um título.
     */
    public function gerarTitulo(array $dados): array
    {

        $prompt = "

Cria um título apelativo para um anúncio automóvel.

Marca:

{$dados['marca']}

Modelo:

{$dados['modelo']}

Ano:

{$dados['ano']}

Potência:

{$dados['potencia']}

Combustível:

{$dados['combustivel']}

Máximo 70 caracteres.

";

        return $this->generate($prompt);

    }

    /**
     * Sugere um preço.
     */
    public function sugerirPreco(array $dados): array
    {

        $prompt = "

Indica um preço estimado para este veículo.

Marca:

{$dados['marca']}

Modelo:

{$dados['modelo']}

Ano:

{$dados['ano']}

Quilómetros:

{$dados['quilometragem']}

Combustível:

{$dados['combustivel']}

Responde apenas com um valor aproximado em euros.

";

        return $this->generate($prompt);

    }

    /**
     * Analisa fotografias.
     */
    public function analisarFotos(array $imagens): array
    {

        $prompt = "

Analisa as fotografias do veículo.

Indica:

- estado geral

- danos visíveis

- qualidade das fotos

- qual deverá ser a foto principal

";

        return $this->generate($prompt, $imagens);

    }

}