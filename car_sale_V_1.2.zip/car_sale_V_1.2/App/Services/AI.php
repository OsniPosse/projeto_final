<?php

require_once BASE_PATH . '/App/Services/Gemini.php';

class AI
{
    private Gemini $gemini;

    public function __construct()
    {
        $this->gemini = new Gemini();
    }

    public function gerarDescricao(array $dados, array $imagens = []): array
    {
        return $this->gemini->gerarDescricao($dados, $imagens);
    }

    public function gerarTitulo(array $dados): array
    {
        return $this->gemini->gerarTitulo($dados);
    }

    public function sugerirPreco(array $dados): array
    {
        return $this->gemini->sugerirPreco($dados);
    }

    public function analisarFotos(array $imagens): array
    {
        return $this->gemini->analisarFotos($imagens);
    }
}