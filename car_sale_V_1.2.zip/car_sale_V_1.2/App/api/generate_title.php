<?php

declare(strict_types=1);

require_once __DIR__ . '/../../config/bootstrap.php';
require_once BASE_PATH . '/App/Services/Gemini.php';
require_once BASE_PATH . '/App/Services/AI.php';

header('Content-Type: application/json; charset=utf-8');

/*
|--------------------------------------------------------------------------
| Verificar autenticação
|--------------------------------------------------------------------------
*/

if (!estaLogado()) {

    http_response_code(401);

    echo json_encode([
        'ok'   => false,
        'erro' => 'Precisas de iniciar sessão.'
    ]);

    exit;
}

/*
|--------------------------------------------------------------------------
| Apenas POST
|--------------------------------------------------------------------------
*/

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {

    http_response_code(405);

    echo json_encode([
        'ok'   => false,
        'erro' => 'Método inválido.'
    ]);

    exit;
}

/*
|--------------------------------------------------------------------------
| Receber JSON
|--------------------------------------------------------------------------
*/

$input = json_decode(file_get_contents('php://input'), true);

if (!is_array($input)) {

    echo json_encode([
        'ok'   => false,
        'erro' => 'Dados inválidos.'
    ]);

    exit;
}

/*
|--------------------------------------------------------------------------
| Validar campos obrigatórios
|--------------------------------------------------------------------------
*/

$campos = [
    'marca',
    'modelo',
    'ano'
];

foreach ($campos as $campo) {

    if (empty($input[$campo])) {

        echo json_encode([
            'ok'   => false,
            'erro' => "O campo '{$campo}' é obrigatório."
        ]);

        exit;
    }
}

/*
|--------------------------------------------------------------------------
| Preparar dados
|--------------------------------------------------------------------------
*/

$dados = [

    'marca' => trim($input['marca']),

    'modelo' => trim($input['modelo']),

    'ano' => trim($input['ano']),

    'potencia' => trim($input['potencia'] ?? ''),

    'combustivel' => trim($input['combustivel'] ?? ''),

    'versao' => trim($input['versao'] ?? '')

];

/*
|--------------------------------------------------------------------------
| Gerar título
|--------------------------------------------------------------------------
*/

try {

    $ai = new AI();

    $resultado = $ai->gerarTitulo($dados);

    echo json_encode($resultado);

} catch (Throwable $e) {

    http_response_code(500);

    echo json_encode([

        'ok'   => false,

        'erro' => $e->getMessage()

    ]);

}