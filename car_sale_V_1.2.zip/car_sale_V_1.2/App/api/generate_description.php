<?php

declare(strict_types=1);

require_once __DIR__ . '/../../config/bootstrap.php';
require_once BASE_PATH . '/App/Services/Gemini.php';
require_once BASE_PATH . '/App/Services/AI.php';

header('Content-Type: application/json; charset=utf-8');

if (!estaLogado()) {
    http_response_code(401);

    echo json_encode([
        'ok'   => false,
        'erro' => 'Precisas de estar autenticado.'
    ]);

    exit;
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {

    http_response_code(405);

    echo json_encode([
        'ok'   => false,
        'erro' => 'Método não permitido.'
    ]);

    exit;
}

$input = json_decode(file_get_contents('php://input'), true);

if (!$input) {

    echo json_encode([
        'ok'   => false,
        'erro' => 'Nenhum dado recebido.'
    ]);

    exit;
}

$dados = [

    'tipo_veiculo' => $input['tipo_veiculo'] ?? 'carro',

    'marca' => trim($input['marca'] ?? ''),

    'modelo' => trim($input['modelo'] ?? ''),

    'ano' => trim($input['ano'] ?? ''),

    'quilometragem' => trim($input['quilometragem'] ?? ''),

    'combustivel' => trim($input['combustivel'] ?? ''),

    'estado' => trim($input['estado'] ?? ''),

];

$imagens = $input['imagens'] ?? [];

try {

    $ai = new AI();

    $resultado = $ai->gerarDescricao($dados, $imagens);

    echo json_encode($resultado);

} catch (Throwable $e) {

    http_response_code(500);

    echo json_encode([

        'ok' => false,

        'erro' => $e->getMessage()

    ]);

}