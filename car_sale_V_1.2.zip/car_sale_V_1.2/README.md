# AutoMarket — car_sale

## O que mudou nesta reorganização

1. **Estrutura em pastas** por responsabilidade: `auth/`, `anuncios/`, `loja/`,
   `config/`, `includes/`, `includes/sync/`, `cron/`.
2. **`config/bootstrap.php`** central — substitui os vários `require "conexao.php"`
   espalhados pelo código. Define `BASE_PATH` (caminho no disco), `BASE_URL`
   (caminho na URL) e liga `$pdo`.
3. **`includes/auth_guard.php`** — substitui o bloco repetido
   `if (!isset($_SESSION["user_id"])) { ... }` por `exigirLogin()` e
   `exigirPerfil(...)`.
4. **Credenciais fora do código**: SMTP e Google OAuth passaram a vir de um
   ficheiro `.env` (ver `.env.example`), que não deve ir para o Git.
5. **Login com Google OAuth 2.0** (`auth/google_login.php` +
   `auth/google_callback.php`), implementado só com cURL, sem dependências.
6. **Divulgação externa (Standvirtual/OLX)** — módulo novo em `includes/sync/`.

## Instalação

1. `composer`/npm não são necessários — é PHP puro.
2. Importa `car_sale_v1.sql` numa base de dados MySQL/MariaDB nova.
   (Se já tinhas a BD antiga, corre antes o `migracoes.sql`.)
3. Copia `.env.example` para `.env` e preenche:
   - Credenciais da base de dados.
   - SMTP (para o email de verificação de conta).
   - `GOOGLE_CLIENT_ID` / `GOOGLE_CLIENT_SECRET` — cria-os em
     https://console.cloud.google.com/apis/credentials (tipo "Aplicação Web").
     Em "URIs de redirecionamento autorizados" usa exatamente o valor de
     `GOOGLE_REDIRECT_URI`.
4. Aponta o servidor web (Apache/PHP built-in) para a pasta do projeto.
   Com o servidor de desenvolvimento do PHP, por exemplo:
   ```
   php -S localhost:8000
   ```

## Divulgação externa (Standvirtual / OLX)

- A Standvirtual só dá acesso à sua API a **contas profissionais** (stands)
  com plano contratado — não existe um endpoint público. Depois de
  contratares, define `STANDVIRTUAL_API_URL` no `.env` e ajusta o payload em
  `includes/sync/StandvirtualProvider.php` conforme a documentação que eles
  te enviarem.
- Publicar na Standvirtual já publica automaticamente no OLX (mesmo grupo
  empresarial) — normalmente **não precisas de configurar o OLX em separado**.
  A opção OLX fica pronta no código apenas para o caso de vires a ter uma
  API OLX independente no futuro.
- Cada lojista guarda o seu próprio ID de stand + token em
  **A minha loja → Divulgação externa** (`loja/integracoes.php`).
- O botão "Divulgar" em `anuncios/meus_anuncios.php` (só visível para contas
  `lojista`) leva a `anuncios/divulgar.php`, onde se escolhe a plataforma,
  se paga (checkout simulado — ainda sem gateway real ligada) e se tenta a
  publicação de imediato.
- `cron/publicar_pendentes.php` pode ser agendado (crontab) para tentar de
  novo publicações que ficaram pendentes ou que falharam, sem cobrar outra
  vez ao lojista.

## Categorias e filtros (inspirado no auto.pt)

- **3 tipos de veículo**: `carro`, `mota`, `pesado` — cada um com campos próprios
  (cilindrada para motas; capacidade de carga + nº de eixos para pesados).
- **Marca → Modelo em cascata**, definidos em `config/veiculos_taxonomia.php`
  (não é uma lista exaustiva — tem sempre "Outra marca" como escape para
  texto livre). Para adicionar marcas/modelos, edita só esse ficheiro.
- **Distrito** por anúncio, lista em `config/distritos.php`.
- **Filtros em escalões fixos** (preço/ano/km, como o auto.pt) definidos em
  `config/faixas_filtro.php`.
- Separadores "Carros usados / Motas usadas / Pesados" no menu e na home.
- Se já tinhas a base de dados antiga, corre o `migracoes.sql` atualizado
  (adiciona `tipo_veiculo`, `distrito`, `cilindrada`, `capacidade_carga_kg`,
  `numero_eixos` à tabela `veiculos`).

### Próximo passo combinado: geração de descrição por IA
Já existe o botão "Gerar descrição automaticamente" no formulário de criar
anúncio, e o endpoint `anuncios/gerar_descricao.php` — mas este último é só
um placeholder que devolve "não configurado". Fica pronto para ligar à
Claude API assim que avançarmos com essa funcionalidade.

## Notas de segurança corrigidas nesta reorganização

- Password SMTP deixou de estar hardcoded no código-fonte.
- Escapatória de XSS em `editar_anuncio.php` (valores não escapados).
- Nome de campo inconsistente entre o formulário e o processamento de
  novas fotos ao editar um anúncio.
