<?php
/**
 * Corre periodicamente (cron) para tentar publicar de novo pedidos que
 * já foram pagos ("pago") ou que falharam numa tentativa anterior
 * ("falhou") — por exemplo, depois de o lojista configurar o token da
 * Standvirtual que faltava.
 *
 * Sugestão de linha de crontab (a cada 15 minutos):
 *   asterisco/15 * * * * php /caminho/para/car_sale/cron/publicar_pendentes.php >> /var/log/car_sale_sync.log 2>&1
 *
 * NÃO deve ser colocado numa pasta acessível publicamente pelo browser
 * sem proteção adicional — idealmente corre só via linha de comandos.
 */

require_once __DIR__ . '/../config/bootstrap.php';
require_once BASE_PATH . '/includes/sync/publicacao_externa.php';

if (PHP_SAPI !== 'cli') {
    http_response_code(403);
    die("Este script só pode ser executado via linha de comandos (cron).");
}

$stmt = $pdo->query("SELECT DISTINCT veiculo_id FROM publicacoes_externas WHERE estado IN ('pago', 'falhou')");
$veiculoIds = $stmt->fetchAll(PDO::FETCH_COLUMN);

echo "[" . date('Y-m-d H:i:s') . "] " . count($veiculoIds) . " veículo(s) com divulgação pendente.\n";

foreach ($veiculoIds as $veiculoId) {
    $resultados = processarPublicacoesPendentes($pdo, (int) $veiculoId);
    foreach ($resultados as $plataforma => $resultado) {
        $estado = $resultado['ok'] ? 'OK' : ('ERRO: ' . $resultado['erro']);
        echo "  veiculo #$veiculoId [$plataforma] -> $estado\n";
    }
}
