<?php
require_once __DIR__ . '/config/bootstrap.php';
require BASE_PATH . '/includes/header.php';
?>

<main class="detalhe-page" style="max-width:800px;margin:40px auto;line-height:1.7;">
    <h1 class="page-title">Política de Privacidade</h1>

    <p>Esta página resume, de forma simples, como o AutoMarket trata os teus
    dados pessoais, em cumprimento do Regulamento Geral sobre a Proteção de
    Dados (RGPD).</p>

    <h2>Que dados recolhemos</h2>
    <ul>
        <li>Dados de registo: nome, email, password (guardada de forma
            encriptada, nunca em texto simples), telefone e cidade
            (opcionais).</li>
        <li>Dados de loja (só para contas de lojista): nome, morada e
            descrição da loja, logótipo.</li>
        <li>Mensagens trocadas entre comprador e anunciante através da
            plataforma.</li>
    </ul>

    <h2>Para que usamos os dados</h2>
    <ul>
        <li>Criar e autenticar a tua conta.</li>
        <li>Mostrar o teu nome e cidade nos anúncios que publicas, para que
            outros utilizadores te possam contactar.</li>
        <li>Enviar o código de verificação de conta por email.</li>
    </ul>

    <h2>O que NÃO tornamos público</h2>
    <p>O teu email e telefone <strong>não são mostrados publicamente</strong>
    nas páginas de anúncios. O contacto entre compradores e anunciantes é
    feito através do sistema de mensagens interno da plataforma. O telefone
    da loja só é mostrado se tu, enquanto lojista, decidires revelá-lo através
    do botão "Mostrar telefone" na tua página de loja.</p>

    <h2>Os teus direitos</h2>
    <p>Podes a qualquer momento pedir para consultar, corrigir ou apagar os
    teus dados, ou encerrar a tua conta, contactando-nos através do email de
    suporte indicado no rodapé do site.</p>
</main>

<?php include BASE_PATH . '/includes/footer.php'; ?>
