<?php
require_once __DIR__ . '/../config/bootstrap.php';
require_once BASE_PATH . '/includes/verificacao.php';

$erro = "";
$sucesso = "";

$email = $_GET["email"] ?? $_SESSION["verificar_email"] ?? "";

// Aviso vindo do registo (ex: falha ao enviar o primeiro email)
if (isset($_SESSION["verificar_aviso"])) {
    $erro = $_SESSION["verificar_aviso"];
    unset($_SESSION["verificar_aviso"]);
}

// ----- Reenviar código -----
if ($_SERVER["REQUEST_METHOD"] === "POST" && isset($_POST["acao"]) && $_POST["acao"] === "reenviar") {

    $email = trim($_POST["email"] ?? "");

    $stmt = $pdo->prepare("SELECT id, nome, verificado FROM utilizadores WHERE email = ?");
    $stmt->execute([$email]);
    $user = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$user) {
        $erro = "Não encontrámos nenhuma conta com este email.";
    } elseif ((int)$user["verificado"] === 1) {
        $sucesso = "Esta conta já está verificada. Podes fazer login.";
    } else {
        $resultado = gerarEEnviarCodigo($pdo, (int)$user["id"], $email, $user["nome"]);
        if ($resultado["ok"]) {
            $sucesso = "Enviámos um novo código para o teu email.";
        } else {
            $erro = "Não foi possível enviar o email agora. Tenta novamente dentro de alguns minutos.";
        }
    }
}

// ----- Confirmar código -----
if ($_SERVER["REQUEST_METHOD"] === "POST" && isset($_POST["acao"]) && $_POST["acao"] === "confirmar") {

    $email  = trim($_POST["email"] ?? "");
    $codigo = trim($_POST["codigo"] ?? "");

    $stmt = $pdo->prepare("SELECT * FROM utilizadores WHERE email = ?");
    $stmt->execute([$email]);
    $user = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$user) {
        $erro = "Não encontrámos nenhuma conta com este email.";
    } elseif ((int)$user["verificado"] === 1) {
        $sucesso = "Esta conta já está verificada. Podes fazer login.";
    } elseif ($codigo === "" || $user["codigo_verificacao"] === null) {
        $erro = "Código inválido. Pede um novo código abaixo.";
    } elseif ($codigo !== $user["codigo_verificacao"]) {
        $erro = "Código incorreto. Verifica e tenta novamente.";
    } elseif (strtotime($user["codigo_expira"]) < time()) {
        $erro = "Este código expirou. Pede um novo código abaixo.";
    } else {
        // Código válido: ativa a conta e faz login automático
        $pdo->prepare("UPDATE utilizadores SET verificado = 1, codigo_verificacao = NULL, codigo_expira = NULL WHERE id = ?")
            ->execute([$user["id"]]);

        iniciarSessaoUtilizador($user);
        unset($_SESSION["verificar_email"]);

        $_SESSION["anuncio_sucesso"] = "Conta verificada com sucesso! Bem-vindo(a) à AutoMarket.";
        header("Location: " . BASE_URL . "/index.php");
        exit;
    }
}
?>

<?php include BASE_PATH . '/includes/header.php'; ?>

<div class="register-container">
    <h2>Verificar conta</h2>
    <p class="verificar-texto">
        Enviámos um código de 6 dígitos para o teu email.
        Introduz o código abaixo para ativares a tua conta.
    </p>

    <?php if (!empty($erro)): ?>
        <p class="erro"><?= htmlspecialchars($erro) ?></p>
    <?php endif; ?>

    <?php if (!empty($sucesso)): ?>
        <p class="sucesso"><?= htmlspecialchars($sucesso) ?></p>
    <?php endif; ?>

    <form method="POST" action="<?= BASE_URL ?>/auth/verificar_email.php" class="register-form">
        <input type="hidden" name="acao" value="confirmar">
        <input type="email" name="email" placeholder="Email" value="<?= htmlspecialchars($email) ?>" required>
        <input type="text" name="codigo" placeholder="Código de 6 dígitos" maxlength="6" inputmode="numeric" pattern="[0-9]{6}" required>
        <button type="submit">Confirmar código</button>
    </form>

    <form method="POST" action="<?= BASE_URL ?>/auth/verificar_email.php" class="verificar-reenviar">
        <input type="hidden" name="acao" value="reenviar">
        <input type="hidden" name="email" value="<?= htmlspecialchars($email) ?>">
        <button type="submit" class="btn-link">Não recebeste? Reenviar código</button>
    </form>
</div>

<?php include BASE_PATH . '/includes/footer.php'; ?>
