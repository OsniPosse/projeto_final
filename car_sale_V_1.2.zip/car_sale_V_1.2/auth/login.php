<?php
require_once __DIR__ . '/../config/bootstrap.php';

// Permite voltar à página de onde veio o pedido de login (ex: favoritos,
// enviar mensagem). Só aceitamos caminhos internos, nunca um URL externo.
$redirect = $_POST["redirect"] ?? $_GET["redirect"] ?? "";
if ($redirect !== "" && strpos($redirect, BASE_URL) !== 0) {
    $redirect = "";
}
$destino = $redirect !== "" ? $redirect : BASE_URL . "/index.php";

if ($_SERVER["REQUEST_METHOD"] === "POST") {

    $email = trim($_POST["email"]);
    $password = $_POST["password"];

    $sql = "SELECT * FROM utilizadores WHERE email = ?";
    $stmt = $pdo->prepare($sql);
    $stmt->execute([$email]);
    $user = $stmt->fetch(PDO::FETCH_ASSOC);

    if ($user && $user["password"] && password_verify($password, $user["password"])) {
         if ((int)$user["verificado"] !== 1) {
            $_SESSION["verificar_email"] = $email;
            header("Location: " . BASE_URL . "/auth/verificar_email.php");
            exit;
        }

        iniciarSessaoUtilizador($user);

        header("Location: " . $destino);
        exit;

    } else {

        $_SESSION["login_erro"] = "Email ou password incorretos";
        header("Location: " . $destino);
        exit;

    }
}
?>
