<?php
require_once __DIR__ . '/../config/bootstrap.php';
require_once BASE_PATH . '/includes/google_oauth.php';

$googleConfig = require BASE_PATH . '/config/google.php';

if ($googleConfig['client_id'] === '.env.GOOGLE_CLIENT_ID' || $googleConfig['client_secret'] === '.env.GOOGLE_CLIENT_SECRET') {
    $_SESSION["login_erro"] = "O login com Google ainda não está configurado neste servidor.";
    header("Location: " . BASE_URL . "/index.php");
    exit;
}

// "state" aleatório para proteger contra CSRF no callback
$state = bin2hex(random_bytes(16));
$_SESSION["google_oauth_state"] = $state;

// Guarda o perfil pré-escolhido (ex: veio de "Criar conta lojista"), para
// usar apenas se a conta Google ainda não existir na plataforma.
$_SESSION["google_oauth_perfil"] = in_array($_GET["perfil"] ?? "", ["comprador", "anunciante", "lojista"], true)
    ? $_GET["perfil"]
    : "comprador";

header("Location: " . googleUrlAutorizacao($googleConfig, $state));
exit;
