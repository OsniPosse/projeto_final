<?php
require_once __DIR__ . '/../config/bootstrap.php';
require_once BASE_PATH . '/includes/google_oauth.php';

$googleConfig = require BASE_PATH . '/config/google.php';

function falharLogin(string $mensagem): void
{
    $_SESSION["login_erro"] = $mensagem;
    header("Location: " . BASE_URL . "/index.php");
    exit;
}

// O utilizador cancelou no ecrã do Google, ou ocorreu um erro
if (isset($_GET["error"])) {
    falharLogin("Não foi possível continuar com o Google.");
}

// Proteção CSRF: o "state" tem de bater certo com o que foi guardado no login
$stateEsperado = $_SESSION["google_oauth_state"] ?? null;
unset($_SESSION["google_oauth_state"]);

if (!isset($_GET["code"], $_GET["state"]) || $_GET["state"] !== $stateEsperado) {
    falharLogin("A sessão de login com o Google expirou. Tenta novamente.");
}

$resultado = googleObterUtilizador($googleConfig, $_GET["code"]);

if (!$resultado["ok"]) {
    falharLogin($resultado["erro"]);
}

$email    = $resultado["email"];
$nome     = $resultado["nome"];
$googleId = $resultado["google_id"];

// 1. Já existe conta com este google_id?
$stmt = $pdo->prepare("SELECT * FROM utilizadores WHERE google_id = ?");
$stmt->execute([$googleId]);
$user = $stmt->fetch(PDO::FETCH_ASSOC);

// 2. Já existe conta com este email (registada com password)? Liga as contas.
if (!$user) {
    $stmt = $pdo->prepare("SELECT * FROM utilizadores WHERE email = ?");
    $stmt->execute([$email]);
    $user = $stmt->fetch(PDO::FETCH_ASSOC);

    if ($user) {
        $pdo->prepare("UPDATE utilizadores SET google_id = ?, verificado = 1 WHERE id = ?")
            ->execute([$googleId, $user["id"]]);
        $user["google_id"]  = $googleId;
        $user["verificado"] = 1;
    }
}

// 3. Ainda não existe: cria conta nova (o email do Google já vem verificado)
if (!$user) {
    $perfil = $_SESSION["google_oauth_perfil"] ?? "comprador";
    unset($_SESSION["google_oauth_perfil"]);

    // Password aleatória (não é usada — esta conta só entra via Google,
    // a menos que o utilizador defina uma password mais tarde no perfil).
    $hashAleatorio = password_hash(bin2hex(random_bytes(32)), PASSWORD_DEFAULT);

    $sql = "INSERT INTO utilizadores
                (nome, email, password, perfil, verificado, google_id, nome_loja, plano_lojista)
            VALUES (?, ?, ?, ?, 1, ?, ?, ?)";

    $pdo->prepare($sql)->execute([
        $nome,
        $email,
        $hashAleatorio,
        $perfil,
        $googleId,
        $perfil === "lojista" ? $nome : null,
        $perfil === "lojista" ? "basico" : null,
    ]);

    $novoId = $pdo->lastInsertId();
    $stmt = $pdo->prepare("SELECT * FROM utilizadores WHERE id = ?");
    $stmt->execute([$novoId]);
    $user = $stmt->fetch(PDO::FETCH_ASSOC);

    iniciarSessaoUtilizador($user);
    $_SESSION["anuncio_sucesso"] = "Conta criada com a tua conta Google. Bem-vindo(a) à AutoMarket!";

    if ($perfil === "lojista") {
        header("Location: " . BASE_URL . "/loja/editar_loja.php");
        exit;
    }

    header("Location: " . BASE_URL . "/index.php");
    exit;
}

// Conta existente encontrada (por google_id ou por email) -> login normal
iniciarSessaoUtilizador($user);
header("Location: " . BASE_URL . "/index.php");
exit;
