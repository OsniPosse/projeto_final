<?php
/**
 * Carregador simples de variáveis de ambiente a partir de um ficheiro .env
 * Não requer nenhuma dependência externa (Composer).
 */

function carregarEnv(string $caminho): void
{
    if (!file_exists($caminho)) {
        return;
    }

    foreach (file($caminho, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES) as $linha) {
        $linha = trim($linha);

        if ($linha === '' || str_starts_with($linha, '#')) {
            continue;
        }

        $partes = array_pad(explode('=', $linha, 2), 2, '');
        $chave  = trim($partes[0]);
        $valor  = trim($partes[1], " \t\n\r\0\x0B\"'");

        if ($chave !== '' && getenv($chave) === false) {
            putenv("$chave=$valor");
            $_ENV[$chave] = $valor;
        }
    }
}

/** Lê uma variável de ambiente com valor por omissão. */
function env(string $chave, $default = null)
{
    $valor = getenv($chave);
    return $valor === false ? $default : $valor;
}
