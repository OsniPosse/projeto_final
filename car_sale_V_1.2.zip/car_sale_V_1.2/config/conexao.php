<?php
/**
 * Ligação à base de dados (PDO) + arranque da sessão.
 * As credenciais vêm do .env (ver .env.example) e nunca devem ser
 * escritas diretamente aqui nem enviadas para o repositório Git.
 */

$host   = env('DB_HOST', 'localhost');
$dbname = env('DB_NAME', 'car_sale_v1');
$user   = env('DB_USER', 'root');
$pass   = env('DB_PASS', '');

try {
    $pdo = new PDO("mysql:host=$host;dbname=$dbname;charset=utf8mb4", $user, $pass);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    die("Erro na BD: " . $e->getMessage());
}

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
