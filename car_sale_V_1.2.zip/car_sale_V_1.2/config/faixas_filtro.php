<?php
/**
 * Escalões fixos para os filtros de preço, ano e quilometragem — dropdowns
 * em vez de inputs numéricos livres, tal como no auto.pt. Mais rápidos de
 * usar em mobile e evitam valores absurdos (ex: "preço até -50").
 */

return [
    'preco' => [
        500, 1000, 1500, 2000, 2500, 3000, 4000, 5000, 6000, 7000, 8000,
        9000, 10000, 12000, 14000, 16000, 18000, 20000, 22000, 24000,
        26000, 28000, 30000, 35000, 40000, 50000, 60000, 70000, 80000,
        90000, 100000, 150000, 200000, 300000,
    ],

    'ano' => range((int) date('Y'), 1970, -1),

    'km' => [
        1000, 3000, 5000, 7000, 9000, 10000, 20000, 30000, 40000, 50000,
        60000, 70000, 80000, 90000, 100000, 150000, 200000, 250000,
        300000, 400000, 500000,
    ],
];
