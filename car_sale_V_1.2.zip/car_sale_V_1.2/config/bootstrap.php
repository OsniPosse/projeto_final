<?php
/**
 * Bootstrap central da aplicação.
 *
 * Todas as páginas (na raiz ou dentro de auth/, anuncios/, loja/) devem
 * começar com:
 *      require_once __DIR__ . '/../config/bootstrap.php';   // dentro de subpasta
 *      require_once __DIR__ . '/config/bootstrap.php';      // na raiz
 *
 * Isto substitui os antigos "require conexao.php" espalhados por cada
 * ficheiro e garante que $pdo, BASE_PATH, BASE_URL e as funções de
 * autenticação (auth_guard.php) estão sempre disponíveis, independentemente
 * da profundidade da pasta onde o ficheiro se encontra.
 */

// Caminho absoluto (sistema de ficheiros) até à raiz do projeto
if (!defined('BASE_PATH')) {
    define('BASE_PATH', dirname(__DIR__));
}

// URL base do projeto (ex: "" se estiver na raiz do site, ou "/car_sale"
// se o projeto estiver numa subpasta do document root)
if (!defined('BASE_URL')) {
    $docRoot     = str_replace('\\', '/', rtrim($_SERVER['DOCUMENT_ROOT'] ?? '', '/'));
    $projectPath = str_replace('\\', '/', BASE_PATH);

    $baseUrl = '';
    if ($docRoot !== '' && strpos($projectPath, $docRoot) === 0) {
        $baseUrl = substr($projectPath, strlen($docRoot));
    }

    define('BASE_URL', rtrim($baseUrl, '/'));
}

require_once BASE_PATH . '/config/env.php';
carregarEnv(BASE_PATH . '/.env');

require_once BASE_PATH . '/config/conexao.php';
require_once BASE_PATH . '/includes/auth_guard.php';
