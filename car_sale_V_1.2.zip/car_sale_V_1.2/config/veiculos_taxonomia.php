<?php
/**
 * Marcas e modelos por tipo de veículo, para alimentar os selects em
 * cascata (marca -> modelo) na criação de anúncios e nos filtros,
 * à semelhança do auto.pt.
 *
 * Não é uma lista exaustiva (o auto.pt tem 150+ marcas de carros) — tem as
 * marcas mais comuns em Portugal, e cada tipo inclui sempre "Outra marca"
 * como escape para o utilizador escrever livremente quando a marca não
 * está na lista. O mesmo vale para os modelos: se a marca não tiver
 * modelos pré-definidos, o campo de modelo passa a ser texto livre.
 *
 * Para adicionar uma marca/modelo, basta editar este ficheiro — nenhuma
 * alteração à base de dados é necessária (marca/modelo continuam a ser
 * gravados como texto em `veiculos`).
 */

return [

    'carro' => [
        'nome' => 'Carros',
        'marcas' => [
            'Audi'          => ['A1', 'A3', 'A4', 'A6', 'Q2', 'Q3', 'Q5'],
            'BMW'           => ['Série 1', 'Série 2', 'Série 3', 'Série 5', 'X1', 'X3', 'X5'],
            'BYD'           => ['Atto 3', 'Dolphin', 'Seal'],
            'Citroën'       => ['C1', 'C3', 'C3 Aircross', 'C4', 'Berlingo'],
            'Cupra'         => ['Born', 'Formentor', 'Leon'],
            'Dacia'         => ['Sandero', 'Duster', 'Jogger', 'Spring'],
            'DS'            => ['DS3', 'DS4', 'DS7'],
            'Fiat'          => ['500', 'Panda', 'Tipo', '500X'],
            'Ford'          => ['Fiesta', 'Focus', 'Puma', 'Kuga', 'Ranger'],
            'Honda'         => ['Civic', 'Jazz', 'CR-V', 'HR-V'],
            'Hyundai'       => ['i10', 'i20', 'i30', 'Tucson', 'Kona'],
            'Jeep'          => ['Renegade', 'Compass', 'Avenger'],
            'Kia'           => ['Picanto', 'Rio', 'Ceed', 'Sportage', 'Niro'],
            'Land Rover'    => ['Range Rover Evoque', 'Discovery Sport', 'Defender'],
            'Lexus'         => ['CT', 'IS', 'NX', 'RX'],
            'Mazda'         => ['Mazda2', 'Mazda3', 'CX-3', 'CX-5'],
            'Mercedes-Benz' => ['Classe A', 'Classe B', 'Classe C', 'Classe E', 'GLA', 'GLC'],
            'MINI'          => ['Cooper', 'Countryman', 'Clubman'],
            'Mitsubishi'    => ['Space Star', 'ASX', 'Eclipse Cross'],
            'Nissan'        => ['Micra', 'Juke', 'Qashqai', 'X-Trail'],
            'Opel'          => ['Corsa', 'Astra', 'Crossland', 'Grandland', 'Mokka'],
            'Peugeot'       => ['108', '208', '2008', '308', '3008', '5008'],
            'Porsche'       => ['911', 'Cayenne', 'Macan', 'Panamera'],
            'Renault'       => ['Clio', 'Captur', 'Mégane', 'Kadjar', 'Austral'],
            'Seat'          => ['Ibiza', 'Leon', 'Arona', 'Ateca'],
            'Skoda'         => ['Fabia', 'Octavia', 'Kamiq', 'Karoq', 'Kodiaq'],
            'Smart'         => ['ForTwo', 'ForFour'],
            'Subaru'        => ['Impreza', 'XV', 'Forester'],
            'Suzuki'        => ['Swift', 'Vitara', 'S-Cross'],
            'Tesla'         => ['Model 3', 'Model Y', 'Model S'],
            'Toyota'        => ['Aygo', 'Yaris', 'Corolla', 'C-HR', 'RAV4'],
            'Volkswagen'    => ['Polo', 'Golf', 'T-Roc', 'Tiguan', 'Passat'],
            'Volvo'         => ['XC40', 'XC60', 'XC90', 'V60'],
            'Outra marca'   => [],
        ],
    ],

    'mota' => [
        'nome' => 'Motas',
        'marcas' => [
            'Aprilia'         => ['RS 125', 'RS 660', 'Tuono'],
            'BMW'             => ['F 850 GS', 'R 1250 GS', 'G 310 R'],
            'Derbi'           => ['Senda', 'Variant'],
            'Ducati'          => ['Monster', 'Panigale', 'Scrambler'],
            'Harley-Davidson' => ['Sportster', 'Street Bob', 'Iron 883'],
            'Honda'           => ['PCX125', 'CB500F', 'CB650R', 'CBR600RR', 'Africa Twin'],
            'Husqvarna'       => ['Svartpilen', 'Vitpilen'],
            'Kawasaki'        => ['Ninja 400', 'Z650', 'Versys 650'],
            'KTM'             => ['Duke 125', 'Duke 390', 'Adventure 390'],
            'Kymco'           => ['Agility', 'People', 'Xciting'],
            'Moto Guzzi'      => ['V7', 'V85 TT'],
            'MV Agusta'       => ['Brutale', 'F3'],
            'Peugeot'         => ['Django', 'Tweet'],
            'Piaggio'         => ['Liberty', 'MP3', 'Beverly'],
            'Suzuki'          => ['GSX-R600', 'V-Strom 650', 'Burgman'],
            'Triumph'         => ['Street Triple', 'Bonneville', 'Tiger 900'],
            'Vespa'           => ['Primavera', 'GTS', 'Sprint'],
            'Yamaha'          => ['MT-07', 'MT-09', 'Tricity', 'XMAX', 'Tenere 700'],
            'Outra marca'     => [],
        ],
    ],

    'pesado' => [
        'nome' => 'Pesados',
        'marcas' => [
            'DAF'            => ['XF', 'CF', 'LF'],
            'Fiat'           => ['Ducato Chassis', 'Doblo Cargo'],
            'Ford'           => ['Transit Chassis', 'Cargo'],
            'Foton'          => ['Aumark', 'Tunland'],
            'Hyundai'        => ['Mighty', 'HD'],
            'Isuzu'          => ['N-Series', 'F-Series'],
            'Iveco'          => ['Daily', 'Eurocargo', 'Stralis', 'S-Way'],
            'MAN'            => ['TGL', 'TGM', 'TGX'],
            'Mercedes-Benz'  => ['Sprinter Chassis', 'Atego', 'Actros'],
            'Nissan'         => ['Cabstar', 'NT400'],
            'Renault Trucks' => ['Master Chassis', 'D', 'T'],
            'Scania'         => ['P-series', 'R-series', 'S-series'],
            'Volvo Trucks'   => ['FL', 'FM', 'FH'],
            'Outra marca'    => [],
        ],
    ],

];
