<?php

return [
    'api_key' => $_ENV['GEMINI_API_KEY']??'',
    'model' => $_ENV['GEMINI_MODEL']??''
];

