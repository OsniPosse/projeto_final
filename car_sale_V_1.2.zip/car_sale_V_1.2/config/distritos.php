<?php
/**
 * Distritos de Portugal continental + regiões autónomas, para o filtro
 * de localização (à semelhança do "Distritos" no auto.pt).
 */

return [
    'Aveiro', 'Beja', 'Braga', 'Bragança', 'Castelo Branco', 'Coimbra',
    'Évora', 'Faro', 'Guarda', 'Leiria', 'Lisboa', 'Portalegre', 'Porto',
    'Santarém', 'Setúbal', 'Viana do Castelo', 'Vila Real', 'Viseu',
    'Açores', 'Madeira',
];
