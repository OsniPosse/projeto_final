<?php
/**
 * Credenciais da aplicação Google OAuth 2.0.
 * Cria as tuas em https://console.cloud.google.com/apis/credentials
 * (tipo "Aplicação Web") e coloca os valores no .env.
 *
 * URI de redirecionamento autorizado a configurar na Google Cloud Console
 * deve ser exatamente igual ao valor de GOOGLE_REDIRECT_URI no .env, por
 * exemplo: http://localhost/car_sale/auth/google_callback.php
 */

return [
    'client_id'     => env('GOOGLE_CLIENT_ID', ''),
    'client_secret' => env('GOOGLE_CLIENT_SECRET', ''),
    'redirect_uri'  => env('GOOGLE_REDIRECT_URI', BASE_URL . '/auth/google_callback.php'),
];
