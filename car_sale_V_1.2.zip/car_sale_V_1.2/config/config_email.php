<?php
/**
 * Configuração SMTP para o envio do código de verificação por email.
 * Os valores reais vêm do ficheiro .env (nunca commitado). Ver .env.example.
 *
 * GMAIL: ativa a verificação em 2 passos na tua conta Google e gera uma
 * "Password de aplicação" em https://myaccount.google.com/apppasswords
 * — usa essa password no .env, NÃO a tua password normal da conta.
 */

return [
    'SMTP_HOST'       => env('SMTP_HOST', 'smtp.gmail.com'),
    'SMTP_PORT'       => (int) env('SMTP_PORT', 587),
    'SMTP_SECURE'     => env('SMTP_SECURE', 'tls'), // 'tls' (587) ou 'ssl' (465)
    'SMTP_USER'       => env('SMTP_USER', ''),
    'SMTP_PASS'       => env('SMTP_PASS', ''),
    'EMAIL_FROM'      => env('EMAIL_FROM', ''),
    'EMAIL_FROM_NOME' => env('EMAIL_FROM_NOME', 'AutoMarket'),
];
