<?php
/**
 * Configuração das plataformas de divulgação externa (Standvirtual / OLX).
 *
 * IMPORTANTE — leitura obrigatória antes de ativar isto em produção:
 *
 * A Standvirtual só disponibiliza a sua API de integração a contas
 * profissionais (stands) com um plano contratado. Não existe um endpoint
 * público documentado; o URL, o formato do payload e o token só são
 * fornecidos pela Standvirtual depois de contratares um plano profissional
 * (ver https://profissionais.standvirtual.com/). Em Portugal, publicar no
 * Standvirtual publica também automaticamente no OLX (o mesmo grupo,
 * FixeAds/OLX Group, sincroniza os anúncios entre os dois portais) — por
 * isso, na prática, a maioria dos stands só precisa de configurar o
 * Standvirtual. A opção "OLX" fica aqui preparada para o caso de, no
 * futuro, quereres uma conta/API OLX totalmente independente.
 *
 * Até teres essas credenciais reais, o StandvirtualProvider/OlxProvider
 * (ver includes/sync/) devolvem sempre "falhou" com uma mensagem clara —
 * nada é publicado de forma enganosa.
 */

return [
    'standvirtual' => [
        'nome'        => 'Standvirtual',
        'preco_cents' => (int) env('PRECO_STANDVIRTUAL_CENTS', 999), // 9,99€
        'api_url'     => env('STANDVIRTUAL_API_URL', ''),            // dado pela Standvirtual
        'ativo'       => env('STANDVIRTUAL_API_URL', '') !== '',
    ],
    'olx' => [
        'nome'        => 'OLX (direto)',
        'preco_cents' => (int) env('PRECO_OLX_CENTS', 499), // 4,99€
        'api_url'     => env('OLX_API_URL', ''),
        'ativo'       => env('OLX_API_URL', '') !== '',
    ],
];
