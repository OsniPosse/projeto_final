<?php
$iconesTipo = ['carro' => 'ti-car', 'mota' => 'ti-motorbike', 'pesado' => 'ti-truck'];
$icone = $iconesTipo[$carro['tipo_veiculo'] ?? 'carro'] ?? 'ti-car';
?>
<a href="<?= BASE_URL ?>/anuncios/detalhes.php?id=<?= (int)$carro['id'] ?>" class="car-card">
    <div class="car-img">
        <?php if (!empty($carro['foto'])): ?>
            <img src="<?= BASE_URL . '/' . htmlspecialchars($carro['foto']) ?>" alt="Foto do veículo">
        <?php else: ?>
            <i class="ti <?= $icone ?>"></i>
        <?php endif; ?>

        <?php if ($carro['estado'] === 'novo'): ?>
            <span class="car-badge badge-novo">Novo</span>
        <?php else: ?>
            <span class="car-badge badge-used"><?= ucfirst($carro['estado']) ?></span>
        <?php endif; ?>
    </div>

    <div class="car-info">
        <div class="car-name"><?= htmlspecialchars($carro['marca'] . ' ' . $carro['modelo']) ?></div>
        <div class="car-specs">
            <?= (int)$carro['ano'] ?> ·
            <?= number_format($carro['quilometragem'], 0, ',', '.') ?> km ·
            <?= ucfirst($carro['combustivel']) ?>

            <?php if (($carro['tipo_veiculo'] ?? 'carro') === 'mota' && !empty($carro['cilindrada'])): ?>
                · <?= (int)$carro['cilindrada'] ?> cc
            <?php elseif (($carro['tipo_veiculo'] ?? 'carro') === 'pesado' && !empty($carro['capacidade_carga_kg'])): ?>
                · <?= number_format($carro['capacidade_carga_kg'], 0, ',', '.') ?> kg
            <?php else: ?>
                · <?= ucfirst($carro['cambio']) ?>
            <?php endif; ?>
        </div>
        <div class="car-price">€<?= number_format($carro['preco'], 2, ',', '.') ?></div>
        <div class="car-location">
            <i class="ti ti-map-pin"></i> <?= htmlspecialchars($carro['distrito'] ?: $carro['cidade']) ?>
        </div>
    </div>
</a>
