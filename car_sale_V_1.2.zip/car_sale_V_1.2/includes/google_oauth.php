<?php
/**
 * Fluxo "Authorization Code" do Google OAuth 2.0, implementado apenas com
 * cURL (sem SDK/Composer) — suficiente para obter nome + email verificado.
 */

/** Constrói o URL para onde o utilizador é enviado para autorizar a app. */
function googleUrlAutorizacao(array $googleConfig, string $state): string
{
    $params = [
        'client_id'     => $googleConfig['client_id'],
        'redirect_uri'  => $googleConfig['redirect_uri'],
        'response_type' => 'code',
        'scope'         => 'openid email profile',
        'access_type'   => 'online',
        'prompt'        => 'select_account',
        'state'         => $state,
    ];

    return 'https://accounts.google.com/o/oauth2/v2/auth?' . http_build_query($params);
}

/**
 * Troca o "code" devolvido pelo Google por um access_token,
 * e depois pede os dados do utilizador (nome, email, verificado).
 *
 * @return array{ok: bool, erro?: string, email?: string, nome?: string, google_id?: string}
 */
function googleObterUtilizador(array $googleConfig, string $code): array
{
    // 1. Trocar o "code" por um access_token
    $tokenResposta = curlPost('https://oauth2.googleapis.com/token', [
        'code'          => $code,
        'client_id'     => $googleConfig['client_id'],
        'client_secret' => $googleConfig['client_secret'],
        'redirect_uri'  => $googleConfig['redirect_uri'],
        'grant_type'    => 'authorization_code',
    ]);

    if (!$tokenResposta['ok'] || empty($tokenResposta['dados']['access_token'])) {
        return ['ok' => false, 'erro' => 'Não foi possível validar a autorização do Google.'];
    }

    $accessToken = $tokenResposta['dados']['access_token'];

    // 2. Pedir os dados do perfil com o access_token
    $perfilResposta = curlGet(
        'https://www.googleapis.com/oauth2/v3/userinfo',
        ['Authorization: Bearer ' . $accessToken]
    );

    if (!$perfilResposta['ok'] || empty($perfilResposta['dados']['email'])) {
        return ['ok' => false, 'erro' => 'Não foi possível obter os dados da conta Google.'];
    }

    $perfil = $perfilResposta['dados'];

    if (empty($perfil['email_verified'])) {
        return ['ok' => false, 'erro' => 'O teu email Google ainda não está verificado.'];
    }

    return [
        'ok'        => true,
        'email'     => $perfil['email'],
        'nome'      => $perfil['name'] ?? explode('@', $perfil['email'])[0],
        'google_id' => $perfil['sub'] ?? '',
    ];
}

/** POST simples com cURL, devolve o JSON já descodificado. */
function curlPost(string $url, array $campos): array
{
    $ch = curl_init($url);
    curl_setopt_array($ch, [
        CURLOPT_POST           => true,
        CURLOPT_POSTFIELDS     => http_build_query($campos),
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_TIMEOUT        => 10,
    ]);
    $resposta = curl_exec($ch);
    $erro     = curl_error($ch);
    curl_close($ch);

    if ($resposta === false) {
        return ['ok' => false, 'erro' => $erro];
    }

    return ['ok' => true, 'dados' => json_decode($resposta, true) ?? []];
}

/** GET simples com cURL (com cabeçalhos), devolve o JSON já descodificado. */
function curlGet(string $url, array $headers = []): array
{
    $ch = curl_init($url);
    curl_setopt_array($ch, [
        CURLOPT_HTTPHEADER     => $headers,
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_TIMEOUT        => 10,
    ]);
    $resposta = curl_exec($ch);
    $erro     = curl_error($ch);
    curl_close($ch);

    if ($resposta === false) {
        return ['ok' => false, 'erro' => $erro];
    }

    return ['ok' => true, 'dados' => json_decode($resposta, true) ?? []];
}
