<?php
require_once __DIR__ . '/SyndicationProvider.php';

/**
 * Adapter para a API profissional da Standvirtual.
 *
 * ATENÇÃO: o URL do endpoint, os nomes dos campos do payload e o formato
 * exato do token abaixo são PLACEHOLDERS. A Standvirtual só entrega essa
 * documentação depois de contratares um plano profissional para o teu
 * stand (secção "Integração de anúncios via API" em
 * https://profissionais.standvirtual.com/). Assim que teres o manual de
 * integração deles, ajusta apenas o método `publicar()` e `remover()`
 * abaixo — o resto da plataforma (pagamento, estados, UI) não precisa de
 * mudar, porque fala apenas com esta classe através da interface
 * SyndicationProvider.
 */
class StandvirtualProvider implements SyndicationProvider
{
    private string $apiUrl;

    public function __construct(string $apiUrl)
    {
        $this->apiUrl = rtrim($apiUrl, '/');
    }

    public function publicar(array $veiculo, array $credenciais): array
    {
        if (empty($credenciais['standvirtual_api_token']) || empty($credenciais['standvirtual_stand_id'])) {
            return [
                'ok' => false,
                'referencia_externa' => null,
                'erro' => 'Esta loja ainda não configurou o token/ID da Standvirtual em "A minha loja > Divulgação externa".',
            ];
        }

        if ($this->apiUrl === '') {
            return [
                'ok' => false,
                'referencia_externa' => null,
                'erro' => 'STANDVIRTUAL_API_URL não está definido no .env — falta confirmar o endpoint com a Standvirtual.',
            ];
        }

        // --- PLACEHOLDER: payload ilustrativo, a confirmar com a Standvirtual ---
        $payload = [
            'stand_id'      => $credenciais['standvirtual_stand_id'],
            'marca'         => $veiculo['marca'],
            'modelo'        => $veiculo['modelo'],
            'ano'           => $veiculo['ano'],
            'quilometragem' => $veiculo['quilometragem'],
            'preco'         => $veiculo['preco'],
            'combustivel'   => $veiculo['combustivel'],
            'cambio'        => $veiculo['cambio'],
            'estado'        => $veiculo['estado'],
            'descricao'     => $veiculo['descricao'],
        ];

        $ch = curl_init($this->apiUrl . '/anuncios');
        curl_setopt_array($ch, [
            CURLOPT_POST           => true,
            CURLOPT_HTTPHEADER     => [
                'Authorization: Bearer ' . $credenciais['standvirtual_api_token'],
                'Content-Type: application/json',
            ],
            CURLOPT_POSTFIELDS     => json_encode($payload),
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_TIMEOUT        => 15,
        ]);
        $resposta = curl_exec($ch);
        $erroCurl = curl_error($ch);
        $codigo   = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);

        if ($resposta === false) {
            return ['ok' => false, 'referencia_externa' => null, 'erro' => "Falha de rede: $erroCurl"];
        }

        $dados = json_decode($resposta, true);

        if ($codigo >= 200 && $codigo < 300 && !empty($dados['id'])) {
            return ['ok' => true, 'referencia_externa' => (string) $dados['id'], 'erro' => null];
        }

        return [
            'ok' => false,
            'referencia_externa' => null,
            'erro' => 'Standvirtual respondeu com erro (HTTP ' . $codigo . '): ' . ($dados['message'] ?? $resposta),
        ];
    }

    public function remover(string $referenciaExterna, array $credenciais): array
    {
        if ($this->apiUrl === '' || empty($credenciais['standvirtual_api_token'])) {
            return ['ok' => false, 'erro' => 'Integração Standvirtual não configurada.'];
        }

        $ch = curl_init($this->apiUrl . '/anuncios/' . urlencode($referenciaExterna));
        curl_setopt_array($ch, [
            CURLOPT_CUSTOMREQUEST  => 'DELETE',
            CURLOPT_HTTPHEADER     => ['Authorization: Bearer ' . $credenciais['standvirtual_api_token']],
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_TIMEOUT        => 15,
        ]);
        $resposta = curl_exec($ch);
        $codigo   = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);

        if ($resposta === false || $codigo >= 300) {
            return ['ok' => false, 'erro' => 'Não foi possível remover o anúncio na Standvirtual.'];
        }

        return ['ok' => true, 'erro' => null];
    }
}
