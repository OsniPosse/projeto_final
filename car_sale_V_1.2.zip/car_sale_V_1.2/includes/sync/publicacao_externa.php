<?php
require_once __DIR__ . '/SyndicationProvider.php';
require_once __DIR__ . '/StandvirtualProvider.php';
require_once __DIR__ . '/OlxProvider.php';

/** Devolve a lista de plataformas configuradas (id => dados + preço). */
function plataformasDivulgacao(): array
{
    return require BASE_PATH . '/config/integracoes.php';
}

/** Instancia o provider correto para uma plataforma. */
function obterProvider(string $plataforma): ?SyndicationProvider
{
    $config = plataformasDivulgacao();

    if (!isset($config[$plataforma])) {
        return null;
    }

    return match ($plataforma) {
        'standvirtual' => new StandvirtualProvider($config['standvirtual']['api_url']),
        'olx'          => new OlxProvider($config['olx']['api_url']),
        default        => null,
    };
}

/**
 * Cria (ou atualiza para pendente_pagamento) os pedidos de divulgação
 * escolhidos pelo lojista para um veículo.
 *
 * @param string[] $plataformasEscolhidas Ex: ['standvirtual', 'olx']
 */
function criarPedidosDivulgacao(PDO $pdo, int $veiculoId, array $plataformasEscolhidas): void
{
    $precos = plataformasDivulgacao();

    $sql = "INSERT INTO publicacoes_externas (veiculo_id, plataforma, estado, valor_cents)
            VALUES (?, ?, 'pendente_pagamento', ?)
            ON DUPLICATE KEY UPDATE
                estado = 'pendente_pagamento',
                valor_cents = VALUES(valor_cents),
                mensagem_erro = NULL";
    $stmt = $pdo->prepare($sql);

    foreach ($plataformasEscolhidas as $plataforma) {
        if (!isset($precos[$plataforma])) {
            continue;
        }
        $stmt->execute([$veiculoId, $plataforma, $precos[$plataforma]['preco_cents']]);
    }
}

/** Soma (em cêntimos) o custo das plataformas escolhidas. */
function custoTotalCents(array $plataformasEscolhidas): int
{
    $precos = plataformasDivulgacao();
    $total = 0;
    foreach ($plataformasEscolhidas as $plataforma) {
        $total += $precos[$plataforma]['preco_cents'] ?? 0;
    }
    return $total;
}

/**
 * Marca os pedidos pendentes de um veículo como pagos e tenta publicá-los
 * de imediato. Se a publicação falhar (ex: token ainda não configurado),
 * o pedido fica com estado "falhou" e pode ser reprocessado mais tarde
 * (ver cron/publicar_pendentes.php) sem cobrar de novo.
 */
function pagarEPublicar(PDO $pdo, int $veiculoId): array
{
    $pdo->prepare("UPDATE publicacoes_externas SET estado = 'pago' WHERE veiculo_id = ? AND estado = 'pendente_pagamento'")
        ->execute([$veiculoId]);

    return processarPublicacoesPendentes($pdo, $veiculoId);
}

/**
 * Tenta publicar (chama o provider) todos os pedidos já pagos de um
 * veículo que ainda não foram publicados com sucesso.
 *
 * @return array Lista de resultados por plataforma, para mostrar ao utilizador.
 */
function processarPublicacoesPendentes(PDO $pdo, int $veiculoId): array
{
    $stmt = $pdo->prepare("
        SELECT pe.*, v.marca, v.modelo, v.ano, v.quilometragem, v.preco,
               v.combustivel, v.cambio, v.estado AS estado_veiculo, v.descricao,
               u.standvirtual_stand_id, u.standvirtual_api_token
        FROM publicacoes_externas pe
        JOIN veiculos v ON v.id = pe.veiculo_id
        JOIN utilizadores u ON u.id = v.utilizador_id
        WHERE pe.veiculo_id = ? AND pe.estado IN ('pago', 'falhou')
    ");
    $stmt->execute([$veiculoId]);
    $pedidos = $stmt->fetchAll(PDO::FETCH_ASSOC);

    $resultados = [];

    foreach ($pedidos as $pedido) {
        $provider = obterProvider($pedido['plataforma']);
        if (!$provider) {
            continue;
        }

        $veiculo = [
            'marca' => $pedido['marca'], 'modelo' => $pedido['modelo'], 'ano' => $pedido['ano'],
            'quilometragem' => $pedido['quilometragem'], 'preco' => $pedido['preco'],
            'combustivel' => $pedido['combustivel'], 'cambio' => $pedido['cambio'],
            'estado' => $pedido['estado_veiculo'], 'descricao' => $pedido['descricao'],
        ];
        $credenciais = [
            'standvirtual_stand_id' => $pedido['standvirtual_stand_id'],
            'standvirtual_api_token' => $pedido['standvirtual_api_token'],
        ];

        $resultado = $provider->publicar($veiculo, $credenciais);

        if ($resultado['ok']) {
            $pdo->prepare("UPDATE publicacoes_externas SET estado = 'publicado', referencia_externa = ?, mensagem_erro = NULL WHERE id = ?")
                ->execute([$resultado['referencia_externa'], $pedido['id']]);
        } else {
            $pdo->prepare("UPDATE publicacoes_externas SET estado = 'falhou', mensagem_erro = ? WHERE id = ?")
                ->execute([$resultado['erro'], $pedido['id']]);
        }

        $resultados[$pedido['plataforma']] = $resultado;
    }

    return $resultados;
}

/** Devolve o estado atual de divulgação de um veículo, indexado por plataforma. */
function estadoDivulgacao(PDO $pdo, int $veiculoId): array
{
    $stmt = $pdo->prepare("SELECT * FROM publicacoes_externas WHERE veiculo_id = ?");
    $stmt->execute([$veiculoId]);

    $estados = [];
    foreach ($stmt->fetchAll(PDO::FETCH_ASSOC) as $linha) {
        $estados[$linha['plataforma']] = $linha;
    }
    return $estados;
}
