<?php
require_once __DIR__ . '/SyndicationProvider.php';

/**
 * Adapter para uma eventual API direta da OLX.
 *
 * Nota: em Portugal, publicar um anúncio profissional na Standvirtual
 * já o sincroniza automaticamente com o OLX (mesmo grupo empresarial),
 * pelo que a maioria dos stands não precisa desta integração em separado.
 * Esta classe fica pronta apenas para o caso de vires a contratar uma
 * conta/API OLX totalmente independente da Standvirtual — a estrutura é
 * igual à do StandvirtualProvider, mesmo aviso sobre os placeholders.
 */
class OlxProvider implements SyndicationProvider
{
    private string $apiUrl;

    public function __construct(string $apiUrl)
    {
        $this->apiUrl = rtrim($apiUrl, '/');
    }

    public function publicar(array $veiculo, array $credenciais): array
    {
        return [
            'ok' => false,
            'referencia_externa' => null,
            'erro' => 'Integração direta com a OLX ainda não está configurada (OLX_API_URL vazio no .env). ' .
                      'Normalmente não é necessária: publicar na Standvirtual já publica automaticamente na OLX.',
        ];
    }

    public function remover(string $referenciaExterna, array $credenciais): array
    {
        return ['ok' => false, 'erro' => 'Integração direta com a OLX não está configurada.'];
    }
}
