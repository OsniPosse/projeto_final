<?php
/**
 * Contrato que qualquer integração externa (Standvirtual, OLX, ou outra
 * plataforma que venhas a adicionar) tem de cumprir.
 *
 * Isto é o que torna o sistema "plugável": para adicionar uma nova
 * plataforma basta criar uma classe que implemente esta interface e
 * registá-la em publicacao_externa.php — nenhuma outra parte do código
 * precisa de mudar.
 */
interface SyndicationProvider
{
    /**
     * Publica um veículo na plataforma externa.
     *
     * @param array $veiculo      Linha da tabela `veiculos` (+ dados do vendedor).
     * @param array $credenciais  Credenciais específicas do lojista (token, id da loja, etc.).
     * @return array{ok: bool, referencia_externa: ?string, erro: ?string}
     */
    public function publicar(array $veiculo, array $credenciais): array;

    /**
     * Remove/despublica um anúncio previamente publicado.
     *
     * @return array{ok: bool, erro: ?string}
     */
    public function remover(string $referenciaExterna, array $credenciais): array;
}
