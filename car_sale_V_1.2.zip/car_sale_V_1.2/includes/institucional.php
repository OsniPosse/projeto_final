    <!-- ===================== SOBRE NÓS ===================== -->
    <section id="sobre" class="inst-section inst-section-dark">
        <div class="inst-inner">
            <span class="inst-eyebrow">Sobre nós</span>
            <h1 class="inst-title">A forma mais simples de comprar e vender carros em Portugal</h1>
            <p class="inst-lead">
                A AutoMarket nasceu para ligar, num único sítio, quem procura o próximo carro
                a particulares e a lojistas profissionais. Sem complicações, sem anúncios
                escondidos atrás de paywalls — só carros reais, publicados por pessoas e lojas reais.
            </p>

            <div class="inst-stats">
                <div class="inst-stat">
                    <strong>100%</strong>
                    <span>Gratuito para compradores</span>
                </div>
                <div class="inst-stat">
                    <strong>Particulares &amp; Lojistas</strong>
                    <span>Tudo na mesma plataforma</span>
                </div>
                <div class="inst-stat">
                    <strong>Verificação por email</strong>
                    <span>Contas reais, menos fraude</span>
                </div>
            </div>
        </div>
    </section>

    <!-- ===================== COMO FUNCIONA ===================== -->
    <section id="como-funciona" class="inst-section">
        <div class="inst-inner">
            <span class="inst-eyebrow">Como funciona</span>
            <h2 class="inst-title-light">Três passos, dois lados da mesma plataforma</h2>

            <div class="como-funciona-grid">

                <div class="como-funciona-col">
                    <h3><i class="ti ti-search"></i> Para quem procura um carro</h3>
                    <ol class="inst-steps">
                        <li>
                            <strong>Pesquisa e filtra</strong>
                            <span>Usa a pesquisa ou os filtros (marca, preço, ano, km, câmbio) para encontrar o carro certo.</span>
                        </li>
                        <li>
                            <strong>Compara anúncios</strong>
                            <span>Vê fotos, especificações e o perfil de quem vende — particular ou loja.</span>
                        </li>
                        <li>
                            <strong>Contacta diretamente</strong>
                            <span>Envia um email ao anunciante a partir da própria página do anúncio. Sem intermediários.</span>
                        </li>
                    </ol>
                </div>

                <div class="como-funciona-col">
                    <h3><i class="ti ti-car"></i> Para quem vende ou é lojista</h3>
                    <ol class="inst-steps">
                        <li>
                            <strong>Cria a tua conta</strong>
                            <span>Regista-te (ou entra com a tua conta Google) como anunciante ou como lojista e confirma a tua conta com o código enviado por email.</span>
                        </li>
                        <li>
                            <strong>Publica os teus anúncios</strong>
                            <span>Adiciona fotos, preço e detalhes do veículo em poucos minutos.</span>
                        </li>
                        <li>
                            <strong>Ganha visibilidade</strong>
                            <span>Destaca anúncios na home ou, se fores lojista, mostra a tua loja na área dedicada de lojistas.</span>
                        </li>
                    </ol>
                </div>

            </div>
        </div>
    </section>

    <!-- ===================== PLANOS PARA LOJISTAS ===================== -->
    <section id="planos" class="inst-section inst-section-dark">
        <div class="inst-inner">
            <span class="inst-eyebrow">Planos para lojistas</span>
            <h2 class="inst-title">Escolhe o plano para a tua loja</h2>
            <p class="inst-lead">
                Sem compromisso e sem pagamento neste momento — escolhe o plano que melhor
                descreve a tua loja ao criares a conta. Podes alterar mais tarde no perfil da loja.
            </p>

            <div class="planos-grid">

                <div class="plano-card">
                    <div class="plano-nome">Básico</div>
                    <div class="plano-preco">Grátis</div>
                    <ul class="plano-features">
                        <li><i class="ti ti-check"></i> Perfil de loja na plataforma</li>
                        <li><i class="ti ti-check"></i> Até 10 anúncios ativos</li>
                        <li><i class="ti ti-check"></i> Aparece na área de lojistas</li>
                        <li><i class="ti ti-check"></i> Suporte por email</li>
                    </ul>
                    <a href="<?= BASE_URL ?>/auth/registo.php?perfil=lojista" class="btn-plano">Criar conta lojista</a>
                </div>

                <div class="plano-card plano-destaque">
                    <div class="plano-tag">Mais popular</div>
                    <div class="plano-nome">Profissional</div>
                    <div class="plano-preco">€19,90<span>/mês</span></div>
                    <ul class="plano-features">
                        <li><i class="ti ti-check"></i> Tudo do plano Básico</li>
                        <li><i class="ti ti-check"></i> Até 30 anúncios ativos</li>
                        <li><i class="ti ti-check"></i> Selo "Loja verificada"</li>
                        <li><i class="ti ti-check"></i> Destaque na área de lojistas</li>
                        <li><i class="ti ti-check"></i> Suporte prioritário</li>
                    </ul>
                    <a href="<?= BASE_URL ?>/auth/registo.php?perfil=lojista" class="btn-plano btn-plano-destaque">Criar conta lojista</a>
                </div>

                <div class="plano-card">
                    <div class="plano-nome">Premium</div>
                    <div class="plano-preco">€39,90<span>/mês</span></div>
                    <ul class="plano-features">
                        <li><i class="ti ti-check"></i> Tudo do plano Profissional</li>
                        <li><i class="ti ti-check"></i> Anúncios ilimitados</li>
                        <li><i class="ti ti-check"></i> Destaque permanente na home</li>
                        <li><i class="ti ti-check"></i> Gestor de conta dedicado</li>
                    </ul>
                    <a href="<?= BASE_URL ?>/auth/registo.php?perfil=lojista" class="btn-plano">Criar conta lojista</a>
                </div>

            </div>
        </div>
    </section>
