<?php
/**
 * Helpers para o código de verificação de conta por email.
 */

require_once __DIR__ . "/mailer.php";

/** Gera um código numérico de 6 dígitos. */
function gerarCodigoVerificacao(): string
{
    return str_pad((string) random_int(0, 999999), 6, '0', STR_PAD_LEFT);
}

/**
 * Gera um novo código, grava-o no utilizador e envia-o por email.
 * Usado tanto no registo como no "reenviar código".
 *
 * @return array{ok: bool, erro: ?string}
 */
function gerarEEnviarCodigo(PDO $pdo, int $userId, string $email, string $nome): array
{
    $codigo = gerarCodigoVerificacao();
    $expira = date("Y-m-d H:i:s", strtotime("+15 minutes"));

    $pdo->prepare("UPDATE utilizadores SET codigo_verificacao = ?, codigo_expira = ? WHERE id = ?")
        ->execute([$codigo, $expira, $userId]);

    return enviarCodigoVerificacao($email, $nome, $codigo);
}
