<?php
/**
 * Funções centrais de sessão / autenticação.
 *
 * Substitui os blocos repetidos
 *      if (!isset($_SESSION["user_id"])) { header("Location: index.php"); exit; }
 * que estavam copiados em vários ficheiros (novo_anuncio.php, meus_anuncios.php,
 * editar_anuncio.php, remover_anuncio.php, processa_anuncio.php,
 * processa_edicao.php, editar_loja.php, lojista.php, anuncios_top.php...).
 *
 * Regra de acesso da plataforma:
 *   - Visitante (sem sessão) -> só pode VISUALIZAR (home, pesquisa, detalhes,
 *     página da loja). Qualquer ação (criar anúncio, editar loja, etc.)
 *     exige login.
 *   - Utilizador autenticado -> "comprador", "anunciante" ou "lojista" são
 *     apenas um perfil dentro da mesma conta (tabela utilizadores.perfil),
 *     não contas/tabelas diferentes.
 */

/** Devolve os dados do utilizador autenticado, ou null se for visitante. */
function utilizadorAtual(): ?array
{
    if (!isset($_SESSION['user_id'])) {
        return null;
    }

    return [
        'id'     => (int) $_SESSION['user_id'],
        'nome'   => $_SESSION['user_nome'] ?? '',
        'perfil' => $_SESSION['user_perfil'] ?? '',
    ];
}

/** true se existir uma sessão de utilizador válida. */
function estaLogado(): bool
{
    return isset($_SESSION['user_id']);
}

/**
 * Bloqueia o acesso de visitantes não autenticados.
 * Usar no topo de qualquer página/ação que exija login
 * (criar/editar/remover anúncio, editar loja, etc.).
 */
function exigirLogin(): void
{
    if (!estaLogado()) {
        header('Location: ' . BASE_URL . '/index.php?login_necessario=1');
        exit;
    }
}

/**
 * Bloqueia o acesso a quem não tiver um dos perfis indicados.
 * Ex: exigirPerfil('lojista');
 */
function exigirPerfil(string ...$perfisPermitidos): void
{
    exigirLogin();

    $perfil = $_SESSION['user_perfil'] ?? '';
    if (!in_array($perfil, $perfisPermitidos, true)) {
        http_response_code(403);
        header('Location: ' . BASE_URL . '/index.php');
        exit;
    }
}

/** Regista a sessão de um utilizador autenticado (login normal ou Google). */
function iniciarSessaoUtilizador(array $user): void
{
    $_SESSION['user_id']     = (int) $user['id'];
    $_SESSION['user_nome']   = $user['nome'];
    $_SESSION['user_perfil'] = $user['perfil'];
}
