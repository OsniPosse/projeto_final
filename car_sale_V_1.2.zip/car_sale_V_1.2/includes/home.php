<?php
// $pdo já vem do bootstrap — não é preciso voltar a ligar à BD aqui.

$sql = "SELECT
            t.id AS top_id,
            v.id AS veiculo_id,
            v.marca,
            v.modelo,
            v.ano,
            v.quilometragem,
            v.preco,
            v.combustivel,
            v.cambio,
            f.url AS foto_principal
        FROM anuncios_top t
        JOIN veiculos v ON v.id = t.veiculo_id
        LEFT JOIN fotos f ON f.veiculo_id = v.id AND f.is_principal = 1
        WHERE t.ativo = 1
          AND t.inicio <= CURDATE()
          AND t.fim >= CURDATE()
        ORDER BY t.id DESC
        LIMIT 10";

$stmt = $pdo->prepare($sql);
$stmt->execute();
$top = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>


<!-- BANNER TOP -->

<div class="banner-top">

    <div class="banner-label"><i class="ti ti-crown"></i> Anúncios em destaque</div>

    <div class="banner-title">Veículos em destaque</div>
    <div class="banner-sub">Tenha máxima visibilidade em seu anúncio</div>

    <div class="banner-cards">

<?php if (!empty($top)): ?>
    <?php foreach ($top as $t): ?>

        <a href="<?= BASE_URL ?>/anuncios/detalhes.php?id=<?= (int)$t['veiculo_id'] ?>" class="top-card">

            <div class="top-card-img">
                <?php if (!empty($t["foto_principal"])): ?>
                    <img src="<?= BASE_URL . '/' . htmlspecialchars($t['foto_principal']) ?>" style="width:100%;height:100%;object-fit:cover;">
                <?php else: ?>
                    <i class="ti ti-car"></i>
                <?php endif; ?>

                <div class="crown">TOP</div>
            </div>

            <div class="top-card-info">
                <div class="tc-name"><?= htmlspecialchars($t['marca'] . " " . $t['modelo'] . " " . $t['ano']) ?></div>
                <div class="tc-price">€<?= number_format($t['preco'], 2, ',', '.') ?></div>
                <div class="tc-detail">
                    <?= number_format($t['quilometragem'], 0, ',', '.') ?> km ·
                    <?= htmlspecialchars(ucfirst($t['combustivel'])) ?> ·
                    <?= htmlspecialchars(ucfirst($t['cambio'])) ?>
                </div>
            </div>

        </a>

    <?php endforeach; ?>
<?php else: ?>
    <p>Sem anúncios em destaque no momento.</p>
<?php endif; ?>

</div>

</div>

<!-- FILTERS -->
<?php
require_once BASE_PATH . '/includes/filtro.php';

$query = obterFiltrosVeiculos($_GET);
$stmtRecentes = $pdo->prepare($query['sql']);
$stmtRecentes->execute($query['params']);
$recentes = $stmtRecentes->fetchAll(PDO::FETCH_ASSOC);

$f = $query['filtros'];
$tipoAtual = $f['tipo'] !== '' ? $f['tipo'] : 'carro';

$taxonomia = require BASE_PATH . '/config/veiculos_taxonomia.php';
$distritos = require BASE_PATH . '/config/distritos.php';
$faixas    = require BASE_PATH . '/config/faixas_filtro.php';

function chipClass(string $estadoAtual, string $estadoChip): string {
    return 'filter-chip' . ($estadoAtual === $estadoChip || ($estadoAtual === '' && $estadoChip === 'todos') ? ' active' : '');
}

function tipoTabClass(string $tipoAtual, string $tipoAba): string {
    return 'tipo-tab' . ($tipoAtual === $tipoAba ? ' active' : '');
}
?>

<!-- SEPARADORES CARROS / MOTAS / PESADOS -->
<div class="tipo-tabs">
    <?php foreach ($taxonomia as $chaveTipo => $dadosTipo): ?>
        <a href="<?= BASE_URL ?>/index.php?tipo=<?= $chaveTipo ?>" class="<?= tipoTabClass($tipoAtual, $chaveTipo) ?>">
            <i class="ti <?= ['carro' => 'ti-car', 'mota' => 'ti-motorbike', 'pesado' => 'ti-truck'][$chaveTipo] ?? 'ti-car' ?>"></i>
            <?= htmlspecialchars($dadosTipo['nome']) ?>
        </a>
    <?php endforeach; ?>
</div>

<!-- FILTER BAR -->
<form method="GET" action="<?= BASE_URL ?>/index.php" class="filter-bar">
    <input type="hidden" name="tipo" value="<?= htmlspecialchars($tipoAtual) ?>">
    <span class="filter-label"><i class="ti ti-filter"></i> Filtros:</span>

    <a href="<?= BASE_URL ?>/index.php?tipo=<?= $tipoAtual ?>" class="<?= chipClass($f['estado'], 'todos') ?>">
        <i class="ti ti-list"></i> Todos
    </a>
    <a href="<?= BASE_URL ?>/index.php?tipo=<?= $tipoAtual ?>&estado=novo" class="<?= chipClass($f['estado'], 'novo') ?>">Novos</a>
    <a href="<?= BASE_URL ?>/index.php?tipo=<?= $tipoAtual ?>&estado=usado" class="<?= chipClass($f['estado'], 'usado') ?>">Usados</a>

    <!-- Painel expandível de filtros -->
    <div class="filter-advanced">
        <details <?= ($f['marca'] || $f['distrito'] || $f['preco_max'] || $f['ano_min'] || $f['km_max'] || $f['cambio']) ? 'open' : '' ?>>
            <summary class="filter-chip"><i class="ti ti-adjustments"></i> Mais filtros</summary>
            <div class="filter-panel">

                <label>Marca
                    <select name="marca" id="filtroMarca">
                        <option value="">Todas</option>
                        <?php foreach (($taxonomia[$tipoAtual]['marcas'] ?? []) as $marca => $modelos): ?>
                            <option value="<?= htmlspecialchars($marca) ?>" <?= $f['marca'] === $marca ? 'selected' : '' ?>>
                                <?= htmlspecialchars($marca) ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                </label>

                <label>Modelo
                    <input type="text" name="modelo" id="filtroModelo" list="listaModelos" value="<?= htmlspecialchars($f['modelo']) ?>" placeholder="Todos">
                    <datalist id="listaModelos"></datalist>
                </label>

                <label>Distrito
                    <select name="distrito">
                        <option value="">Todos</option>
                        <?php foreach ($distritos as $distrito): ?>
                            <option value="<?= htmlspecialchars($distrito) ?>" <?= $f['distrito'] === $distrito ? 'selected' : '' ?>>
                                <?= htmlspecialchars($distrito) ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                </label>

                <label>Preço até
                    <select name="preco_max">
                        <option value="">Sem limite</option>
                        <?php foreach ($faixas['preco'] as $valor): ?>
                            <option value="<?= $valor ?>" <?= (string)$f['preco_max'] === (string)$valor ? 'selected' : '' ?>>€<?= number_format($valor, 0, ',', '.') ?></option>
                        <?php endforeach; ?>
                    </select>
                </label>

                <label>Ano desde
                    <select name="ano_min">
                        <option value="">Sem limite</option>
                        <?php foreach ($faixas['ano'] as $ano): ?>
                            <option value="<?= $ano ?>" <?= (string)$f['ano_min'] === (string)$ano ? 'selected' : '' ?>><?= $ano ?></option>
                        <?php endforeach; ?>
                    </select>
                </label>

                <label>Km até
                    <select name="km_max">
                        <option value="">Sem limite</option>
                        <?php foreach ($faixas['km'] as $valor): ?>
                            <option value="<?= $valor ?>" <?= (string)$f['km_max'] === (string)$valor ? 'selected' : '' ?>><?= number_format($valor, 0, ',', '.') ?> km</option>
                        <?php endforeach; ?>
                    </select>
                </label>

                <?php if ($tipoAtual !== 'pesado'): ?>
                <label>Câmbio
                    <select name="cambio">
                        <option value="">Todos</option>
                        <option value="manual" <?= $f['cambio'] === 'manual' ? 'selected' : '' ?>>Manual</option>
                        <option value="automatico" <?= $f['cambio'] === 'automatico' ? 'selected' : '' ?>>Automático</option>
                    </select>
                </label>
                <?php endif; ?>

                <label>Combustível
                    <select name="combustivel">
                        <option value="">Todos</option>
                        <option value="gasolina" <?= $f['combustivel'] === 'gasolina' ? 'selected' : '' ?>>Gasolina</option>
                        <option value="diesel" <?= $f['combustivel'] === 'diesel' ? 'selected' : '' ?>>Diesel</option>
                        <option value="eletrico" <?= $f['combustivel'] === 'eletrico' ? 'selected' : '' ?>>Elétrico</option>
                        <option value="hibrido" <?= $f['combustivel'] === 'hibrido' ? 'selected' : '' ?>>Híbrido</option>
                        <option value="gpl" <?= $f['combustivel'] === 'gpl' ? 'selected' : '' ?>>GPL</option>
                    </select>
                </label>

                <?php if ($f['estado']): ?>
                    <input type="hidden" name="estado" value="<?= htmlspecialchars($f['estado']) ?>">
                <?php endif; ?>
                <button type="submit" class="btn-filter">Aplicar</button>
            </div>
        </details>
    </div>

    <select name="ordenar" class="filter-sort" onchange="this.form.submit()">
        <option value="recentes" <?= $f['ordenar'] === 'recentes' ? 'selected' : '' ?>>Mais recentes</option>
        <option value="preco_asc" <?= $f['ordenar'] === 'preco_asc' ? 'selected' : '' ?>>Preço ↑</option>
        <option value="preco_desc" <?= $f['ordenar'] === 'preco_desc' ? 'selected' : '' ?>>Preço ↓</option>
        <option value="ano_desc" <?= $f['ordenar'] === 'ano_desc' ? 'selected' : '' ?>>Ano ↓</option>
    </select>
</form>

<script>
(function () {
    // Gerado a partir de config/veiculos_taxonomia.php — alimenta o datalist de modelos
    // conforme a marca escolhida, para o tipo de veículo atual (<?= htmlspecialchars($tipoAtual) ?>).
    const marcasModelos = <?= json_encode($taxonomia[$tipoAtual]['marcas'] ?? [], JSON_UNESCAPED_UNICODE) ?>;

    const selectMarca = document.getElementById('filtroMarca');
    const datalistModelos = document.getElementById('listaModelos');

    function atualizarModelos() {
        const modelos = marcasModelos[selectMarca.value] || [];
        datalistModelos.innerHTML = modelos.map(m => `<option value="${m}">`).join('');
    }

    if (selectMarca) {
        selectMarca.addEventListener('change', atualizarModelos);
        atualizarModelos();
    }
})();
</script>

<!-- GALLERY -->
<div class="gallery">
    <div class="gallery-header">
        <span class="gallery-title">Anúncios recentes</span>
        <span class="gallery-count"><?= count($recentes) ?> veículos encontrados</span>
    </div>

    <div class="cars-grid">
        <?php if (empty($recentes)): ?>
            <p class="sem-resultados">Nenhum veículo encontrado com estes filtros.</p>
        <?php else: ?>
            <?php foreach ($recentes as $carro): ?>
                <?php include BASE_PATH . '/includes/card_veiculo.php'; ?>
            <?php endforeach; ?>
        <?php endif; ?>
    </div>
</div>

<!-- ÁREA DE LOJISTAS -->
<?php
$sqlLojistas = "
    SELECT u.id, u.nome_loja, u.descricao_loja, u.logo_loja, u.cidade, u.plano_lojista,
           (SELECT COUNT(*) FROM veiculos WHERE utilizador_id = u.id) AS total_anuncios
    FROM utilizadores u
    WHERE u.perfil = 'lojista' AND u.verificado = 1
    ORDER BY FIELD(u.plano_lojista, 'premium', 'profissional', 'basico'), total_anuncios DESC, u.id DESC
    LIMIT 8
";
$stmtLojistas = $pdo->query($sqlLojistas);
$lojistas = $stmtLojistas->fetchAll(PDO::FETCH_ASSOC);
?>
<div id="stands" class="lojistas-section">
    <div class="lojistas-banner">

        <div class="lojistas-banner-header">
            <div>
                <div class="lojistas-label"><i class="ti ti-building-store"></i> Stands</div>
                <div class="banner-title">Stands em destaque</div>
                <div class="banner-sub">Profissionais verificados, com anúncios atualizados todos os dias</div>
            </div>
            <a href="<?= BASE_URL ?>/index.php#planos" class="lojistas-cta">Anuncia a tua loja aqui →</a>
        </div>

        <?php if (empty($lojistas)): ?>
            <div class="lojistas-vazio">
                <i class="ti ti-building-store"></i>
                <p>Ainda não há lojas registadas. Sê o primeiro lojista na AutoMarket.</p>
                <a href="<?= BASE_URL ?>/auth/registo.php?perfil=lojista" class="btn-anunciar">Criar conta lojista</a>
            </div>
        <?php else: ?>
            <div class="lojistas-cards">
                <?php foreach ($lojistas as $loja): ?>
                    <a href="<?= BASE_URL ?>/loja/lojista.php?id=<?= (int)$loja['id'] ?>" class="loja-card-top">
                        <div class="loja-card-avatar">
                            <?php if (!empty($loja['logo_loja'])): ?>
                                <img src="<?= BASE_URL . '/' . htmlspecialchars($loja['logo_loja']) ?>" alt="">
                            <?php else: ?>
                                <i class="ti ti-building-store"></i>
                            <?php endif; ?>
                        </div>
                        <div class="loja-card-info">
                            <div class="loja-card-nome"><?= htmlspecialchars($loja['nome_loja']) ?></div>
                            <div class="loja-card-meta">
                                <?php if (!empty($loja['cidade'])): ?><?= htmlspecialchars($loja['cidade']) ?> · <?php endif; ?><?= (int)$loja['total_anuncios'] ?> anúncios
                            </div>
                        </div>
                        <?php if (in_array($loja['plano_lojista'], ['premium', 'profissional'], true)): ?>
                            <span class="loja-card-badge"><i class="ti ti-star"></i></span>
                        <?php endif; ?>
                    </a>
                <?php endforeach; ?>
            </div>
        <?php endif; ?>

    </div>
</div>
