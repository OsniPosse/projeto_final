<?php
require_once __DIR__ . '/../config/bootstrap.php';


session_start();

if (!isset($_SESSION["user_id"])) {
    header("Location: " . BASE_URL . "/auth/login.php?redirect=" . urlencode(BASE_URL . "/anuncios/detalhes.php?id=" . (int)($_POST["veiculo_id"] ?? 0)));
    exit;
}



$remetente_id    = $_SESSION["user_id"];
$destinatario_id = (int)$_POST["destinatario_id"];
$veiculo_id      = (int)$_POST["veiculo_id"];
$mensagem        = trim($_POST["mensagem"]);

// Validação
if (empty($mensagem)) {
    die("A mensagem não pode estar vazia.");
}

// Impede enviar mensagem para si próprio
if ($remetente_id == $destinatario_id) {
    die("Não pode enviar mensagens para si próprio.");
}

// Verifica se o veículo pertence ao destinatário
$sql = "SELECT id
        FROM veiculos
        WHERE id = ? AND utilizador_id = ?";

$stmt = $pdo->prepare($sql);
$stmt->execute([$veiculo_id, $destinatario_id]);

if (!$stmt->fetch()) {
    die("Anúncio inválido.");
}

//protege de mensagem com script
$mensagem = trim($_POST["mensagem"]);

$mensagem = strip_tags($mensagem);

$mensagem = substr($mensagem, 0, 1000);

//evitar mensagem longa
if (strlen($mensagem) > 1000) {
    die("A mensagem é demasiado longa.");
}

//proteção contra Spam
$sql = "SELECT id
        FROM mensagens
        WHERE remetente_id = ?
        AND veiculo_id = ?
        AND enviada_em > DATE_SUB(NOW(), INTERVAL 2 MINUTE)";

$stmt = $pdo->prepare($sql);
$stmt->execute([$remetente_id, $veiculo_id]);

if ($stmt->fetch()) {
    die("Aguarde alguns minutos antes de enviar outra mensagem.");
}

//evitar mensagem fazia
if (strlen(trim($mensagem)) < 5) {
    die("Escreva uma mensagem válida.");
}

// Guarda a mensagem
$sql = "INSERT INTO mensagens
        (remetente_id, destinatario_id, veiculo_id, conteudo)
        VALUES (?, ?, ?, ?)";

$stmt = $pdo->prepare($sql);
$stmt->execute([
    $remetente_id,
    $destinatario_id,
    $veiculo_id,
    $mensagem
]);

// Volta ao anúncio
header("Location: " . BASE_URL . "/anuncios/detalhes.php?id=" . $veiculo_id . "&msg=enviada");
exit;