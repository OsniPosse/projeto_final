
<?php
require_once __DIR__ . '/../config/bootstrap.php';

if (!isset($_SESSION["user_id"])) {
    header("Location: " . BASE_URL . "/index.php?login_necessario=1");
    exit;
}

$user_id = $_SESSION["user_id"];

require_once BASE_PATH . '/includes/header.php';

$sqlAnuncios = "
    SELECT v.*,
           (SELECT url
            FROM fotos
            WHERE veiculo_id = v.id
              AND is_principal = 1
            LIMIT 1) AS foto
    FROM veiculos v
    WHERE v.utilizador_id = ?
    ORDER BY v.criado_em DESC
";

$stmtAnuncios = $pdo->prepare($sqlAnuncios);
$stmtAnuncios->execute([$user_id]);
$anuncios = $stmtAnuncios->fetchAll(PDO::FETCH_ASSOC);

$sqlMensagens = "
SELECT
    m.*,
    u.nome AS comprador,
    v.marca,
    v.modelo
FROM mensagens m
JOIN utilizadores u ON u.id = m.remetente_id
JOIN veiculos v ON v.id = m.veiculo_id
WHERE m.destinatario_id = ?
ORDER BY m.enviada_em DESC
";
$stmtMensagens = $pdo->prepare($sqlMensagens);
$stmtMensagens->execute([$user_id]);
$mensagens = $stmtMensagens->fetchAll(PDO::FETCH_ASSOC);
?>


<div>
    <h2 style="margin-top:40px;">Mensagens Recebidas</h2>

<?php if (empty($mensagens)): ?>

<p>Ainda não recebeu mensagens.</p>

<?php else: ?>

<?php foreach ($mensagens as $m): ?>


<div class="car-card" style="padding:20px;margin-bottom:15px;">
    <strong><?= htmlspecialchars($m['comprador']) ?></strong>
    <br>

    <small>
        Interesse em
        <?= htmlspecialchars($m['marca']." ".$m['modelo']) ?>
    </small>

    <p style="margin-top:10px;">
        <?= nl2br(htmlspecialchars($m['conteudo'])) ?>
    </p>

    <form action="<?= BASE_URL ?>/mensagens/responder_mensagem.php" method="post" style="margin-top:15px;">
    <input type="hidden" name="destinatario_id" value="<?= $m['remetente_id'] ?>">
    <input type="hidden" name="veiculo_id" value="<?= $m['veiculo_id'] ?>">

    <textarea name="mensagem" required
              placeholder="Escreva sua resposta..."
              style="width:100%;padding:10px;margin-bottom:10px;"></textarea>

    <button type="submit" class="btn-login"
            style="background:#4f7ef7;color:#fff;">
        <i class="ti ti-send"></i> Responder
    </button>
</form>


    <small><?= date('d/m/Y H:i', strtotime($m['enviada_em'])) ?></small>
    <form action="<?= BASE_URL ?>/mensagens/apagar_mensagem.php" method="post"
      onsubmit="return confirm('Deseja apagar esta mensagem?');">

    <input type="hidden" name="id" value="<?= $m['id'] ?>">

    <button type="submit" class="btn-login"
            style="background:#e63946;color:#fff;">
        <i class="ti ti-trash"></i> Apagar
    </button>

</form>
</div>

<?php endforeach; ?>

<?php endif; ?>
</div>

<?php include BASE_PATH . '/includes/footer.php'; ?>
