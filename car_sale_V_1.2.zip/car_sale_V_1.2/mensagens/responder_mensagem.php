<?php
require_once __DIR__ . '/../config/bootstrap.php';

session_start();

if (!isset($_SESSION["user_id"])) {
    header("Location: " . BASE_URL . "/index.php");
    exit;
}

$remetente_id = $_SESSION["user_id"];
$destinatario_id = (int)($_POST["destinatario_id"] ?? 0);
$veiculo_id = (int)($_POST["veiculo_id"] ?? 0);
$mensagem = trim($_POST["mensagem"] ?? "");
$mensagem = strip_tags(substr($mensagem, 0, 1000));

if ($mensagem === "") {
    die("Mensagem vazia.");
}

$sql = "
    INSERT INTO mensagens (remetente_id, destinatario_id, veiculo_id, conteudo, enviada_em)
    VALUES (?, ?, ?, ?, NOW())
";

$stmt = $pdo->prepare($sql);
$stmt->execute([$remetente_id, $destinatario_id, $veiculo_id, $mensagem]);

header("Location: " . BASE_URL . "/anuncios/meus_anuncios.php?resposta=ok");
exit;
