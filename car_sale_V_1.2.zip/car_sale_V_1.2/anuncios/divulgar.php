<?php
require_once __DIR__ . '/../config/bootstrap.php';
exigirPerfil('lojista'); // só contas profissionais (lojista) têm acesso à API da Standvirtual
require_once BASE_PATH . '/includes/sync/publicacao_externa.php';

$id = (int) ($_GET['id'] ?? 0);
$user_id = $_SESSION['user_id'];

$stmt = $pdo->prepare("SELECT * FROM veiculos WHERE id = ? AND utilizador_id = ?");
$stmt->execute([$id, $user_id]);
$carro = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$carro) {
    die("Acesso negado.");
}

$plataformas = plataformasDivulgacao();
$estados     = estadoDivulgacao($pdo, $id);

$stmtLoja = $pdo->prepare("SELECT standvirtual_stand_id, standvirtual_api_token FROM utilizadores WHERE id = ?");
$stmtLoja->execute([$user_id]);
$loja = $stmtLoja->fetch(PDO::FETCH_ASSOC);
$temCredenciaisStandvirtual = !empty($loja['standvirtual_stand_id']) && !empty($loja['standvirtual_api_token']);

require BASE_PATH . '/includes/header.php';
?>

<div class="register-container register-container-wide">
    <h2>Divulgar anúncio externamente</h2>
    <p class="lojista-fields-nota">
        <?= htmlspecialchars($carro['marca'] . ' ' . $carro['modelo'] . ' (' . $carro['ano'] . ')') ?>
    </p>

    <?php if (!$temCredenciaisStandvirtual): ?>
        <p class="erro">
            Ainda não configuraste o token da Standvirtual para esta loja.
            <a href="<?= BASE_URL ?>/loja/integracoes.php">Configurar agora</a>.
        </p>
    <?php endif; ?>

    <form method="POST" action="<?= BASE_URL ?>/anuncios/processa_divulgacao.php" class="register-form">
        <input type="hidden" name="veiculo_id" value="<?= $id ?>">

        <?php foreach ($plataformas as $chave => $p): ?>
            <?php $estadoAtual = $estados[$chave]['estado'] ?? null; ?>
            <label class="campo-checkbox">
                <input type="checkbox" name="plataformas[]" value="<?= htmlspecialchars($chave) ?>"
                    <?= $estadoAtual === 'publicado' ? 'disabled' : '' ?>
                    <?= in_array($estadoAtual, ['pago','falhou'], true) ? 'checked' : '' ?>>
                <?= htmlspecialchars($p['nome']) ?> — €<?= number_format($p['preco_cents'] / 100, 2, ',', '.') ?>

                <?php if ($estadoAtual === 'publicado'): ?>
                    <span class="badge-sync badge-sync-ok"><i class="ti ti-check"></i> Publicado</span>
                <?php elseif ($estadoAtual === 'falhou'): ?>
                    <span class="badge-sync badge-sync-erro" title="<?= htmlspecialchars($estados[$chave]['mensagem_erro'] ?? '') ?>">
                        <i class="ti ti-alert-triangle"></i> Falhou — tentar novamente
                    </span>
                <?php elseif ($estadoAtual === 'pago'): ?>
                    <span class="badge-sync badge-sync-pendente"><i class="ti ti-clock"></i> A publicar</span>
                <?php endif; ?>
            </label>
        <?php endforeach; ?>

        <button type="submit">Continuar para pagamento</button>
    </form>

    <a href="<?= BASE_URL ?>/anuncios/meus_anuncios.php" class="btn-link" style="display:block;margin-top:12px;">
        Saltar por agora
    </a>
</div>

<?php require BASE_PATH . '/includes/footer.php'; ?>
