<?php
require_once __DIR__ . '/../config/bootstrap.php';
exigirLogin();

$taxonomia = require BASE_PATH . '/config/veiculos_taxonomia.php';
$distritos = require BASE_PATH . '/config/distritos.php';

require BASE_PATH . '/includes/header.php';
?>

<div class="register-container">
    <h2>Criar Anúncio</h2>

    <?php if (isset($_SESSION["anuncio_erro"])): ?>
        <p class="erro"><?= $_SESSION["anuncio_erro"] ?></p>
        <?php unset($_SESSION["anuncio_erro"]); ?>
    <?php endif; ?>

    <form action="<?= BASE_URL ?>/anuncios/processa_anuncio.php" method="POST" enctype="multipart/form-data" class="register-form" id="formAnuncio">
        <label> Destacar anúncio por 5€ /semana (opcional)
    <input type="checkbox" name="destaque" value="1" >

</label>

        <label class="campo-label">Tipo de veículo
            <select name="tipo_veiculo" id="selectTipo" required>
                <?php foreach ($taxonomia as $chaveTipo => $dadosTipo): ?>
                    <option value="<?= $chaveTipo ?>"><?= htmlspecialchars($dadosTipo['nome']) ?></option>
                <?php endforeach; ?>
            </select>
        </label>

        <label class="campo-label">Marca
            <select name="marca_select" id="selectMarca" required>
                <option value="">Escolha a marca</option>
            </select>
        </label>
        <input type="text" name="marca_outra" id="inputMarcaOutra" placeholder="Escreva a marca" style="display:none;">

        <input type="text" name="modelo" id="inputModelo" list="listaModelos" placeholder="Modelo" required>
        <datalist id="listaModelos"></datalist>

        <input type="number" name="ano" id="ano" placeholder="Ano" required>
        <input type="number" name="quilometragem" id="quilometragem" placeholder="Quilometragem" required>

        <input type="number" step="0.01" name="preco" placeholder="Preço (€)" required>

        <select name="combustivel" id="combustivel" required>
            <option value="">Combustível</option>
            <option value="gasolina">Gasolina</option>
            <option value="diesel">Diesel</option>
            <option value="eletrico">Elétrico</option>
            <option value="hibrido">Híbrido</option>
            <option value="gpl">GPL</option>
        </select>

        <div id="campoCambio">
            <select name="cambio" id="selectCambio">
                <option value="">Câmbio</option>
                <option value="manual">Manual</option>
                <option value="automatico">Automático</option>
            </select>
        </div>

        <div id="campoCilindrada" style="display:none;">
            <input type="number" name="cilindrada" placeholder="Cilindrada (cc)">
        </div>

        <div id="camposPesado" style="display:none;">
            <input type="number" name="capacidade_carga_kg" placeholder="Capacidade de carga (kg)">
            <input type="number" name="numero_eixos" placeholder="Número de eixos">
        </div>

        <select name="estado" id="estado" required>
            <option value="">Estado</option>
            <option value="novo">Novo</option>
            <option value="seminovo">Seminovo</option>
            <option value="usado">Usado</option>
        </select>

        <label class="campo-label">Distrito
            <select name="distrito" id="distrito">
                <option value="">Selecione o distrito</option>
                <?php foreach ($distritos as $distrito): ?>
                    <option value="<?= htmlspecialchars($distrito) ?>"><?= htmlspecialchars($distrito) ?></option>
                <?php endforeach; ?>
            </select>
        </label>

        <textarea name="descricao" id="descricao" placeholder="Descrição do veículo" rows="6"></textarea>

        <label>Fotos do veículo (pode enviar várias):</label>
        <input type="file" name="fotos[]" id="inputFotos" multiple accept="image/*">

        <button type="button" id="btnGerarDescricao" class="btn-google" style="margin-top:6px;">
            <i class="ti ti-sparkles"></i> Gerar descrição automaticamente
        </button>
        <p class="lojista-fields-nota" id="notaGerarDescricao" style="display:none;"></p>

        <button type="submit">Publicar Anúncio</button>
    </form>
</div>

<script>
(function () {
    const taxonomia = <?= json_encode($taxonomia, JSON_UNESCAPED_UNICODE) ?>;

    const selectTipo   = document.getElementById('selectTipo');
    const selectMarca  = document.getElementById('selectMarca');
    const inputOutra   = document.getElementById('inputMarcaOutra');
    const inputModelo  = document.getElementById('inputModelo');
    const listaModelos = document.getElementById('listaModelos');
    const campoCambio      = document.getElementById('campoCambio');
    const campoCilindrada  = document.getElementById('campoCilindrada');
    const camposPesado     = document.getElementById('camposPesado');

    function popularMarcas() {
        const marcas = Object.keys(taxonomia[selectTipo.value].marcas);
        selectMarca.innerHTML = '<option value="">Escolha a marca</option>' +
            marcas.map(m => `<option value="${m}">${m}</option>`).join('');
        atualizarModelos();
        inputOutra.style.display = 'none';
    }

    function atualizarModelos() {
        const modelos = taxonomia[selectTipo.value].marcas[selectMarca.value] || [];
        listaModelos.innerHTML = modelos.map(m => `<option value="${m}">`).join('');
    }

    function atualizarCamposPorTipo() {
        const tipo = selectTipo.value;
        const selectCambio = document.getElementById('selectCambio');

        campoCambio.style.display = tipo === 'pesado' ? 'none' : 'block';
        selectCambio.required = tipo !== 'pesado';
        if (tipo === 'pesado') { selectCambio.value = ''; }

        campoCilindrada.style.display = tipo === 'mota' ? 'block' : 'none';
        camposPesado.style.display = tipo === 'pesado' ? 'block' : 'none';
    }

    selectTipo.addEventListener('change', function () {
        popularMarcas();
        atualizarCamposPorTipo();
    });

    selectMarca.addEventListener('change', function () {
        atualizarModelos();
        inputOutra.style.display = selectMarca.value === 'Outra marca' ? 'block' : 'none';
    });

    popularMarcas();
    atualizarCamposPorTipo();

    // Antes de submeter: se marca = "Outra marca", usa o texto livre
    document.getElementById('formAnuncio').addEventListener('submit', function () {
        if (selectMarca.value === 'Outra marca' && inputOutra.value.trim() !== '') {
            selectMarca.value = inputOutra.value.trim();
            const opt = document.createElement('option');
            opt.value = inputOutra.value.trim();
            opt.selected = true;
            selectMarca.appendChild(opt);
        }
    });

    
})();
</script>
<script>
    const BASE_URL = "<?= BASE_URL ?>";
    console.log(BASE_URL);
</script>

<script src="<?= BASE_URL ?>/assets/js/ai.js"></script>
<?php require BASE_PATH . '/includes/footer.php'; ?>
