<?php

session_start();
require_once __DIR__ . '/../config/bootstrap.php';



if (!isset($_SESSION["user_id"])) {
    header("Location: " . BASE_URL . "/auth/login.php?redirect=" . urlencode(BASE_URL . "/anuncios/favoritos.php"));
    exit;
}

$utilizador_id = $_SESSION["user_id"];

// buscar favoritos
$sql = "SELECT v.*, 
        (SELECT url FROM fotos f 
         WHERE f.veiculo_id = v.id 
         ORDER BY is_principal DESC, id ASC LIMIT 1) AS foto
        FROM favoritos fav
        JOIN veiculos v ON v.id = fav.veiculo_id
        WHERE fav.utilizador_id = ?
        ORDER BY v.id DESC";

$stmt = $pdo->prepare($sql);
$stmt->execute([$utilizador_id]);
$favoritos = $stmt->fetchAll(PDO::FETCH_ASSOC);


?>
<?php include BASE_PATH . '/includes/header.php'; ?>

<main class="favoritos-page">

    <h1 class="page-title">Meus Favoritos ❤️</h1>

    <?php if (empty($favoritos)): ?>
        <div class="no-favs">
            <i class="ti ti-heart-off"></i>
            <p>Não tem veículos favoritos ainda.</p>
            <a href="<?= BASE_URL ?>/index.php" class="btn-voltar">Ver anúncios</a>
        </div>
    <?php else: ?>

        <div class="cars-grid">

            <?php foreach ($favoritos as $v): ?>
                <div class="car-card">

                    <a href="detalhes.php?id=<?= $v['id'] ?>" class="car-img">
                        <?php if ($v['foto']): ?>
                            <img src="<?= BASE_URL . '/' . htmlspecialchars($v['foto']) ?>" alt="">
                        <?php else: ?>
                            <i class="ti ti-car"></i>
                        <?php endif; ?>
                        <span class="car-badge badge-used"><?= ucfirst($v['estado']) ?></span>
                    </a>

                    <div class="car-info">
                        <div class="car-name">
                            <?= htmlspecialchars($v['marca'] . " " . $v['modelo']) ?>
                        </div>

                        <div class="car-specs">
                            <?= (int)$v['ano'] ?> ·
                            <?= number_format($v['quilometragem'], 0, ',', '.') ?> km ·
                            <?= ucfirst($v['combustivel']) ?> ·
                            <?= ucfirst($v['cambio']) ?>
                        </div>

                        <div class="car-price">
                            €<?= number_format($v['preco'], 2, ',', '.') ?>
                        </div>

                        <button class="fav-remove-btn" data-id="<?= $v['id'] ?>">
                            <i class="ti ti-heart-minus"></i> Remover favorito
                        </button>
                    </div>

                </div>
            <?php endforeach; ?>

        </div>

    <?php endif; ?>

</main>

<script src="<?= BASE_URL ?>/anuncios/js/favoritos.js"></script>
<script src="<?= BASE_URL ?>/anuncios/js/favoritos_remove.js"></script>


<?php include BASE_PATH . '/includes/footer.php'; ?>