document.addEventListener("DOMContentLoaded", () => {
    const btn = document.querySelector(".fav-btn");
    if (!btn) return;

    btn.addEventListener("click", async () => {
        const id = btn.dataset.id;
        const isFav = btn.dataset.fav === "1";

        const url = isFav 
            ? "api/favoritos_remove.php"
            : "api/favoritos_add.php";

        const formData = new FormData();
        formData.append("veiculo_id", id);

        const req = await fetch(url, {
            method: "POST",
            body: formData
        });

        const res = await req.json();

        if (res.status === "ok") {
            if (isFav) {
                btn.dataset.fav = "0";
                btn.innerHTML = "🤍 Adicionar aos favoritos";
            } else {
                btn.dataset.fav = "1";
                btn.innerHTML = "❤️ Remover dos favoritos";
            }
        } else {
            alert(res.msg);
        }
    });
});
