document.addEventListener('DOMContentLoaded', () => {
    const slider = document.getElementById('carSlider');
    if (!slider) return;

    const slides = slider.querySelectorAll('.slider-slide');
    const prevBtn = slider.querySelector('.slider-prev');
    const nextBtn = slider.querySelector('.slider-next');
    const dotsContainer = slider.querySelector('.slider-dots');
    const thumbsContainer = document.querySelector('.slider-thumbs');

    if (slides.length <= 1) return;

    let current = 0;
    let autoplayTimer = null;
    const AUTOPLAY_MS = 5000;

    // Criar dots
    if (dotsContainer) {
        slides.forEach((_, i) => {
            const dot = document.createElement('button');
            dot.type = 'button';
            dot.className = 'slider-dot' + (i === 0 ? ' active' : '');
            dot.setAttribute('aria-label', 'Ir para foto ' + (i + 1));
            dot.addEventListener('click', (e) => {
                e.preventDefault();
                goTo(i);
                resetAutoplay();
            });
            dotsContainer.appendChild(dot);
        });
    }

    const dots = dotsContainer ? dotsContainer.querySelectorAll('.slider-dot') : [];
    const thumbs = thumbsContainer ? thumbsContainer.querySelectorAll('.slider-thumb') : [];

    function goTo(index) {
        if (index < 0 || index >= slides.length) return;

        // Remover active da slide atual
        slides[current].classList.remove('active');
        if (thumbs[current]) thumbs[current].classList.remove('active');
        if (dots[current]) dots[current].classList.remove('active');

        // Nova slide
        current = index;

        slides[current].classList.add('active');
        if (thumbs[current]) thumbs[current].classList.add('active');
        if (dots[current]) dots[current].classList.add('active');
    }

    function next() {
        goTo((current + 1) % slides.length);
    }

    function prev() {
        goTo((current - 1 + slides.length) % slides.length);
    }

    // Setas
    if (prevBtn) {
        prevBtn.addEventListener('click', (e) => {
            e.preventDefault();
            e.stopPropagation();
            prev();
            resetAutoplay();
        });
    }

    if (nextBtn) {
        nextBtn.addEventListener('click', (e) => {
            e.preventDefault();
            e.stopPropagation();
            next();
            resetAutoplay();
        });
    }

    // Miniaturas — clique na imagem ou no botão
    if (thumbsContainer) {
        thumbsContainer.addEventListener('click', (e) => {
            const thumb = e.target.closest('.slider-thumb');
            if (!thumb) return;

            e.preventDefault();
            const index = parseInt(thumb.dataset.index, 10);
            if (!isNaN(index)) {
                goTo(index);
                resetAutoplay();
            }
        });
    }

    // Teclado
    document.addEventListener('keydown', (e) => {
        if (e.key === 'ArrowLeft') { prev(); resetAutoplay(); }
        if (e.key === 'ArrowRight') { next(); resetAutoplay(); }
    });

    function startAutoplay() {
        stopAutoplay();
        autoplayTimer = setInterval(next, AUTOPLAY_MS);
    }

    function stopAutoplay() {
        clearInterval(autoplayTimer);
    }

    function resetAutoplay() {
        stopAutoplay();
        startAutoplay();
    }

    slider.addEventListener('mouseenter', stopAutoplay);
    slider.addEventListener('mouseleave', startAutoplay);

    startAutoplay();
});