<?php
require_once __DIR__ . '/../config/bootstrap.php';

$id = (int)($_GET["id"] ?? 0);

// RGPD: só selecionamos os dados do anunciante que são de facto necessários
// para mostrar a página (nome + cidade). Email e telefone não são exibidos
// aqui, por isso não são pedidos à base de dados.
$sql = "SELECT v.*, u.nome, u.cidade
        FROM veiculos v
        JOIN utilizadores u ON u.id = v.utilizador_id
        WHERE v.id = ?";
$stmt = $pdo->prepare($sql);
$stmt->execute([$id]);
$carro = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$carro) {
    header("Location: " . BASE_URL . "/index.php");
    exit;
}

$sqlFotos = "SELECT url FROM fotos WHERE veiculo_id = ? ORDER BY is_principal DESC, id ASC";
$stmtFotos = $pdo->prepare($sqlFotos);
$stmtFotos->execute([$id]);
$fotos = $stmtFotos->fetchAll(PDO::FETCH_ASSOC);

include BASE_PATH . '/includes/header.php';
?>

<main class="detalhe-page">
    <a href="<?= BASE_URL ?>/index.php" class="detalhe-voltar">
        <i class="ti ti-arrow-left"></i> Voltar aos anúncios
    </a>

    <div class="detalhe-grid">

        <!-- COLUNA ESQUERDA: SLIDER -->
        <section class="detalhe-galeria">
            <div class="slider" id="carSlider">
                <div class="slider-viewport">
                    <?php if (empty($fotos)): ?>
                        <div class="slider-slide active">
                            <div class="slider-placeholder">
                                <i class="ti ti-car"></i>
                                <span>Sem fotos disponíveis</span>
                            </div>
                        </div>
                    <?php else: ?>
                        <?php foreach ($fotos as $index => $f): ?>
                            <div class="slider-slide <?= $index === 0 ? 'active' : '' ?>">
                                <img src="<?= BASE_URL . '/' . htmlspecialchars($f['url']) ?>"
                                     alt="<?= htmlspecialchars($carro['marca'] . ' ' . $carro['modelo']) ?>">
                            </div>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </div>

                <?php if (count($fotos) > 1): ?>
                    <button type="button" class="slider-btn slider-prev" aria-label="Foto anterior">
                        <i class="ti ti-chevron-left"></i>
                    </button>
                    <button type="button" class="slider-btn slider-next" aria-label="Próxima foto">
                        <i class="ti ti-chevron-right"></i>
                    </button>
                    <div class="slider-dots"></div>
                <?php endif; ?>
            </div>

            <?php if (count($fotos) > 1): ?>
                <div class="slider-thumbs">
                    <?php foreach ($fotos as $index => $f): ?>
                        <button type="button"
                                class="slider-thumb <?= $index === 0 ? 'active' : '' ?>"
                                data-index="<?= $index ?>">
                            <img src="<?= BASE_URL . '/' . htmlspecialchars($f['url']) ?>" alt="">
                        </button>
                    <?php endforeach; ?>
                </div>
            <?php endif; ?>
        </section>

        <!-- COLUNA DIREITA: DADOS -->
        <aside class="detalhe-info">
            <div class="detalhe-badges">
                <?php if ($carro['estado'] === 'novo'): ?>
                    <span class="car-badge badge-novo">Novo</span>
                <?php else: ?>
                    <span class="car-badge badge-used"><?= ucfirst($carro['estado']) ?></span>
                <?php endif; ?>
                 <?php
$logado = isset($_SESSION["user_id"]);
$utilizador_id = $_SESSION["user_id"] ?? 0;

// verificar se já é favorito
$isFav = false;

if ($logado) {
    $sqlFav = "SELECT 1 FROM favoritos WHERE utilizador_id = ? AND veiculo_id = ?";
    $stmtFav = $pdo->prepare($sqlFav);
    $stmtFav->execute([$utilizador_id, $carro['id']]);
    $isFav = $stmtFav->fetch() ? true : false;
}
?>

<button class="fav-btn" 
        data-id="<?= $carro['id'] ?>" 
        data-fav="<?= $isFav ? '1' : '0' ?>">
    <?= $isFav ? '❤️ Remover dos favoritos' : '🤍 Adicionar aos favoritos' ?>
</button>

             </div>

            <h1 class="detalhe-titulo">
                <?= htmlspecialchars($carro['marca'] . ' ' . $carro['modelo']) ?>
            </h1>

            <p class="detalhe-subtitulo">
                <?= (int)$carro['ano'] ?> ·
                <?= number_format($carro['quilometragem'], 0, ',', '.') ?> km ·
                <?= ucfirst($carro['combustivel']) ?>· 
                <?= ucfirst($carro['cambio']) ?>
                
            </p>

            <div class="detalhe-preco">
                €<?= number_format($carro['preco'], 2, ',', '.') ?>
            </div>

            <div class="detalhe-specs">
                <div class="spec-item">
                    <span>Ano</span>
                    <strong><?= (int)$carro['ano'] ?></strong>
                </div>
                <div class="spec-item">
                    <span>Quilometragem</span>
                    <strong><?= number_format($carro['quilometragem'], 0, ',', '.') ?> km</strong>
                </div>
                <div class="spec-item">
                    <span>Combustível</span>
                    <strong><?= ucfirst($carro['combustivel']) ?></strong>
                </div>

                <?php if ($tipo=$carro['tipo_veiculo'] ?? 'carro'): ?>
                    <?php if ($tipo === 'mota'): ?>
                        <div class="spec-item">
                            <span>Cilindrada</span>
                            <strong><?= (int)$carro['cilindrada'] ?> cc</strong>
                        </div>
                    <?php elseif ($tipo === 'pesado'): ?>
                        <div class="spec-item">
                            <span>Capacidade de carga</span>
                            <strong><?= number_format($carro['capacidade_carga_kg'], 0, ',', '.') ?> kg</strong>
                        </div>
                        <div class="spec-item">
                            <span>Nº de eixos</span>
                            <strong><?= (int)$carro['numero_eixos'] ?></strong>
                        </div>
                    <?php else: ?>
                        <div class="spec-item">
                            <span>Câmbio</span>  

                            <strong><?= ucfirst($carro['cambio']) ?></strong>
                        </div>
                    <?php endif; ?>
                <?php endif; ?>
                    
                <?php if (!empty($carro['distrito'])): ?>
                    <div class="spec-item">
                        <span>Distrito</span>
                        <strong><?= htmlspecialchars($carro['distrito']) ?></strong>
                    </div>
                <?php endif; ?>
            </div>

            <?php if (!empty($carro['descricao'])): ?>
                <div class="detalhe-descricao">
                    <h2>Descrição</h2>
                    <p><?= nl2br(htmlspecialchars($carro['descricao'])) ?></p>
                </div>
            <?php endif; ?>

             <!-- contactar anunciante -->
            <?php if (isset($_GET['msg']) && $_GET['msg'] == 'enviada'): ?>
    <div class="mensagem_enviada">
        <i class="ti ti-check"></i>
        A sua mensagem foi enviada ao anunciante com sucesso.
    </div>
<?php endif; ?>

            <div class="detalhe-contacto">
                <h2>Contactar anunciante</h2>
                <p class="contacto-nome"><?= htmlspecialchars($carro['nome']) ?></p>
                <p class="contacto-local">
                    <i class="ti ti-map-pin"></i> <?= htmlspecialchars($carro['cidade']) ?>
                </p>
                  <!-- envia mensagem precisa fazer login -->
                <?php if (!isset($_SESSION["user_id"])): ?>
    <div style="background:#ffe8e8;padding:12px;border-radius:8px;margin-bottom:15px;">
        <i class="ti ti-lock"></i>  
        Para enviar mensagem ao anunciante, precisa fazer login.
    </div>
<?php endif; ?>


                <form action="<?= BASE_URL ?>/mensagens/enviar_mensagem.php" method="post">
    <input type="hidden" name="veiculo_id" value="<?= $carro['id'] ?>">
    <input type="hidden" name="destinatario_id" value="<?= $carro['utilizador_id'] ?>">

   
    <textarea name="mensagem"
              class="form-control"
              rows="5"
              placeholder="Escreva a sua mensagem ao anunciante..."
              required></textarea>
              
<!-- Se o utilizador não estiver logado, mostra um link para login -->
              <?php if (!isset($_SESSION["user_id"])): ?>
    <a href="<?= BASE_URL ?>/auth/login.php?redirect=<?= urlencode(BASE_URL . '/anuncios/detalhes.php?id=' . $carro['id']) ?>"
       class="contact-button">
        <i class="ti ti-login"></i> Fazer login para enviar mensagem
    </a>
<?php else: ?>
    <button type="submit" class="contact-button">Enviar mensagem</button>
<?php endif; ?>

</form>
            </div>
  
        </aside>

    </div>
</main>

<script src="<?= BASE_URL ?>/anuncios/js/favoritos_remove.js"></script>
<script src="<?= BASE_URL ?>/anuncios/js/favoritos.js"></script>
<script src="<?= BASE_URL ?>/anuncios/js/slider.js"></script>

<?php include BASE_PATH . '/includes/footer.php'; ?>




