<?php
require_once __DIR__ . '/../config/bootstrap.php';
exigirLogin();

$id = $_GET["id"];
$user_id = $_SESSION["user_id"];

// 1. Verifica se o anúncio pertence ao utilizador
$sql = "SELECT * FROM veiculos WHERE id = ? AND utilizador_id = ?";
$stmt = $pdo->prepare($sql);
$stmt->execute([$id, $user_id]);

$carro = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$carro) {
    die("Acesso negado.");
}

// 2. Buscar fotos
$sqlFotos = "SELECT url FROM fotos WHERE veiculo_id = ?";
$stmtFotos = $pdo->prepare($sqlFotos);
$stmtFotos->execute([$id]);
$fotos = $stmtFotos->fetchAll(PDO::FETCH_ASSOC);

// 3. Apagar ficheiros fisicamente
foreach ($fotos as $f) {
    $caminho = BASE_PATH . "/" . $f["url"];
    if (file_exists($caminho)) {
        unlink($caminho);
    }
}

// 4. Apagar o anúncio (CASCADE apaga fotos da BD)
$sqlDel = "DELETE FROM veiculos WHERE id = ? AND utilizador_id = ?";
$stmtDel = $pdo->prepare($sqlDel);
$stmtDel->execute([$id, $user_id]);

// 5. Redirecionar corretamente
header("Location: " . BASE_URL . "/anuncios/meus_anuncios.php");
exit;
