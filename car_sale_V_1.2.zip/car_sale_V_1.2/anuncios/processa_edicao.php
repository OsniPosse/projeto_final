<?php
require_once __DIR__ . '/../config/bootstrap.php';
exigirLogin();

$id = (int)($_POST["id"] ?? 0);
$user_id = $_SESSION["user_id"];

// Verificar desde já que o anúncio pertence ao utilizador autenticado,
// antes de qualquer alteração (evita que um utilizador edite/destaque
// anúncios de outra pessoa só por adivinhar o id).
$sqlDono = "SELECT id FROM veiculos WHERE id = ? AND utilizador_id = ?";
$stmtDono = $pdo->prepare($sqlDono);
$stmtDono->execute([$id, $user_id]);
if (!$stmtDono->fetch()) {
    http_response_code(403);
    die("Acesso negado.");
}

// Verificar se o utilizador marcou destaque
$destaque = isset($_POST["destaque"]) ? 1 : 0;

// Verificar se já existe destaque para este veículo
$sqlCheck = "SELECT id FROM anuncios_top WHERE veiculo_id = ?";
$stmtCheck = $pdo->prepare($sqlCheck);
$stmtCheck->execute([$id]);
$existeTop = $stmtCheck->fetch(PDO::FETCH_ASSOC);

if ($destaque == 1) {

    $inicio = date("Y-m-d");
    $fim = date("Y-m-d", strtotime("+30 days"));
    $valor_pago = 0.00;

    if ($existeTop) {
        // Atualizar destaque existente
        $sqlTop = "UPDATE anuncios_top
                   SET inicio=?, fim=?, valor_pago=?, ativo=1
                   WHERE veiculo_id=?";
        $pdo->prepare($sqlTop)->execute([$inicio, $fim, $valor_pago, $id]);

    } else {
        // Criar novo destaque
        $sqlTop = "INSERT INTO anuncios_top (veiculo_id, inicio, fim, valor_pago, ativo)
                   VALUES (?, ?, ?, ?, 1)";
        $pdo->prepare($sqlTop)->execute([$id, $inicio, $fim, $valor_pago]);
    }

} else if ($existeTop) {
    // Desativar destaque
    $sqlTop = "UPDATE anuncios_top SET ativo = 0 WHERE veiculo_id = ?";
    $pdo->prepare($sqlTop)->execute([$id]);
}




// Atualizar dados

$tipoVeiculo = in_array($_POST["tipo_veiculo"] ?? '', ['carro', 'mota', 'pesado'], true)
    ? $_POST["tipo_veiculo"] : 'carro';

$marca = trim($_POST["marca_select"] ?? '');
if ($marca === 'Outra marca' || $marca === '') {
    $marca = trim($_POST["marca_outra"] ?? $marca);
}

$cambio = $tipoVeiculo === 'pesado' ? 'manual' : $_POST["cambio"];
$distrito = $_POST["distrito"] ?: null;
$cilindrada = $tipoVeiculo === 'mota' && $_POST["cilindrada"] !== '' ? (int) $_POST["cilindrada"] : null;
$capacidadeCarga = $tipoVeiculo === 'pesado' && $_POST["capacidade_carga_kg"] !== '' ? (int) $_POST["capacidade_carga_kg"] : null;
$numeroEixos = $tipoVeiculo === 'pesado' && $_POST["numero_eixos"] !== '' ? (int) $_POST["numero_eixos"] : null;

$sql = "UPDATE veiculos SET
            tipo_veiculo=?, marca=?, modelo=?, ano=?, quilometragem=?, preco=?, combustivel=?, cambio=?,
            estado=?, distrito=?, cilindrada=?, capacidade_carga_kg=?, numero_eixos=?, descricao=?
        WHERE id=? AND utilizador_id=?";

$stmt = $pdo->prepare($sql);
$stmt->execute([
    $tipoVeiculo, $marca, $_POST["modelo"], $_POST["ano"], $_POST["quilometragem"],
    $_POST["preco"], $_POST["combustivel"], $cambio, $_POST["estado"], $distrito,
    $cilindrada, $capacidadeCarga, $numeroEixos,
    $_POST["descricao"], $id, $user_id
]);



// ADICIONAR NOVAS FOTOS
if (!empty($_FILES["novas_fotos"]["name"][0])) {

    if (!is_dir(BASE_PATH . "/uploads")) {
        mkdir(BASE_PATH . "/uploads", 0755, true);
    }

    $total = count($_FILES["novas_fotos"]["name"]);

    for ($i = 0; $i < $total; $i++) {

        $tmp = $_FILES["novas_fotos"]["tmp_name"][$i];
        $nomeOriginal = $_FILES["novas_fotos"]["name"][$i];
        $ext = strtolower(pathinfo($nomeOriginal, PATHINFO_EXTENSION));

        if (!in_array($ext, ["jpg", "jpeg", "png"])) continue;

        $novoNome = uniqid() . "." . $ext;

        $destinoServidor = BASE_PATH . "/uploads/" . $novoNome;
        $destinoBD = "uploads/" . $novoNome;

        if (move_uploaded_file($tmp, $destinoServidor)) {
            $pdo->prepare("INSERT INTO fotos (veiculo_id, url, is_principal) VALUES (?, ?, 0)")
                ->execute([$id, $destinoBD]);
        }
    }
}

header("Location: " . BASE_URL . "/anuncios/meus_anuncios.php");
exit;
