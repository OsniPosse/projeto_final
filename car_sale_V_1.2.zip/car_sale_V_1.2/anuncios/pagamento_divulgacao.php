<?php
require_once __DIR__ . '/../config/bootstrap.php';
exigirPerfil('lojista');
require_once BASE_PATH . '/includes/sync/publicacao_externa.php';

$veiculoId = (int) ($_GET['veiculo_id'] ?? $_POST['veiculo_id'] ?? 0);
$user_id = $_SESSION['user_id'];

$stmt = $pdo->prepare("SELECT * FROM veiculos WHERE id = ? AND utilizador_id = ?");
$stmt->execute([$veiculoId, $user_id]);
$carro = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$carro) {
    die("Acesso negado.");
}

$stmtPendentes = $pdo->prepare("SELECT * FROM publicacoes_externas WHERE veiculo_id = ? AND estado = 'pendente_pagamento'");
$stmtPendentes->execute([$veiculoId]);
$pendentes = $stmtPendentes->fetchAll(PDO::FETCH_ASSOC);

$resultados = null;

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['confirmar_pagamento'])) {
    /**
     * PAGAMENTO SIMULADO — tal como o resto da plataforma (destaques,
     * planos de lojista), ainda não há uma gateway de pagamento real
     * ligada (Stripe, MB WAY, Multibanco, etc.). Este é o único ponto do
     * código onde essa integração precisa de entrar: confirma aqui o
     * pagamento antes de chamar pagarEPublicar().
     */
    $resultados = pagarEPublicar($pdo, $veiculoId);

    // Atualiza a lista de pendentes depois de processar
    $stmtPendentes->execute([$veiculoId]);
    $pendentes = [];
}

$total = array_sum(array_column($pendentes, 'valor_cents'));
$plataformas = plataformasDivulgacao();

require BASE_PATH . '/includes/header.php';
?>

<div class="register-container">
    <h2>Pagamento da divulgação</h2>
    <p class="lojista-fields-nota">
        <?= htmlspecialchars($carro['marca'] . ' ' . $carro['modelo']) ?>
    </p>

    <?php if ($resultados !== null): ?>

        <h3>Resultado</h3>
        <?php foreach ($resultados as $plataforma => $resultado): ?>
            <?php if ($resultado['ok']): ?>
                <p class="sucesso">
                    <?= htmlspecialchars($plataformas[$plataforma]['nome'] ?? $plataforma) ?>: publicado com sucesso.
                </p>
            <?php else: ?>
                <p class="erro">
                    <?= htmlspecialchars($plataformas[$plataforma]['nome'] ?? $plataforma) ?>: <?= htmlspecialchars($resultado['erro']) ?>
                    (o pagamento ficou registado — podes tentar publicar de novo assim que corrigires a configuração,
                    sem pagar outra vez).
                </p>
            <?php endif; ?>
        <?php endforeach; ?>

        <a href="<?= BASE_URL ?>/anuncios/meus_anuncios.php" class="btn-plano" style="text-decoration:none;display:inline-block;">
            Voltar aos meus anúncios
        </a>

    <?php elseif (empty($pendentes)): ?>

        <p>Não há nenhuma divulgação pendente de pagamento para este anúncio.</p>
        <a href="<?= BASE_URL ?>/anuncios/divulgar.php?id=<?= $veiculoId ?>" class="btn-plano" style="text-decoration:none;display:inline-block;">
            Escolher plataformas
        </a>

    <?php else: ?>

        <ul class="lista-resumo">
            <?php foreach ($pendentes as $p): ?>
                <li>
                    <?= htmlspecialchars($plataformas[$p['plataforma']]['nome'] ?? $p['plataforma']) ?>
                    — €<?= number_format($p['valor_cents'] / 100, 2, ',', '.') ?>
                </li>
            <?php endforeach; ?>
        </ul>
        <p><strong>Total: €<?= number_format($total / 100, 2, ',', '.') ?></strong></p>

        <form method="POST" action="<?= BASE_URL ?>/anuncios/pagamento_divulgacao.php">
            <input type="hidden" name="veiculo_id" value="<?= $veiculoId ?>">
            <input type="hidden" name="confirmar_pagamento" value="1">
            <p class="lojista-fields-nota">
                Pagamento simulado — ainda sem gateway real ligada a esta plataforma.
            </p>
            <button type="submit">Confirmar pagamento de €<?= number_format($total / 100, 2, ',', '.') ?></button>
        </form>

    <?php endif; ?>
</div>

<?php require BASE_PATH . '/includes/footer.php'; ?>
