<?php
require_once __DIR__ . '/../config/bootstrap.php';
exigirLogin();

if ($_SERVER["REQUEST_METHOD"] === "POST") {

    $tipoVeiculo = in_array($_POST["tipo_veiculo"] ?? '', ['carro', 'mota', 'pesado'], true)
        ? $_POST["tipo_veiculo"] : 'carro';

    // Marca: vem do <select> (marca_select), ou do texto livre quando "Outra marca"
    $marca = trim($_POST["marca_select"] ?? '');
    if ($marca === 'Outra marca' || $marca === '') {
        $marca = trim($_POST["marca_outra"] ?? $marca);
    }

    $modelo = $_POST["modelo"];
    $ano = $_POST["ano"];
    $km = $_POST["quilometragem"];
    $preco = $_POST["preco"];
    $combustivel = $_POST["combustivel"];
    $cambio = $tipoVeiculo === 'pesado' ? 'manual' : $_POST["cambio"]; // pesados não pedem câmbio no formulário
    $estado = $_POST["estado"];
    $distrito = $_POST["distrito"] ?: null;
    $descricao = $_POST["descricao"];
    $user_id = $_SESSION["user_id"];

    $cilindrada = $tipoVeiculo === 'mota' && $_POST["cilindrada"] !== '' ? (int) $_POST["cilindrada"] : null;
    $capacidadeCarga = $tipoVeiculo === 'pesado' && $_POST["capacidade_carga_kg"] !== '' ? (int) $_POST["capacidade_carga_kg"] : null;
    $numeroEixos = $tipoVeiculo === 'pesado' && $_POST["numero_eixos"] !== '' ? (int) $_POST["numero_eixos"] : null;

    $destaque = isset($_POST['destaque']) ? 1 : 0;


    // Inserir veículo

    $sql = "INSERT INTO veiculos
            (utilizador_id, tipo_veiculo, marca, modelo, ano, quilometragem, preco, combustivel, cambio, estado, distrito, cilindrada, capacidade_carga_kg, numero_eixos, descricao)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";

    $stmt = $pdo->prepare($sql);
    $stmt->execute([
        $user_id, $tipoVeiculo, $marca, $modelo, $ano, $km, $preco, $combustivel, $cambio, $estado,
        $distrito, $cilindrada, $capacidadeCarga, $numeroEixos, $descricao,
    ]);

    $veiculo_id = $pdo->lastInsertId();
    // Se o utilizador marcou destaque
if ($destaque == 1) {

    $inicio = date("Y-m-d");
    $fim = date("Y-m-d", strtotime("+30 days")); // destaque válido por 30 dias
    $valor_pago = 0.00; // ou o valor que quiseres

    $sqlTop = "INSERT INTO anuncios_top (veiculo_id, inicio, fim, valor_pago, ativo)
               VALUES (?, ?, ?, ?, 1)";

    $stmtTop = $pdo->prepare($sqlTop);
    $stmtTop->execute([$veiculo_id, $inicio, $fim, $valor_pago]);
}


    // Upload das fotos
    if (!empty($_FILES["fotos"]["name"][0])) {

        if (!is_dir(BASE_PATH . "/uploads")) {
            mkdir(BASE_PATH . "/uploads", 0755, true);
        }

        $total = count($_FILES["fotos"]["name"]);

        for ($i = 0; $i < $total; $i++) {

            $tmp = $_FILES["fotos"]["tmp_name"][$i];
            $nomeOriginal = $_FILES["fotos"]["name"][$i];
            $ext = strtolower(pathinfo($nomeOriginal, PATHINFO_EXTENSION));

            if (!in_array($ext, ["jpg", "jpeg", "png"])) continue;

            $novoNome = uniqid() . "." . $ext;

            $destinoServidor = BASE_PATH . "/uploads/" . $novoNome;
            $destinoBD = "uploads/" . $novoNome;

            if (move_uploaded_file($tmp, $destinoServidor)) {
                $pdo->prepare("INSERT INTO fotos (veiculo_id, url, is_principal) VALUES (?, ?, ?)")
                    ->execute([$veiculo_id, $destinoBD, $i === 0 ? 1 : 0]);
            }
        }
    }

    // Lojistas têm acesso à divulgação externa (Standvirtual/OLX) — sugere o próximo passo
    if (($_SESSION["user_perfil"] ?? '') === 'lojista') {
        header("Location: " . BASE_URL . "/anuncios/divulgar.php?id=" . $veiculo_id);
        exit;
    }

    header("Location: " . BASE_URL . "/anuncios/meus_anuncios.php");
    exit;
}
