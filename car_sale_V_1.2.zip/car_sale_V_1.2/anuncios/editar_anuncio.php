<?php
require_once __DIR__ . '/../config/bootstrap.php';
exigirLogin();

$id = $_GET["id"];
$user_id = $_SESSION["user_id"];

// Verifica se o anúncio pertence ao utilizador
$sql = "SELECT * FROM veiculos WHERE id = ? AND utilizador_id = ?";
$stmt = $pdo->prepare($sql);
$stmt->execute([$id, $user_id]);
$carro = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$carro) {
    die("Acesso negado.");
}

$taxonomia = require BASE_PATH . '/config/veiculos_taxonomia.php';
$distritos = require BASE_PATH . '/config/distritos.php';
$tipoAtual = $carro['tipo_veiculo'] ?: 'carro';
$marcaConhecida = array_key_exists($carro['marca'], $taxonomia[$tipoAtual]['marcas'] ?? []);

require BASE_PATH . '/includes/header.php';
?>

<div class="register-container">
    <h2>Editar Anúncio</h2>

    <form action="<?= BASE_URL ?>/anuncios/processa_edicao.php" method="POST" enctype="multipart/form-data" class="register-form" id="formAnuncio">

    <label>Destacar anúncio por 5€ /semana (opcional)
    <input type="checkbox" name="destaque" value="1" >

</label>

        <input type="hidden" name="id" value="<?= $carro['id'] ?>">

        <label class="campo-label">Tipo de veículo
            <select name="tipo_veiculo" id="selectTipo" required>
                <?php foreach ($taxonomia as $chaveTipo => $dadosTipo): ?>
                    <option value="<?= $chaveTipo ?>" <?= $tipoAtual === $chaveTipo ? 'selected' : '' ?>><?= htmlspecialchars($dadosTipo['nome']) ?></option>
                <?php endforeach; ?>
            </select>
        </label>

        <label class="campo-label">Marca
            <select name="marca_select" id="selectMarca" required></select>
        </label>
        <input type="text" name="marca_outra" id="inputMarcaOutra"
               placeholder="Escreva a marca"
               value="<?= !$marcaConhecida ? htmlspecialchars($carro['marca']) : '' ?>"
               style="display:<?= !$marcaConhecida ? 'block' : 'none' ?>;">

        <input type="text" name="modelo" id="inputModelo" list="listaModelos" value="<?= htmlspecialchars($carro['modelo']) ?>" placeholder="Modelo" required>
        <datalist id="listaModelos"></datalist>

        <input type="number" name="ano" value="<?= $carro['ano'] ?>" required>
        <input type="number" name="quilometragem" value="<?= $carro['quilometragem'] ?>" required>

        <input type="number" step="0.01" name="preco" value="<?= $carro['preco'] ?>" required>

        <select name="combustivel" required>
            <option value="gasolina" <?= $carro['combustivel']=='gasolina'?'selected':'' ?>>Gasolina</option>
            <option value="diesel" <?= $carro['combustivel']=='diesel'?'selected':'' ?>>Diesel</option>
            <option value="eletrico" <?= $carro['combustivel']=='eletrico'?'selected':'' ?>>Elétrico</option>
            <option value="hibrido" <?= $carro['combustivel']=='hibrido'?'selected':'' ?>>Híbrido</option>
            <option value="gpl" <?= $carro['combustivel']=='gpl'?'selected':'' ?>>GPL</option>
        </select>

        <div id="campoCambio">
            <select name="cambio" id="selectCambio">
                <option value="manual" <?= $carro['cambio']=='manual'?'selected':'' ?>>Manual</option>
                <option value="automatico" <?= $carro['cambio']=='automatico'?'selected':'' ?>>Automático</option>
            </select>
        </div>

        <div id="campoCilindrada" style="display:none;">
            <input type="number" name="cilindrada" placeholder="Cilindrada (cc)" value="<?= htmlspecialchars($carro['cilindrada'] ?? '') ?>">
        </div>

        <div id="camposPesado" style="display:none;">
            <input type="number" name="capacidade_carga_kg" placeholder="Capacidade de carga (kg)" value="<?= htmlspecialchars($carro['capacidade_carga_kg'] ?? '') ?>">
            <input type="number" name="numero_eixos" placeholder="Número de eixos" value="<?= htmlspecialchars($carro['numero_eixos'] ?? '') ?>">
        </div>

        <select name="estado" required>
            <option value="novo" <?= $carro['estado']=='novo'?'selected':'' ?>>Novo</option>
            <option value="seminovo" <?= $carro['estado']=='seminovo'?'selected':'' ?>>Seminovo</option>
            <option value="usado" <?= $carro['estado']=='usado'?'selected':'' ?>>Usado</option>
        </select>

        <label class="campo-label">Distrito
            <select name="distrito">
                <option value="">Selecione o distrito</option>
                <?php foreach ($distritos as $distrito): ?>
                    <option value="<?= htmlspecialchars($distrito) ?>" <?= ($carro['distrito'] ?? '') === $distrito ? 'selected' : '' ?>><?= htmlspecialchars($distrito) ?></option>
                <?php endforeach; ?>
            </select>
        </label>

        <textarea name="descricao" rows="4"><?= htmlspecialchars($carro['descricao']) ?></textarea>

        <label>Adicionar novas fotos ao anúncio:</label>
        <input type="file" name="novas_fotos[]" multiple accept="image/*">

        <button type="submit">Guardar Alterações</button>
    </form>
</div>

<script>
(function () {
    const taxonomia = <?= json_encode($taxonomia, JSON_UNESCAPED_UNICODE) ?>;
    const marcaAtual = <?= json_encode($carro['marca']) ?>;
    const marcaConhecida = <?= $marcaConhecida ? 'true' : 'false' ?>;

    const selectTipo   = document.getElementById('selectTipo');
    const selectMarca  = document.getElementById('selectMarca');
    const inputOutra   = document.getElementById('inputMarcaOutra');
    const inputModelo  = document.getElementById('inputModelo');
    const listaModelos = document.getElementById('listaModelos');
    const campoCambio      = document.getElementById('campoCambio');
    const selectCambio     = document.getElementById('selectCambio');
    const campoCilindrada  = document.getElementById('campoCilindrada');
    const camposPesado     = document.getElementById('camposPesado');

    function popularMarcas(manterSelecao) {
        const marcas = Object.keys(taxonomia[selectTipo.value].marcas);
        selectMarca.innerHTML = marcas.map(m => `<option value="${m}">${m}</option>`).join('');

        if (manterSelecao) {
            selectMarca.value = marcaConhecida ? marcaAtual : 'Outra marca';
        }
        atualizarModelos();
    }

    function atualizarModelos() {
        const modelos = taxonomia[selectTipo.value].marcas[selectMarca.value] || [];
        listaModelos.innerHTML = modelos.map(m => `<option value="${m}">`).join('');
    }

    function atualizarCamposPorTipo() {
        const tipo = selectTipo.value;
        campoCambio.style.display = tipo === 'pesado' ? 'none' : 'block';
        selectCambio.required = tipo !== 'pesado';
        campoCilindrada.style.display = tipo === 'mota' ? 'block' : 'none';
        camposPesado.style.display = tipo === 'pesado' ? 'block' : 'none';
    }

    selectTipo.addEventListener('change', function () {
        popularMarcas(false);
        atualizarCamposPorTipo();
    });

    selectMarca.addEventListener('change', function () {
        atualizarModelos();
        inputOutra.style.display = selectMarca.value === 'Outra marca' ? 'block' : 'none';
    });

    popularMarcas(true);
    atualizarCamposPorTipo();
    inputOutra.style.display = (selectMarca.value === 'Outra marca') ? 'block' : 'none';

    document.getElementById('formAnuncio').addEventListener('submit', function () {
        if (selectMarca.value === 'Outra marca' && inputOutra.value.trim() !== '') {
            selectMarca.value = inputOutra.value.trim();
            const opt = document.createElement('option');
            opt.value = inputOutra.value.trim();
            opt.selected = true;
            selectMarca.appendChild(opt);
        }
    });
})();
</script>

<?php require BASE_PATH . '/includes/footer.php'; ?>
