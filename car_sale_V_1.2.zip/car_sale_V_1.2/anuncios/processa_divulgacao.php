<?php
require_once __DIR__ . '/../config/bootstrap.php';
exigirPerfil('lojista');
require_once BASE_PATH . '/includes/sync/publicacao_externa.php';

$veiculoId = (int) ($_POST['veiculo_id'] ?? 0);
$plataformas = $_POST['plataformas'] ?? [];
$user_id = $_SESSION['user_id'];

// Confirma que o veículo pertence a este utilizador
$stmt = $pdo->prepare("SELECT id FROM veiculos WHERE id = ? AND utilizador_id = ?");
$stmt->execute([$veiculoId, $user_id]);
if (!$stmt->fetch()) {
    die("Acesso negado.");
}

// Só aceita plataformas conhecidas
$plataformasValidas = array_intersect($plataformas, array_keys(plataformasDivulgacao()));

if (empty($plataformasValidas)) {
    header("Location: " . BASE_URL . "/anuncios/meus_anuncios.php");
    exit;
}

criarPedidosDivulgacao($pdo, $veiculoId, $plataformasValidas);

header("Location: " . BASE_URL . "/anuncios/pagamento_divulgacao.php?veiculo_id=" . $veiculoId);
exit;
