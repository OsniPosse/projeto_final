<?php
require_once __DIR__ . '/../config/bootstrap.php';
exigirLogin();
require_once BASE_PATH . '/includes/sync/publicacao_externa.php';

$user_id = $_SESSION["user_id"];
$ehLojista = ($_SESSION["user_perfil"] ?? '') === 'lojista';

$sql = "
    SELECT v.*,
           (SELECT url FROM fotos WHERE veiculo_id = v.id AND is_principal = 1 LIMIT 1) AS foto
    FROM veiculos v
    WHERE v.utilizador_id = ?
    ORDER BY v.criado_em DESC
";

$stmt = $pdo->prepare($sql);
$stmt->execute([$user_id]);
$anuncios = $stmt->fetchAll(PDO::FETCH_ASSOC);

?>
<?php require BASE_PATH . '/includes/header.php'; ?>

<div class="gallery" style="margin-top:20px;">
    <div class="gallery-header">
        <span class="gallery-title">Meus Anúncios</span>
        <span class="gallery-count"><?= count($anuncios) ?> anúncios</span>
    </div>

    <div class="cars-grid">
    <?php foreach ($anuncios as $carro): ?>

        <a href="<?= BASE_URL ?>/anuncios/detalhes.php?id=<?= $carro['id'] ?>" class="car-card" style="text-decoration:none;color:inherit;">

            <div class="car-img">
                <?php if ($carro["foto"]): ?>
                    <img src="<?= BASE_URL . '/' . htmlspecialchars($carro["foto"]) ?>" style="width:100%;height:100%;object-fit:cover;">
                <?php else: ?>
                    <i class="ti ti-car"></i>
                <?php endif; ?>
            </div>

            <div class="car-info">
                <div class="car-name"><?= htmlspecialchars($carro["marca"] . " " . $carro["modelo"]) ?></div>
                <div class="car-specs">
                    <?= htmlspecialchars($carro["ano"]) ?> · <?= number_format($carro["quilometragem"], 0, ',', '.') ?> km
                </div>
                <div class="car-price">€<?= number_format($carro["preco"], 2, ',', '.') ?></div>

                <div style="margin-top:10px; display:flex; gap:8px; flex-wrap:wrap;">
                    <a href="<?= BASE_URL ?>/anuncios/editar_anuncio.php?id=<?= $carro['id'] ?>"
                       class="btn-login"
                       style="background:#4f7ef7;color:white;border:none;">
                       Editar
                    </a>

                    <a href="<?= BASE_URL ?>/anuncios/remover_anuncio.php?id=<?= $carro['id'] ?>"
                       class="btn-login"
                       style="background:#e63946;color:white;border:none;"
                       onclick="return confirm('Tem certeza que deseja remover este anúncio?')">
                       Remover
                    </a>

                    <?php if ($ehLojista): ?>
                        <a href="<?= BASE_URL ?>/anuncios/divulgar.php?id=<?= $carro['id'] ?>"
                           class="btn-login"
                           style="background:#1a1a2e;color:white;border:none;">
                           <i class="ti ti-broadcast"></i> Divulgar
                        </a>
                    <?php endif; ?>
                </div>

                <?php if ($ehLojista):
                    $estadosSync = estadoDivulgacao($pdo, (int) $carro['id']);
                ?>
                    <div style="margin-top:8px;">
                        <?php foreach ($estadosSync as $plataforma => $info): ?>
                            <span class="badge-sync <?= $info['estado'] === 'publicado' ? 'badge-sync-ok' : ($info['estado'] === 'falhou' ? 'badge-sync-erro' : 'badge-sync-pendente') ?>">
                                <?= htmlspecialchars(ucfirst($plataforma)) ?>: <?= htmlspecialchars($info['estado']) ?>
                            </span>
                        <?php endforeach; ?>
                    </div>
                <?php endif; ?>
            </div>

        </a>

    <?php endforeach; ?>
</div>


<?php require BASE_PATH . '/includes/footer.php'; ?>
