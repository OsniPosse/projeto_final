<?php
require_once __DIR__ . '/config/bootstrap.php';
require BASE_PATH . '/includes/header.php';
require BASE_PATH . '/includes/home.php';
?>
<?php if (isset($_SESSION["anuncio_sucesso"])): ?>
    <p class="sucesso"><?= $_SESSION["anuncio_sucesso"] ?></p>
    <?php unset($_SESSION["anuncio_sucesso"]); ?>
<?php endif; ?>
<?php require BASE_PATH . '/includes/institucional.php'; ?>
<?php require BASE_PATH . '/includes/footer.php'; ?>
