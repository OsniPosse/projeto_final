<?php
require_once __DIR__ . '/config/bootstrap.php';
require_once BASE_PATH . '/includes/filtro.php';

if (!isset($_GET['q']) || trim($_GET['q']) === '') {
    header("Location: " . BASE_URL . "/index.php");
    exit;
}

$query = obterFiltrosVeiculos($_GET);
$stmt = $pdo->prepare($query['sql']);
$stmt->execute($query['params']);
$resultados = $stmt->fetchAll(PDO::FETCH_ASSOC);
$f = $query['filtros'];

require BASE_PATH . '/includes/header.php';
?>

<div class="gallery" style="margin-top:20px; padding:20px;">
    <div class="gallery-header">
        <span class="gallery-title">Resultados para "<?= htmlspecialchars($f['q']) ?>"</span>
        <span class="gallery-count"><?= count($resultados) ?> veículos encontrados</span>
    </div>

    <!-- Formulário de filtros extra (reutiliza campos de filtro.php) -->
    <form method="GET" action="<?= BASE_URL ?>/buscar.php" class="filter-panel" style="margin-bottom:16px;">
        <input type="hidden" name="q" value="<?= htmlspecialchars($f['q']) ?>">
        <label>Marca <input type="text" name="marca" value="<?= htmlspecialchars($f['marca']) ?>"></label>
        <label>Preço máx <input type="number" name="preco_max" value="<?= htmlspecialchars($f['preco_max']) ?>"></label>
        <label>Ano mín <input type="number" name="ano_min" value="<?= htmlspecialchars($f['ano_min']) ?>"></label>
        <label>Ano máx <input type="number" name="ano_max" value="<?= htmlspecialchars($f['ano_max']) ?>"></label>
        <label>Km máx <input type="number" name="km_max" value="<?= htmlspecialchars($f['km_max']) ?>"></label>
        <button type="submit" class="btn-filter">Refinar</button>
    </form>

    <div class="cars-grid">
        <?php if (empty($resultados)): ?>
            <p>Nenhum veículo encontrado.</p>
        <?php else: ?>
            <?php foreach ($resultados as $carro): ?>
                <?php include BASE_PATH . '/includes/card_veiculo.php'; ?>
            <?php endforeach; ?>
        <?php endif; ?>
    </div>
</div>

<?php require BASE_PATH . '/includes/footer.php'; ?>
