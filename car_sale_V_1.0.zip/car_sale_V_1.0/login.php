<?php
require "conexao.php";

if ($_SERVER["REQUEST_METHOD"] === "POST") {

    $email = trim($_POST["email"]);
    $password = $_POST["password"];

    $sql = "SELECT * FROM utilizadores WHERE email = ?";
    $stmt = $pdo->prepare($sql);
    $stmt->execute([$email]);
    $user = $stmt->fetch(PDO::FETCH_ASSOC);

    if ($user && password_verify($password, $user["password"])) {
         if ((int)$user["verificado"] !== 1) {
            $_SESSION["verificar_email"] = $email;
            header("Location: verificar_email.php");
            exit;
        }
        $_SESSION["user_id"] = $user["id"];
        $_SESSION["user_nome"] = $user["nome"];
        $_SESSION["user_perfil"] = $user["perfil"];

        header("Location: index.php");
        exit;

    } else {

        $_SESSION["login_erro"] = "Email ou password incorretos";
        header("Location: index.php");
        exit;

    }
}
?>