<?php
$host = "localhost";
$dbname = "car_sale_V1";
$user = "root";
$pass = "";

try {
    $pdo = new PDO("mysql:host=$host;dbname=$dbname;charset=utf8mb4", $user, $pass);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    die("Erro na BD: " . $e->getMessage());
}

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

?>
