<?php
require_once "conexao.php";

if (!isset($_SESSION["user_id"])) {
    header("Location: index.php");
    exit;
}

$id = $_GET["id"];
$user_id = $_SESSION["user_id"];

// Verifica se o anúncio pertence ao utilizador
$sql = "SELECT * FROM veiculos WHERE id = ? AND utilizador_id = ?";
$stmt = $pdo->prepare($sql);
$stmt->execute([$id, $user_id]);
$carro = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$carro) {
    die("Acesso negado.");
}

include "includes/header.php";
?>

<div class="register-container">
    <h2>Editar Anúncio</h2>

    <form action="processa_edicao.php" method="POST" enctype="multipart/form-data" class="register-form">

    <label>Destacar anúncio por 5€ /semana (opcional)
    <input type="checkbox" name="destaque" value="1" >
   
</label>

        <input type="hidden" name="id" value="<?= $carro['id'] ?>">

        <input type="text" name="marca" value="<?= $carro['marca'] ?>" required>
        <input type="text" name="modelo" value="<?= $carro['modelo'] ?>" required>

        <input type="number" name="ano" value="<?= $carro['ano'] ?>" required>
        <input type="number" name="quilometragem" value="<?= $carro['quilometragem'] ?>" required>

        <input type="number" step="0.01" name="preco" value="<?= $carro['preco'] ?>" required>

        <select name="combustivel" required>
            <option value="gasolina" <?= $carro['combustivel']=='gasolina'?'selected':'' ?>>Gasolina</option>
            <option value="diesel" <?= $carro['combustivel']=='diesel'?'selected':'' ?>>Diesel</option>
            <option value="eletrico" <?= $carro['combustivel']=='eletrico'?'selected':'' ?>>Elétrico</option>
            <option value="hibrido" <?= $carro['combustivel']=='hibrido'?'selected':'' ?>>Híbrido</option>
        </select>

        <select name="cambio" required>
            <option value="manual" <?= $carro['cambio']=='manual'?'selected':'' ?>>Manual</option>
            <option value="automatico" <?= $carro['cambio']=='automatico'?'selected':'' ?>>Automático</option>
        </select>

        <select name="estado" required>
            <option value="novo" <?= $carro['estado']=='novo'?'selected':'' ?>>Novo</option>
            <option value="seminovo" <?= $carro['estado']=='seminovo'?'selected':'' ?>>Seminovo</option>
            <option value="usado" <?= $carro['estado']=='usado'?'selected':'' ?>>Usado</option>
        </select>

        <textarea name="descricao" rows="4"><?= $carro['descricao'] ?></textarea>

        <label>Fotos do veículo (pode trocar as fotos):</label>
        <input type="file" name="fotos[]" multiple accept="image/*">
        <input type="hidden" name="trocar_fotos" value="1">

        <button type="submit">Guardar Alterações</button>
    </form>
</div>

<?php include "includes/footer.php"; ?>
