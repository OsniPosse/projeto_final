<?php
require "conexao.php";

$id = (int)($_GET["id"] ?? 0);

// Sem id na URL: se estiver logado, mostra a própria loja (link "Área lojista" do menu)
if ($id === 0 && isset($_SESSION["user_id"])) {
    $id = (int) $_SESSION["user_id"];
}

if ($id === 0) {
    header("Location: index.php");
    exit;
}

$stmt = $pdo->prepare("SELECT * FROM utilizadores WHERE id = ? AND perfil = 'lojista'");
$stmt->execute([$id]);
$loja = $stmt->fetch(PDO::FETCH_ASSOC);

$souEuMesmo = isset($_SESSION["user_id"]) && (int)$_SESSION["user_id"] === $id;

if (!$loja) {

    include "includes/header.php";

    if ($souEuMesmo) {
        // Utilizador logado mas a conta não é (ainda) de lojista
        echo '<div class="container" style="padding:40px 20px;text-align:center;">';
        echo '<i class="ti ti-building-store" style="font-size:48px;color:var(--color-text-secondary);"></i>';
        echo '<h2 style="margin:14px 0 8px;">Ainda não tens uma loja</h2>';
        echo '<p style="color:var(--color-text-secondary);margin-bottom:18px;">A tua conta atual não está registada como lojista.</p>';
        echo '<a href="institucional.php#planos" class="btn-anunciar" style="text-decoration:none;display:inline-block;">Ver planos para lojistas</a>';
        echo '</div>';
    } else {
        echo '<div class="container" style="padding:40px 20px;text-align:center;">';
        echo '<h2>Loja não encontrada</h2>';
        echo '<a href="index.php">Voltar à página inicial</a>';
        echo '</div>';
    }

    include "includes/footer.php";
    exit;
}

$sqlVeiculos = "
    SELECT v.*, u.cidade,
           (SELECT url FROM fotos WHERE veiculo_id = v.id AND is_principal = 1 LIMIT 1) AS foto
    FROM veiculos v
    JOIN utilizadores u ON u.id = v.utilizador_id
    WHERE v.utilizador_id = ?
    ORDER BY v.criado_em DESC
";
$stmtVeiculos = $pdo->prepare($sqlVeiculos);
$stmtVeiculos->execute([$id]);
$veiculos = $stmtVeiculos->fetchAll(PDO::FETCH_ASSOC);

$planoLabels = [
    'basico'       => 'Plano Básico',
    'profissional' => 'Plano Profissional',
    'premium'      => 'Plano Premium',
];

include "includes/header.php";
?>

<main class="loja-page">

    <section class="loja-header">
        <div class="loja-logo">
            <?php if (!empty($loja["logo_loja"])): ?>
                <img src="<?= htmlspecialchars($loja["logo_loja"]) ?>" alt="Logótipo de <?= htmlspecialchars($loja["nome_loja"]) ?>">
            <?php else: ?>
                <i class="ti ti-building-store"></i>
            <?php endif; ?>
        </div>

        <div class="loja-info">
            <h1><?= htmlspecialchars($loja["nome_loja"] ?: $loja["nome"]) ?></h1>

            <div class="loja-meta">
                <?php if (!empty($loja["cidade"])): ?>
                    <span><i class="ti ti-map-pin"></i> <?= htmlspecialchars($loja["cidade"]) ?></span>
                <?php endif; ?>
                <?php if (!empty($loja["telefone"])): ?>
                    <span><i class="ti ti-phone"></i> <?= htmlspecialchars($loja["telefone"]) ?></span>
                <?php endif; ?>
                <span><i class="ti ti-car"></i> <?= count($veiculos) ?> anúncios</span>
                <?php if (!empty($loja["plano_lojista"]) && isset($planoLabels[$loja["plano_lojista"]])): ?>
                    <span class="loja-plano-badge"><i class="ti ti-star"></i> <?= $planoLabels[$loja["plano_lojista"]] ?></span>
                <?php endif; ?>
            </div>

            <?php if (!empty($loja["morada_loja"])): ?>
                <p class="loja-morada"><i class="ti ti-building"></i> <?= htmlspecialchars($loja["morada_loja"]) ?></p>
            <?php endif; ?>

            <?php if (!empty($loja["descricao_loja"])): ?>
                <p class="loja-descricao"><?= nl2br(htmlspecialchars($loja["descricao_loja"])) ?></p>
            <?php endif; ?>

            <?php if ($souEuMesmo): ?>
                <a href="editar_loja.php" class="btn-anunciar loja-editar-btn">
                    <i class="ti ti-edit"></i> Editar perfil da loja
                </a>
            <?php endif; ?>
        </div>
    </section>

    <div class="gallery">
        <div class="gallery-header">
            <span class="gallery-title">Anúncios desta loja</span>
            <span class="gallery-count"><?= count($veiculos) ?> veículos</span>
        </div>

        <div class="cars-grid">
            <?php if (empty($veiculos)): ?>
                <p class="sem-resultados">Esta loja ainda não tem anúncios publicados.</p>
            <?php else: ?>
                <?php foreach ($veiculos as $carro): ?>
                    <?php include "includes/card_veiculo.php"; ?>
                <?php endforeach; ?>
            <?php endif; ?>
        </div>
    </div>

</main>

<?php include "includes/footer.php"; ?>