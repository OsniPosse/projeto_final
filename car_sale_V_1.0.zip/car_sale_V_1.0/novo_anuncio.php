<?php
require "conexao.php";

// Só permite acesso se estiver logado
if (!isset($_SESSION["user_id"])) {
    header("Location: index.php");
    exit;
}

include "includes/header.php";
?>

<div class="register-container">
    <h2>Criar Anúncio</h2>

    <?php if (isset($_SESSION["anuncio_erro"])): ?>
        <p class="erro"><?= $_SESSION["anuncio_erro"] ?></p>
        <?php unset($_SESSION["anuncio_erro"]); ?>
    <?php endif; ?>

    <form action="processa_anuncio.php" method="POST" enctype="multipart/form-data" class="register-form">
        <label> Destacar anúncio por 5€ /semana (opcional)
    <input type="checkbox" name="destaque" value="1" >
   
</label>

        <input type="text" name="marca" placeholder="Marca" required>
        <input type="text" name="modelo" placeholder="Modelo" required>

        <input type="number" name="ano" placeholder="Ano" required>
        <input type="number" name="quilometragem" placeholder="Quilometragem" required>

        <input type="number" step="0.01" name="preco" placeholder="Preço (€)" required>

        <select name="combustivel" required>
            <option value="">Combustível</option>
            <option value="gasolina">Gasolina</option>
            <option value="diesel">Diesel</option>
            <option value="eletrico">Elétrico</option>
            <option value="hibrido">Híbrido</option>
        </select>

        <select name="cambio" required>
            <option value="">Câmbio</option>
            <option value="manual">Manual</option>
            <option value="automatico">Automático</option>
        </select>

        <select name="estado" required>
            <option value="">Estado</option>
            <option value="novo">Novo</option>
            <option value="seminovo">Seminovo</option>
            <option value="usado">Usado</option>
        </select>

        <textarea name="descricao" placeholder="Descrição do veículo" rows="6"></textarea>

        <label>Fotos do veículo (pode enviar várias):</label>
        <input type="file" name="fotos[]" multiple accept="image/*">

        <button type="submit">Publicar Anúncio</button>
    </form>
</div>

<?php include "includes/footer.php"; ?>
