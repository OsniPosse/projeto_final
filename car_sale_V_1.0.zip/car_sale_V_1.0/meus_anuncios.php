<?php
require "conexao.php";


if (!isset($_SESSION["user_id"])) {
    header("Location: index.php");
    exit;
}

$user_id = $_SESSION["user_id"];

$sql = "
    SELECT v.*, 
           (SELECT url FROM fotos WHERE veiculo_id = v.id AND is_principal = 1 LIMIT 1) AS foto
    FROM veiculos v
    WHERE v.utilizador_id = ?
    ORDER BY v.criado_em DESC
";

$stmt = $pdo->prepare($sql);
$stmt->execute([$user_id]);
$anuncios = $stmt->fetchAll(PDO::FETCH_ASSOC);

?>
<?php include "includes/header.php"; ?>

<div class="gallery" style="margin-top:20px;">
    <div class="gallery-header">
        <span class="gallery-title">Meus Anúncios</span>
        <span class="gallery-count"><?= count($anuncios) ?> anúncios</span>
    </div>

    <div class="cars-grid">
    <?php foreach ($anuncios as $carro): ?>
        
        <a href="detalhes.php?id=<?= $carro['id'] ?>" class="car-card" style="text-decoration:none;color:inherit;">

            <div class="car-img">
                <?php if ($carro["foto"]): ?>
                    <img src="<?= $carro["foto"] ?>" style="width:100%;height:100%;object-fit:cover;">
                <?php else: ?>
                    <i class="ti ti-car"></i>
                <?php endif; ?>
            </div>

            <div class="car-info">
                <div class="car-name"><?= $carro["marca"] . " " . $carro["modelo"] ?></div>
                <div class="car-specs">
                    <?= $carro["ano"] ?> · <?= number_format($carro["quilometragem"], 0, ',', '.') ?> km
                </div>
                <div class="car-price">€<?= number_format($carro["preco"], 2, ',', '.') ?></div>

                <div style="margin-top:10px; display:flex; gap:8px;">
                    <a href="editar_anuncio.php?id=<?= $carro['id'] ?>" 
                       class="btn-login" 
                       style="background:#4f7ef7;color:white;border:none;">
                       Editar
                    </a>

                    <a href="remover_anuncio.php?id=<?= $carro['id'] ?>" 
                       class="btn-login" 
                       style="background:#e63946;color:white;border:none;" 
                       onclick="return confirm('Tem certeza que deseja remover este anúncio?')">
                       Remover
                    </a>
                </div>
            </div>

        </a>

    <?php endforeach; ?>
</div>


<?php include "includes/footer.php"; ?>
