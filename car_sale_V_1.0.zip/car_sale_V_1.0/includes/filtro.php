<?php
/**
 * Constrói SQL base + condições dinâmicas a partir de $_GET
 * Retorna: ['sql' => string, 'params' => array, 'filtros' => array]
 */
function obterFiltrosVeiculos(array $get): array
{
    $filtros = [
        'estado'    => $get['estado']    ?? '',
        'preco_min' => $get['preco_min'] ?? '',
        'preco_max' => $get['preco_max'] ?? '',
        'ano_min'   => $get['ano_min']   ?? '',
        'ano_max'   => $get['ano_max']   ?? '',
        'km_max'    => $get['km_max']    ?? '',
        'cambio'    => $get['cambio']    ?? '',
        'marca'     => $get['marca']     ?? '',
        'ordenar'   => $get['ordenar']   ?? 'recentes',
        'q'         => isset($get['q']) ? trim($get['q']) : '',
    ];

    $sql = "
        SELECT v.*, u.cidade,
               (SELECT url FROM fotos WHERE veiculo_id = v.id AND is_principal = 1 LIMIT 1) AS foto
        FROM veiculos v
        JOIN utilizadores u ON u.id = v.utilizador_id
        WHERE 1=1
    ";
    $params = [];

    // Pesquisa textual (opcional — só quando há termo)
    if ($filtros['q'] !== '') {
        $sql .= " AND (
            v.marca LIKE :q OR
            v.modelo LIKE :q OR
            CONCAT(v.ano, '') LIKE :q OR
            u.cidade LIKE :q
        )";
        $params[':q'] = '%' . $filtros['q'] . '%';
    }

    // Estado
    if ($filtros['estado'] === 'novo') {
        $sql .= " AND v.estado = 'novo'";
    } elseif ($filtros['estado'] === 'usado') {
        $sql .= " AND v.estado IN ('usado', 'seminovo')";
    }

    // Marca
    if ($filtros['marca'] !== '') {
        $sql .= " AND v.marca LIKE :marca";
        $params[':marca'] = '%' . $filtros['marca'] . '%';
    }

    // Preço
    if ($filtros['preco_min'] !== '' && is_numeric($filtros['preco_min'])) {
        $sql .= " AND v.preco >= :preco_min";
        $params[':preco_min'] = $filtros['preco_min'];
    }
    if ($filtros['preco_max'] !== '' && is_numeric($filtros['preco_max'])) {
        $sql .= " AND v.preco <= :preco_max";
        $params[':preco_max'] = $filtros['preco_max'];
    }

    // Ano
    if ($filtros['ano_min'] !== '' && is_numeric($filtros['ano_min'])) {
        $sql .= " AND v.ano >= :ano_min";
        $params[':ano_min'] = $filtros['ano_min'];
    }
    if ($filtros['ano_max'] !== '' && is_numeric($filtros['ano_max'])) {
        $sql .= " AND v.ano <= :ano_max";
        $params[':ano_max'] = $filtros['ano_max'];
    }

    // Quilometragem
    if ($filtros['km_max'] !== '' && is_numeric($filtros['km_max'])) {
        $sql .= " AND v.quilometragem <= :km_max";
        $params[':km_max'] = $filtros['km_max'];
    }

    // Câmbio
    if (in_array($filtros['cambio'], ['manual', 'automatico'], true)) {
        $sql .= " AND v.cambio = :cambio";
        $params[':cambio'] = $filtros['cambio'];
    }

  
    switch ($filtros['ordenar']) {
        case 'preco_asc':
            $sql .= " ORDER BY v.preco ASC";
            break;
        case 'preco_desc':
            $sql .= " ORDER BY v.preco DESC";
            break;
        case 'ano_desc':
            $sql .= " ORDER BY v.ano DESC";
            break;
        default:
            $sql .= " ORDER BY v.criado_em DESC";
    }

    return ['sql' => $sql, 'params' => $params, 'filtros' => $filtros];
}

/** Gera URL preservando filtros ativos */
function urlComFiltros(array $filtros, array $extra = []): string
{
    $params = array_merge($filtros, $extra);
    $params = array_filter($params, fn($v) => $v !== '' && $v !== null);
    unset($params['ordenar']); // evitar duplicar se passares no extra
    if (!empty($extra['ordenar'])) {
        $params['ordenar'] = $extra['ordenar'];
    }
    return 'index.php?' . http_build_query($params);
}