<?php
/**
 * Configuração SMTP para o envio do código de verificação por email.
 *
 * Preenche com os dados da tua conta de email (Gmail, Outlook, etc.).
 *
 * GMAIL: ativa a verificação em 2 passos na tua conta Google e gera uma
 * "Password de aplicação" em https://myaccount.google.com/apppasswords
 * — usa essa password aqui, NÃO a tua password normal da conta.
 *
 * OUTLOOK/HOTMAIL: SMTP_HOST = smtp.office365.com, SMTP_PORT = 587.
 *
 * NUNCA envies este ficheiro com as credenciais reais para um repositório
 * público (GitHub, etc.). Idealmente adiciona-o ao .gitignore.
 */

return [
    'SMTP_HOST'       => 'smtp.gmail.com',
    'SMTP_PORT'       => 587,
    'SMTP_SECURE'     => 'tls',          // 'tls' (porta 587) ou 'ssl' (porta 465)
    'SMTP_USER'       => 'osniposse@gmail.com',
    'SMTP_PASS'       => 'ivfunjichpqhcaez',
    'EMAIL_FROM'      => 'osniposse@gmail.com',
    'EMAIL_FROM_NOME' => 'AutoMarket',
];
