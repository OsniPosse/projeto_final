<?php

?>
<a href="detalhes.php?id=<?= (int)$carro['id'] ?>" class="car-card">
    <div class="car-img">
        <?php if (!empty($carro['foto'])): ?>
            <img src="<?= htmlspecialchars($carro['foto']) ?>" alt="Foto do veículo">
        <?php else: ?>
            <i class="ti ti-car"></i>
        <?php endif; ?>

        <?php if ($carro['estado'] === 'novo'): ?>
            <span class="car-badge badge-novo">Novo</span>
        <?php else: ?>
            <span class="car-badge badge-used"><?= ucfirst($carro['estado']) ?></span>
        <?php endif; ?>
    </div>

    <div class="car-info">
        <div class="car-name"><?= htmlspecialchars($carro['marca'] . ' ' . $carro['modelo']) ?></div>
        <div class="car-specs">
            <?= (int)$carro['ano'] ?> ·
            <?= number_format($carro['quilometragem'], 0, ',', '.') ?> km ·
            <?= ucfirst($carro['combustivel']) ?> ·
            <?= ucfirst($carro['cambio']) ?>
        </div>
        <div class="car-price">€<?= number_format($carro['preco'], 2, ',', '.') ?></div>
        <div class="car-location">
            <i class="ti ti-map-pin"></i> <?= htmlspecialchars($carro['cidade']) ?>
        </div>
    </div>
</a>