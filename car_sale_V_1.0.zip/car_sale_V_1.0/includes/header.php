<?php require_once "conexao.php"; ?>
<!DOCTYPE html>
<html lang="pt">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>AutoMarket</title>
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/@tabler/icons-webfont@latest/tabler-icons.min.css">
    <link rel="stylesheet" href="style.css">
</head>

<body>

<nav class="navbar">

    <div  class="logo" ><a href="index.php" class="logo">AutoMarket</a></div>



    <form class="nav-search" action="buscar.php" method="GET">
        <i class="ti ti-search"></i>
        <input type="text" name="q" placeholder="Pesquisar marca, modelo, ano..." required>
    </form>

    <div class="nav-actions">

        <?php if (!isset($_SESSION["user_id"])): ?>

            <!-- BOTÃO LOGIN -->
            <button class="btn-login" onclick="document.getElementById('modalLogin').style.display='flex'">
                <i class="ti ti-user"></i> Entrar
            </button>

        <?php else: ?>

            <!-- MENU DO UTILIZADOR -->
            <div class="user-menu">
                <span class="user-name">
                    <i class="ti ti-user"></i> <?= htmlspecialchars($_SESSION["user_nome"]) ?>
                </span>

                <div class="user-dropdown">
                    <a href="meus_anuncios.php">Meus anúncios</a>
                    <a href="novo_anuncio.php">Criar anúncio</a>
                    <?php if (($_SESSION["user_perfil"] ?? '') === 'lojista'): ?>
                        <a href="lojista.php"><i class="ti ti-building-store"></i> A minha loja</a>
                    <?php else: ?>
                        <a href="institucional.php#planos"><i class="ti ti-building-store"></i> Tornar-me lojista</a>
                    <?php endif; ?>
                    <a href="logout.php" style="color:#e63946;">Sair</a>
                </div>
            </div>

        <?php endif; ?>

        <!-- BOTÃO ANUNCIAR -->
        <button class="btn-anunciar"
            onclick="<?php echo isset($_SESSION['user_id']) ? "window.location='novo_anuncio.php'" : "alert('Faça login para anunciar');"; ?>">
            <i class="ti ti-plus"></i> Anunciar
        </button>

    </div>
</nav>


<?php
// Erro de login vindo de login.php (ex: password incorreta)
$erro = $_SESSION["login_erro"] ?? "";
unset($_SESSION["login_erro"]);
?>

<!-- MODAL LOGIN -->
<div id="modalLogin" class="modal-login" <?= !empty($erro) ? "style='display:flex;'" : "" ?>>
    <div class="modal-content">
        <h3>Entrar</h3>

        <?php if (!empty($erro)) echo "<p class='erro'>" . htmlspecialchars($erro) . "</p>"; ?>

        <form method="POST" action="login.php">
            <input type="email" name="email" placeholder="Email" required>
            <input type="password" name="password" placeholder="Password" required>
            <button type="submit">Entrar</button>

            <a href="registo.php" style="font-size:13px;margin-top:10px;color:#1a1a2e;">Criar conta</a>
        </form>

        <span class="close" onclick="document.getElementById('modalLogin').style.display='none'">Fechar</span>
    </div>
</div>
