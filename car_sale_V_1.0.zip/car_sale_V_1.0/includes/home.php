<?php
require_once "conexao.php";

$sql = "SELECT 
            t.id AS top_id,
            v.id AS veiculo_id,
            v.marca,
            v.modelo,
            v.ano,
            v.quilometragem,
            v.preco,
            v.combustivel,
            v.cambio,
            f.url AS foto_principal
        FROM anuncios_top t
        JOIN veiculos v ON v.id = t.veiculo_id
        LEFT JOIN fotos f ON f.veiculo_id = v.id AND f.is_principal = 1
        WHERE t.ativo = 1
          AND t.inicio <= CURDATE()
          AND t.fim >= CURDATE()
        ORDER BY t.id DESC
        LIMIT 10";

$stmt = $pdo->prepare($sql);
$stmt->execute();
$top = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>


<!-- BANNER TOP -->
 
<div class="banner-top">
    
    <div class="banner-label"><i class="ti ti-crown"></i> Anúncios em destaque</div>
    
    <div class="banner-title">Veículos em destaque</div>
    <div class="banner-sub">Lojistas que investiram no topo — máxima visibilidade</div>

    <div class="banner-cards">

<?php if (!empty($top)): ?>
    <?php foreach ($top as $t): ?>

        <a href="detalhes.php?id=<?= (int)$t['veiculo_id'] ?>" class="top-card">

            <div class="top-card-img">
                <?php if (!empty($t["foto_principal"])): ?>
                    <img src="<?= htmlspecialchars($t['foto_principal']) ?>" style="width:100%;height:100%;object-fit:cover;">
                <?php else: ?>
                    <i class="ti ti-car"></i>
                <?php endif; ?>

                <div class="crown">TOP</div>
            </div>

            <div class="top-card-info">
                <div class="tc-name"><?= htmlspecialchars($t['marca'] . " " . $t['modelo'] . " " . $t['ano']) ?></div>
                <div class="tc-price">€<?= number_format($t['preco'], 2, ',', '.') ?></div>
                <div class="tc-detail">
                    <?= number_format($t['quilometragem'], 0, ',', '.') ?> km · 
                    <?= htmlspecialchars(ucfirst($t['combustivel'])) ?> · 
                    <?= htmlspecialchars(ucfirst($t['cambio'])) ?>
                </div>
            </div>

        </a>

    <?php endforeach; ?>
<?php else: ?>
    <p>Sem anúncios em destaque no momento.</p>
<?php endif; ?>

</div>

</div>

<!-- FILTERS -->
<?php
require_once "includes/filtro.php";

$query = obterFiltrosVeiculos($_GET);
$stmtRecentes = $pdo->prepare($query['sql']);
$stmtRecentes->execute($query['params']);
$recentes = $stmtRecentes->fetchAll(PDO::FETCH_ASSOC);

$f = $query['filtros'];

function chipClass(string $estadoAtual, string $estadoChip): string {
    return 'filter-chip' . ($estadoAtual === $estadoChip || ($estadoAtual === '' && $estadoChip === 'todos') ? ' active' : '');
}
?>
<!-- FILTER BAR -->
<form method="GET" action="index.php" class="filter-bar">
    <span class="filter-label"><i class="ti ti-filter"></i> Filtros:</span>

    <a href="index.php" class="<?= chipClass($f['estado'], 'todos') ?>">
        <i class="ti ti-list"></i> Todos
    </a>
    <a href="index.php?estado=novo" class="<?= chipClass($f['estado'], 'novo') ?>">Novos</a>
    <a href="index.php?estado=usado" class="<?= chipClass($f['estado'], 'usado') ?>">Usados</a>

    <!-- Painel expandível de filtros numéricos -->
    <div class="filter-advanced">
        <details <?= ($f['preco_max'] || $f['ano_min'] || $f['km_max'] || $f['cambio']) ? 'open' : '' ?>>
            <summary class="filter-chip"><i class="ti ti-adjustments"></i> Mais filtros</summary>
            <div class="filter-panel">
                <label>Preço máx (€)
                    <input type="number" name="preco_max" value="<?= htmlspecialchars($f['preco_max']) ?>">
                </label>
                <label>Ano mín
                    <input type="number" name="ano_min" value="<?= htmlspecialchars($f['ano_min']) ?>">
                </label>
                <label>Ano máx
                    <input type="number" name="ano_max" value="<?= htmlspecialchars($f['ano_max']) ?>">
                </label>
                <label>Km máx
                    <input type="number" name="km_max" value="<?= htmlspecialchars($f['km_max']) ?>">
                </label>
                <label>Câmbio
                    <select name="cambio">
                        <option value="">Todos</option>
                        <option value="manual" <?= $f['cambio'] === 'manual' ? 'selected' : '' ?>>Manual</option>
                        <option value="automatico" <?= $f['cambio'] === 'automatico' ? 'selected' : '' ?>>Automático</option>
                    </select>
                </label>
                <?php if ($f['estado']): ?>
                    <input type="hidden" name="estado" value="<?= htmlspecialchars($f['estado']) ?>">
                <?php endif; ?>
                <button type="submit" class="btn-filter">Aplicar</button>
            </div>
        </details>
    </div>

    <select name="ordenar" class="filter-sort" onchange="this.form.submit()">
        <option value="recentes" <?= $f['ordenar'] === 'recentes' ? 'selected' : '' ?>>Mais recentes</option>
        <option value="preco_asc" <?= $f['ordenar'] === 'preco_asc' ? 'selected' : '' ?>>Preço ↑</option>
        <option value="preco_desc" <?= $f['ordenar'] === 'preco_desc' ? 'selected' : '' ?>>Preço ↓</option>
        <option value="ano_desc" <?= $f['ordenar'] === 'ano_desc' ? 'selected' : '' ?>>Ano ↓</option>
    </select>
</form>

<!-- GALLERY -->
<div class="gallery">
    <div class="gallery-header">
        <span class="gallery-title">Anúncios recentes</span>
        <span class="gallery-count"><?= count($recentes) ?> veículos encontrados</span>
    </div>

    <div class="cars-grid">
        <?php if (empty($recentes)): ?>
            <p class="sem-resultados">Nenhum veículo encontrado com estes filtros.</p>
        <?php else: ?>
            <?php foreach ($recentes as $carro): ?>
                <?php include 'includes/card_veiculo.php'; ?>
            <?php endforeach; ?>
        <?php endif; ?>
    </div>
</div>

<!-- ÁREA DE LOJISTAS -->
<?php
$sqlLojistas = "
    SELECT u.id, u.nome_loja, u.descricao_loja, u.logo_loja, u.cidade, u.plano_lojista,
           (SELECT COUNT(*) FROM veiculos WHERE utilizador_id = u.id) AS total_anuncios
    FROM utilizadores u
    WHERE u.perfil = 'lojista' AND u.verificado = 1
    ORDER BY FIELD(u.plano_lojista, 'premium', 'profissional', 'basico'), total_anuncios DESC, u.id DESC
    LIMIT 8
";
$stmtLojistas = $pdo->query($sqlLojistas);
$lojistas = $stmtLojistas->fetchAll(PDO::FETCH_ASSOC);
?>
<div class="lojistas-section">
    <div class="lojistas-banner">

        <div class="lojistas-banner-header">
            <div>
                <div class="lojistas-label"><i class="ti ti-building-store"></i> Área de lojistas</div>
                <div class="banner-title">Lojas em destaque</div>
                <div class="banner-sub">Profissionais verificados, com anúncios atualizados todos os dias</div>
            </div>
            <a href="institucional.php#planos" class="lojistas-cta">Anuncia a tua loja aqui →</a>
        </div>

        <?php if (empty($lojistas)): ?>
            <div class="lojistas-vazio">
                <i class="ti ti-building-store"></i>
                <p>Ainda não há lojas registadas. Sê o primeiro lojista na AutoMarket.</p>
                <a href="registo.php?perfil=lojista" class="btn-anunciar">Criar conta lojista</a>
            </div>
        <?php else: ?>
            <div class="lojistas-cards">
                <?php foreach ($lojistas as $loja): ?>
                    <a href="lojista.php?id=<?= (int)$loja['id'] ?>" class="loja-card-top">
                        <div class="loja-card-avatar">
                            <?php if (!empty($loja['logo_loja'])): ?>
                                <img src="<?= htmlspecialchars($loja['logo_loja']) ?>" alt="">
                            <?php else: ?>
                                <i class="ti ti-building-store"></i>
                            <?php endif; ?>
                        </div>
                        <div class="loja-card-info">
                            <div class="loja-card-nome"><?= htmlspecialchars($loja['nome_loja']) ?></div>
                            <div class="loja-card-meta">
                                <?php if (!empty($loja['cidade'])): ?><?= htmlspecialchars($loja['cidade']) ?> · <?php endif; ?><?= (int)$loja['total_anuncios'] ?> anúncios
                            </div>
                        </div>
                        <?php if (in_array($loja['plano_lojista'], ['premium', 'profissional'], true)): ?>
                            <span class="loja-card-badge"><i class="ti ti-star"></i></span>
                        <?php endif; ?>
                    </a>
                <?php endforeach; ?>
            </div>
        <?php endif; ?>

    </div>
</div>
