<?php
/**
 * Envio de emails da plataforma (código de verificação de conta).
 * Usa o PHPMailer incluído em includes/PHPMailer/.
 */

require_once __DIR__ . "/PHPMailer/Exception.php";
require_once __DIR__ . "/PHPMailer/PHPMailer.php";
require_once __DIR__ . "/PHPMailer/SMTP.php";

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception as PHPMailerException;

/**
 * Envia o código de verificação de 6 dígitos para o email do utilizador.
 *
 * @return array{ok: bool, erro: ?string}
 */
function enviarCodigoVerificacao(string $paraEmail, string $paraNome, string $codigo): array
{
    $config = require __DIR__ . "/config_email.php";

    $mail = new PHPMailer(true);

    try {
        $mail->isSMTP();
        $mail->Host       = $config['SMTP_HOST'];
        $mail->SMTPAuth   = true;
        $mail->Username   = $config['SMTP_USER'];
        $mail->Password   = $config['SMTP_PASS'];
        $mail->SMTPSecure = $config['SMTP_SECURE'] === 'ssl'
            ? PHPMailer::ENCRYPTION_SMTPS
            : PHPMailer::ENCRYPTION_STARTTLS;
        $mail->Port       = (int) $config['SMTP_PORT'];
        $mail->CharSet    = 'UTF-8';

        $mail->setFrom($config['EMAIL_FROM'], $config['EMAIL_FROM_NOME']);
        $mail->addAddress($paraEmail, $paraNome);

        $mail->isHTML(true);
        $mail->Subject = 'O teu código de verificação — AutoMarket';
        $mail->Body    = '
            <div style="font-family:Arial,sans-serif;max-width:480px;margin:0 auto;">
                <h2 style="color:#1a1a2e;">Bem-vindo(a) à AutoMarket, ' . htmlspecialchars($paraNome) . '!</h2>
                <p>Usa o código abaixo para confirmares a tua conta. O código é válido por 15 minutos.</p>
                <div style="background:#f3f4f6;border-radius:8px;padding:18px;text-align:center;margin:20px 0;">
                    <span style="font-size:28px;font-weight:700;letter-spacing:6px;color:#1a1a2e;">' . htmlspecialchars($codigo) . '</span>
                </div>
                <p style="color:#6b7280;font-size:13px;">Se não foste tu a criar esta conta, ignora este email.</p>
            </div>
        ';
        $mail->AltBody = "O teu código de verificação AutoMarket é: $codigo (válido por 15 minutos).";

        $mail->send();
        return ['ok' => true, 'erro' => null];

    } catch (PHPMailerException $e) {
        return ['ok' => false, 'erro' => $mail->ErrorInfo];
    }
}
