<?php
require_once "conexao.php";

if (!isset($_SESSION["user_id"])) {
    header("Location: index.php");
    exit;
}

// Buscar anúncios em destaque
$sql = "SELECT 
            t.id AS top_id,
            t.inicio,
            t.fim,
            t.valor_pago,
            t.ativo,
            v.id AS veiculo_id,
            v.marca,
            v.modelo,
            v.ano,
            v.preco,
            f.url AS foto_principal
        FROM anuncios_top t
        JOIN veiculos v ON v.id = t.veiculo_id
        LEFT JOIN fotos f ON f.veiculo_id = v.id AND f.is_principal = 1
        ORDER BY t.id DESC";

$stmt = $pdo->prepare($sql);
$stmt->execute();
$anuncios = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>
