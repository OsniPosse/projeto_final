<?php
require_once "conexao.php";

$id = (int)($_GET["id"] ?? 0);

$sql = "SELECT v.*, u.nome, u.email, u.cidade, u.telefone
        FROM veiculos v
        JOIN utilizadores u ON u.id = v.utilizador_id
        WHERE v.id = ?";
$stmt = $pdo->prepare($sql);
$stmt->execute([$id]);
$carro = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$carro) {
    header("Location: index.php");
    exit;
}

$sqlFotos = "SELECT url FROM fotos WHERE veiculo_id = ? ORDER BY is_principal DESC, id ASC";
$stmtFotos = $pdo->prepare($sqlFotos);
$stmtFotos->execute([$id]);
$fotos = $stmtFotos->fetchAll(PDO::FETCH_ASSOC);

include "includes/header.php";
?>

<main class="detalhe-page">
    <a href="index.php" class="detalhe-voltar">
        <i class="ti ti-arrow-left"></i> Voltar aos anúncios
    </a>

    <div class="detalhe-grid">

        <!-- COLUNA ESQUERDA: SLIDER -->
        <section class="detalhe-galeria">
            <div class="slider" id="carSlider">
                <div class="slider-viewport">
                    <?php if (empty($fotos)): ?>
                        <div class="slider-slide active">
                            <div class="slider-placeholder">
                                <i class="ti ti-car"></i>
                                <span>Sem fotos disponíveis</span>
                            </div>
                        </div>
                    <?php else: ?>
                        <?php foreach ($fotos as $index => $f): ?>
                            <div class="slider-slide <?= $index === 0 ? 'active' : '' ?>">
                                <img src="<?= htmlspecialchars($f['url']) ?>"
                                     alt="<?= htmlspecialchars($carro['marca'] . ' ' . $carro['modelo']) ?>">
                            </div>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </div>

                <?php if (count($fotos) > 1): ?>
                    <button type="button" class="slider-btn slider-prev" aria-label="Foto anterior">
                        <i class="ti ti-chevron-left"></i>
                    </button>
                    <button type="button" class="slider-btn slider-next" aria-label="Próxima foto">
                        <i class="ti ti-chevron-right"></i>
                    </button>
                    <div class="slider-dots"></div>
                <?php endif; ?>
            </div>

            <?php if (count($fotos) > 1): ?>
                <div class="slider-thumbs">
                    <?php foreach ($fotos as $index => $f): ?>
                        <button type="button"
                                class="slider-thumb <?= $index === 0 ? 'active' : '' ?>"
                                data-index="<?= $index ?>">
                            <img src="<?= htmlspecialchars($f['url']) ?>" alt="">
                        </button>
                    <?php endforeach; ?>
                </div>
            <?php endif; ?>
        </section>

        <!-- COLUNA DIREITA: DADOS -->
        <aside class="detalhe-info">
            <div class="detalhe-badges">
                <?php if ($carro['estado'] === 'novo'): ?>
                    <span class="car-badge badge-novo">Novo</span>
                <?php else: ?>
                    <span class="car-badge badge-used"><?= ucfirst($carro['estado']) ?></span>
                <?php endif; ?>
                <span class="detalhe-id">Anúncio #<?= (int)$carro['id'] ?></span>
            </div>

            <h1 class="detalhe-titulo">
                <?= htmlspecialchars($carro['marca'] . ' ' . $carro['modelo']) ?>
            </h1>

            <p class="detalhe-subtitulo">
                <?= (int)$carro['ano'] ?> ·
                <?= number_format($carro['quilometragem'], 0, ',', '.') ?> km ·
                <?= ucfirst($carro['combustivel']) ?> ·
                <?= ucfirst($carro['cambio']) ?>
            </p>

            <div class="detalhe-preco">
                €<?= number_format($carro['preco'], 2, ',', '.') ?>
            </div>

            <div class="detalhe-specs">
                <div class="spec-item">
                    <span>Ano</span>
                    <strong><?= (int)$carro['ano'] ?></strong>
                </div>
                <div class="spec-item">
                    <span>Quilometragem</span>
                    <strong><?= number_format($carro['quilometragem'], 0, ',', '.') ?> km</strong>
                </div>
                <div class="spec-item">
                    <span>Combustível</span>
                    <strong><?= ucfirst($carro['combustivel']) ?></strong>
                </div>
                <div class="spec-item">
                    <span>Câmbio</span>
                    <strong><?= ucfirst($carro['cambio']) ?></strong>
                </div>
            </div>

            <?php if (!empty($carro['descricao'])): ?>
                <div class="detalhe-descricao">
                    <h2>Descrição</h2>
                    <p><?= nl2br(htmlspecialchars($carro['descricao'])) ?></p>
                </div>
            <?php endif; ?>

            <div class="detalhe-contacto">
                <h2>Contactar anunciante</h2>
                <p class="contacto-nome"><?= htmlspecialchars($carro['nome']) ?></p>
                <p class="contacto-local">
                    <i class="ti ti-map-pin"></i> <?= htmlspecialchars($carro['cidade']) ?>
                </p>
                <a href="mailto:<?= htmlspecialchars($carro['email']) ?>?subject=Interesse em <?= urlencode($carro['marca'] . ' ' . $carro['modelo']) ?>"
                   class="contact-button">
                    <i class="ti ti-mail"></i> Enviar email
                </a>
            </div>
        </aside>

    </div>
</main>

<script src="slider.js"></script>
<?php include "includes/footer.php"; ?>