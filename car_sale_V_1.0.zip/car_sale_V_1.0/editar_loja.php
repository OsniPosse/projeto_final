<?php
require_once "conexao.php";

if (!isset($_SESSION["user_id"])) {
    header("Location: index.php");
    exit;
}

$user_id = $_SESSION["user_id"];

$stmt = $pdo->prepare("SELECT * FROM utilizadores WHERE id = ? AND perfil = 'lojista'");
$stmt->execute([$user_id]);
$loja = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$loja) {
    header("Location: lojista.php");
    exit;
}

$erro = "";

if ($_SERVER["REQUEST_METHOD"] === "POST") {

    $nomeLoja      = trim($_POST["nome_loja"] ?? "");
    $descricaoLoja = trim($_POST["descricao_loja"] ?? "");
    $moradaLoja    = trim($_POST["morada_loja"] ?? "");
    $planoLojista  = $_POST["plano_lojista"] ?? "";
    $cidade        = trim($_POST["cidade"] ?? "");
    $telefone      = trim($_POST["telefone"] ?? "");
    $planosValidos = ["basico", "profissional", "premium"];

    if ($nomeLoja === "" || !in_array($planoLojista, $planosValidos, true)) {
        $erro = "Preenche o nome da loja e escolhe um plano.";
    } else {

        $logoLojaDestino = $loja["logo_loja"];

        if (!empty($_FILES["logo_loja"]["name"])) {
            $ext = strtolower(pathinfo($_FILES["logo_loja"]["name"], PATHINFO_EXTENSION));
            if (in_array($ext, ["jpg", "jpeg", "png"], true)) {
                if (!is_dir(__DIR__ . "/uploads/lojas")) {
                    mkdir(__DIR__ . "/uploads/lojas", 0755, true);
                }
                $novoNome = uniqid("loja_") . "." . $ext;
                if (move_uploaded_file($_FILES["logo_loja"]["tmp_name"], __DIR__ . "/uploads/lojas/" . $novoNome)) {
                    $logoLojaDestino = "uploads/lojas/" . $novoNome;
                }
            }
        }

        $sql = "UPDATE utilizadores SET
                    nome_loja = ?, descricao_loja = ?, morada_loja = ?,
                    plano_lojista = ?, logo_loja = ?, cidade = ?, telefone = ?
                WHERE id = ?";

        $pdo->prepare($sql)->execute([
            $nomeLoja, $descricaoLoja, $moradaLoja,
            $planoLojista, $logoLojaDestino, $cidade, $telefone,
            $user_id,
        ]);

        header("Location: lojista.php");
        exit;
    }
}

include "includes/header.php";
?>

<div class="register-container">
    <h2>Editar perfil da loja</h2>

    <?php if (!empty($erro)): ?>
        <p class="erro"><?= htmlspecialchars($erro) ?></p>
    <?php endif; ?>

    <form method="POST" action="editar_loja.php" enctype="multipart/form-data" class="register-form">

        <input type="text" name="nome_loja" placeholder="Nome da loja" value="<?= htmlspecialchars($loja['nome_loja'] ?? '') ?>" required>

        <textarea name="descricao_loja" placeholder="Descrição da loja" rows="4"><?= htmlspecialchars($loja['descricao_loja'] ?? '') ?></textarea>

        <input type="text" name="morada_loja" placeholder="Morada da loja" value="<?= htmlspecialchars($loja['morada_loja'] ?? '') ?>">

        <input type="text" name="cidade" placeholder="Cidade" value="<?= htmlspecialchars($loja['cidade'] ?? '') ?>">

        <input type="text" name="telefone" placeholder="Telefone" value="<?= htmlspecialchars($loja['telefone'] ?? '') ?>">

        <?php if (!empty($loja["logo_loja"])): ?>
            <div class="logo-atual">
                <img src="<?= htmlspecialchars($loja["logo_loja"]) ?>" alt="Logótipo atual">
                <span>Logótipo atual</span>
            </div>
        <?php endif; ?>

        <label class="campo-label">Trocar logótipo (opcional)
            <input type="file" name="logo_loja" accept="image/*">
        </label>

        <label class="campo-label">Plano
            <select name="plano_lojista" required>
                <option value="basico" <?= ($loja['plano_lojista'] ?? '') === 'basico' ? 'selected' : '' ?>>Básico — Grátis</option>
                <option value="profissional" <?= ($loja['plano_lojista'] ?? '') === 'profissional' ? 'selected' : '' ?>>Profissional — €19,90/mês</option>
                <option value="premium" <?= ($loja['plano_lojista'] ?? '') === 'premium' ? 'selected' : '' ?>>Premium — €39,90/mês</option>
            </select>
        </label>
        <p class="lojista-fields-nota">
            Sem pagamento neste momento. Vê os detalhes em
            <a href="institucional.php#planos" target="_blank">Planos para lojistas</a>.
        </p>

        <button type="submit">Guardar Alterações</button>
    </form>
</div>

<?php include "includes/footer.php"; ?>