<?php
require 'includes/header.php';
require 'includes/home.php';

?>
<?php if (isset($_SESSION["anuncio_sucesso"])): ?>
    <p class="sucesso"><?= $_SESSION["anuncio_sucesso"] ?></p>
    <?php unset($_SESSION["anuncio_sucesso"]); ?>
<?php endif; ?>
<?php require 'includes/institucional.php'; ?>
<?php require 'includes/footer.php'; ?>