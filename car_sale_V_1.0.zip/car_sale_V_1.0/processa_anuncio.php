<?php
require "conexao.php";

if (!isset($_SESSION["user_id"])) {
    header("Location: index.php");
    exit;
}

if ($_SERVER["REQUEST_METHOD"] === "POST") {

    $marca = $_POST["marca"];
    $modelo = $_POST["modelo"];
    $ano = $_POST["ano"];
    $km = $_POST["quilometragem"];
    $preco = $_POST["preco"];
    $combustivel = $_POST["combustivel"];
    $cambio = $_POST["cambio"];
    $estado = $_POST["estado"];
    $descricao = $_POST["descricao"];
    $user_id = $_SESSION["user_id"];

    $destaque = isset($_POST['destaque']) ? 1 : 0;


    // Inserir veículo
    
    $sql = "INSERT INTO veiculos 
            (utilizador_id, marca, modelo, ano, quilometragem, preco, combustivel, cambio, estado, descricao)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";

    $stmt = $pdo->prepare($sql);
    $stmt->execute([$user_id, $marca, $modelo, $ano, $km, $preco, $combustivel, $cambio, $estado, $descricao]);

    $veiculo_id = $pdo->lastInsertId();
    // Se o utilizador marcou destaque
if ($destaque == 1) {

    $inicio = date("Y-m-d");
    $fim = date("Y-m-d", strtotime("+30 days")); // destaque válido por 30 dias
    $valor_pago = 0.00; // ou o valor que quiseres

    $sqlTop = "INSERT INTO anuncios_top (veiculo_id, inicio, fim, valor_pago, ativo)
               VALUES (?, ?, ?, ?, 1)";

    $stmtTop = $pdo->prepare($sqlTop);
    $stmtTop->execute([$veiculo_id, $inicio, $fim, $valor_pago]);
}


    // Upload das fotos
    if (!empty($_FILES["fotos"]["name"][0])) {

        if (!is_dir(__DIR__ . "/uploads")) {
            mkdir(__DIR__ . "/uploads", 0755, true);
        }

        $total = count($_FILES["fotos"]["name"]);

        for ($i = 0; $i < $total; $i++) {

            $tmp = $_FILES["fotos"]["tmp_name"][$i];
            $nomeOriginal = $_FILES["fotos"]["name"][$i];
            $ext = strtolower(pathinfo($nomeOriginal, PATHINFO_EXTENSION));

            if (!in_array($ext, ["jpg", "jpeg", "png"])) continue;

            $novoNome = uniqid() . "." . $ext;

            $destinoServidor = __DIR__ . "/uploads/" . $novoNome;
            $destinoBD = "uploads/" . $novoNome;

            if (move_uploaded_file($tmp, $destinoServidor)) {
                $pdo->prepare("INSERT INTO fotos (veiculo_id, url, is_principal) VALUES (?, ?, ?)")
                    ->execute([$veiculo_id, $destinoBD, $i === 0 ? 1 : 0]);
            }
        }
    }

    header("Location: meus_anuncios.php");
    exit;
}
?>
