<?php
require_once "conexao.php";
require_once "includes/filtro.php";

$query = obterFiltrosVeiculos($_GET);
$stmt = $pdo->prepare($query['sql']);
$stmt->execute($query['params']);
$resultados = $stmt->fetchAll(PDO::FETCH_ASSOC);
$f = $query['filtros'];

require 'includes/header.php';
?>

<div class="container" style="padding:20px;">
    <h2>Pesquisa avançada</h2>

    <form method="GET" action="index.php" class="filter-panel">
        <div class="filter-row">
            <label>Marca <input type="text" name="marca" value="<?= htmlspecialchars($f['marca']) ?>"></label>
            <label>Estado
                <select name="estado">
                    <option value="">Todos</option>
                    <option value="novo" <?= $f['estado'] === 'novo' ? 'selected' : '' ?>>Novo</option>
                    <option value="usado" <?= $f['estado'] === 'usado' ? 'selected' : '' ?>>Usado</option>
                </select>
            </label>
            <label>Preço mín <input type="number" name="preco_min" value="<?= htmlspecialchars($f['preco_min']) ?>"></label>
            <label>Preço máx <input type="number" name="preco_max" value="<?= htmlspecialchars($f['preco_max']) ?>"></label>
            <label>Ano mín <input type="number" name="ano_min" value="<?= htmlspecialchars($f['ano_min']) ?>"></label>
            <label>Ano máx <input type="number" name="ano_max" value="<?= htmlspecialchars($f['ano_max']) ?>"></label>
            <label>Km máx <input type="number" name="km_max" value="<?= htmlspecialchars($f['km_max']) ?>"></label>
            <label>Câmbio
                <select name="cambio">
                    <option value="">Todos</option>
                    <option value="manual">Manual</option>
                    <option value="automatico">Automático</option>
                </select>
            </label>
        </div>
        <button type="submit" class="btn-filter">Pesquisar</button>
    </form>

    
</div>

<?php require 'includes/footer.php'; ?>