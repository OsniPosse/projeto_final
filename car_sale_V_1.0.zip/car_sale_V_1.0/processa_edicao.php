<?php
require "conexao.php";

if (!isset($_SESSION["user_id"])) {
    header("Location: index.php");
    exit;
}

$id = $_POST["id"];
$user_id = $_SESSION["user_id"];
// Verificar se o utilizador marcou destaque
$destaque = isset($_POST["destaque"]) ? 1 : 0;

// Verificar se já existe destaque para este veículo
$sqlCheck = "SELECT id FROM anuncios_top WHERE veiculo_id = ?";
$stmtCheck = $pdo->prepare($sqlCheck);
$stmtCheck->execute([$id]);
$existeTop = $stmtCheck->fetch(PDO::FETCH_ASSOC);

if ($destaque == 1) {

    $inicio = date("Y-m-d");
    $fim = date("Y-m-d", strtotime("+30 days"));
    $valor_pago = 0.00;

    if ($existeTop) {
        // Atualizar destaque existente
        $sqlTop = "UPDATE anuncios_top 
                   SET inicio=?, fim=?, valor_pago=?, ativo=1
                   WHERE veiculo_id=?";
        $pdo->prepare($sqlTop)->execute([$inicio, $fim, $valor_pago, $id]);

    } else {
        // Criar novo destaque
        $sqlTop = "INSERT INTO anuncios_top (veiculo_id, inicio, fim, valor_pago, ativo)
                   VALUES (?, ?, ?, ?, 1)";
        $pdo->prepare($sqlTop)->execute([$id, $inicio, $fim, $valor_pago]);
    }

} else if ($existeTop) {
    // Desativar destaque
    $sqlTop = "UPDATE anuncios_top SET ativo = 0 WHERE veiculo_id = ?";
    $pdo->prepare($sqlTop)->execute([$id]);
}




// Atualizar dados

$sql = "UPDATE veiculos SET 
            marca=?, modelo=?, ano=?, quilometragem=?, preco=?, combustivel=?, cambio=?, estado=?, descricao=?
        WHERE id=? AND utilizador_id=?";

$stmt = $pdo->prepare($sql);
$stmt->execute([
    $_POST["marca"], $_POST["modelo"], $_POST["ano"], $_POST["quilometragem"],
    $_POST["preco"], $_POST["combustivel"], $_POST["cambio"], $_POST["estado"],
    $_POST["descricao"], $id, $user_id
]);



// ADICIONAR NOVAS FOTOS
if (!empty($_FILES["novas_fotos"]["name"][0])) {

    if (!is_dir(__DIR__ . "/uploads")) {
        mkdir(__DIR__ . "/uploads", 0755, true);
    }

    $total = count($_FILES["novas_fotos"]["name"]);

    for ($i = 0; $i < $total; $i++) {

        $tmp = $_FILES["novas_fotos"]["tmp_name"][$i];
        $nomeOriginal = $_FILES["novas_fotos"]["name"][$i];
        $ext = strtolower(pathinfo($nomeOriginal, PATHINFO_EXTENSION));

        if (!in_array($ext, ["jpg", "jpeg", "png"])) continue;

        $novoNome = uniqid() . "." . $ext;

        $destinoServidor = __DIR__ . "/uploads/" . $novoNome;
        $destinoBD = "uploads/" . $novoNome;

        if (move_uploaded_file($tmp, $destinoServidor)) {
            $pdo->prepare("INSERT INTO fotos (veiculo_id, url, is_principal) VALUES (?, ?, 0)")
                ->execute([$id, $destinoBD]);
        }
    }
}

header("Location: meus_anuncios.php");
exit;
?>

