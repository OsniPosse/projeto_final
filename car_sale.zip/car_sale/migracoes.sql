-- Executa este script só se já tiveres a base de dados `car_sale_v1.sql`
-- criada anteriormente (sem as colunas/tabela abaixo). Quem importar o
-- car_sale_v1.sql atualizado do zero não precisa de correr isto.

-- Login com Google
ALTER TABLE `utilizadores`
    ADD COLUMN `google_id` VARCHAR(255) DEFAULT NULL AFTER `plano_lojista`;

-- Divulgação externa (Standvirtual / OLX)
ALTER TABLE `utilizadores`
    ADD COLUMN `standvirtual_stand_id` VARCHAR(100) DEFAULT NULL AFTER `google_id`,
    ADD COLUMN `standvirtual_api_token` VARCHAR(255) DEFAULT NULL AFTER `standvirtual_stand_id`;

CREATE TABLE `publicacoes_externas` (
  `id` INT(11) NOT NULL AUTO_INCREMENT,
  `veiculo_id` INT(11) NOT NULL,
  `plataforma` ENUM('standvirtual','olx') NOT NULL,
  `estado` ENUM('pendente_pagamento','pago','publicado','falhou','removido') NOT NULL DEFAULT 'pendente_pagamento',
  `valor_cents` INT(11) NOT NULL DEFAULT 0,
  `referencia_externa` VARCHAR(150) DEFAULT NULL,
  `mensagem_erro` VARCHAR(500) DEFAULT NULL,
  `criado_em` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP(),
  `atualizado_em` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP() ON UPDATE CURRENT_TIMESTAMP(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_veiculo_plataforma` (`veiculo_id`,`plataforma`),
  CONSTRAINT `fk_publicacoes_veiculo` FOREIGN KEY (`veiculo_id`) REFERENCES `veiculos` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Categorias (carro/mota/pesado) + distrito + campos específicos
ALTER TABLE `veiculos`
    ADD COLUMN `tipo_veiculo` ENUM('carro','mota','pesado') NOT NULL DEFAULT 'carro' AFTER `utilizador_id`,
    ADD COLUMN `distrito` VARCHAR(60) DEFAULT NULL AFTER `estado`,
    ADD COLUMN `cilindrada` SMALLINT(5) UNSIGNED DEFAULT NULL AFTER `distrito`,
    ADD COLUMN `capacidade_carga_kg` INT(10) UNSIGNED DEFAULT NULL AFTER `cilindrada`,
    ADD COLUMN `numero_eixos` TINYINT(3) UNSIGNED DEFAULT NULL AFTER `capacidade_carga_kg`,
    MODIFY COLUMN `combustivel` ENUM('gasolina','diesel','eletrico','hibrido','gpl') NOT NULL;
