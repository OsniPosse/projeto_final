<?php
require_once __DIR__ . '/../config/bootstrap.php';
require_once BASE_PATH . '/includes/verificacao.php';

$erro = "";

// Permite pré-selecionar o perfil lojista vindo de institucional.php#planos
$perfilPreSelecionado = $_GET["perfil"] ?? "";

if ($_SERVER["REQUEST_METHOD"] === "POST") {

    $nome     = trim($_POST["nome"] ?? "");
    $email    = trim($_POST["email"] ?? "");
    $password = $_POST["password"] ?? "";
    $perfil   = $_POST["perfil"] ?? "";
    $cidade   = trim($_POST["cidade"] ?? "");
    $telefone = trim($_POST["telefone"] ?? "");

    $perfisValidos = ["comprador", "anunciante", "lojista"];

    // Campos extra só relevantes para lojista
    $nomeLoja      = trim($_POST["nome_loja"] ?? "");
    $descricaoLoja = trim($_POST["descricao_loja"] ?? "");
    $moradaLoja    = trim($_POST["morada_loja"] ?? "");
    $planoLojista  = $_POST["plano_lojista"] ?? "";
    $planosValidos = ["basico", "profissional", "premium"];

    if ($nome === "" || $email === "" || $password === "" || !in_array($perfil, $perfisValidos, true)) {
        $erro = "Preenche todos os campos obrigatórios.";
    } elseif ($perfil === "lojista" && $nomeLoja === "") {
        $erro = "Indica o nome da tua loja.";
    } elseif ($perfil === "lojista" && !in_array($planoLojista, $planosValidos, true)) {
        $erro = "Escolhe um plano para a tua loja.";
    } else {

        // 1. Verificar email duplicado
        $sql = "SELECT id FROM utilizadores WHERE email = ?";
        $stmt = $pdo->prepare($sql);
        $stmt->execute([$email]);

        if ($stmt->rowCount() > 0) {
            $erro = "Este email já está registado.";
        } else {

            // 2. Logo da loja (opcional)
            $logoLojaDestino = null;
            if ($perfil === "lojista" && !empty($_FILES["logo_loja"]["name"])) {
                $ext = strtolower(pathinfo($_FILES["logo_loja"]["name"], PATHINFO_EXTENSION));
                if (in_array($ext, ["jpg", "jpeg", "png"], true)) {
                    if (!is_dir(BASE_PATH . "/uploads/lojas")) {
                        mkdir(BASE_PATH . "/uploads/lojas", 0755, true);
                    }
                    $novoNome = uniqid("loja_") . "." . $ext;
                    if (move_uploaded_file($_FILES["logo_loja"]["tmp_name"], BASE_PATH . "/uploads/lojas/" . $novoNome)) {
                        $logoLojaDestino = "uploads/lojas/" . $novoNome;
                    }
                }
            }

            // 3. Criar hash seguro da password
            $hash = password_hash($password, PASSWORD_DEFAULT);

            // 4. Gerar código de verificação (conta começa por "não verificada")
            $codigo = gerarCodigoVerificacao();
            $expira = date("Y-m-d H:i:s", strtotime("+15 minutes"));

            // 5. Inserir utilizador
            $sql = "INSERT INTO utilizadores
                        (nome, email, password, perfil, telefone, cidade,
                         verificado, codigo_verificacao, codigo_expira,
                         nome_loja, descricao_loja, logo_loja, morada_loja, plano_lojista)
                    VALUES (?, ?, ?, ?, ?, ?, 0, ?, ?, ?, ?, ?, ?, ?)";

            $stmt = $pdo->prepare($sql);
            $ok = $stmt->execute([
                $nome, $email, $hash, $perfil, $telefone, $cidade,
                $codigo, $expira,
                $perfil === "lojista" ? $nomeLoja : null,
                $perfil === "lojista" ? $descricaoLoja : null,
                $logoLojaDestino,
                $perfil === "lojista" ? $moradaLoja : null,
                $perfil === "lojista" ? $planoLojista : null,
            ]);

            if ($ok) {
                // 6. Enviar email com o código (não bloqueia a conta criada se falhar)
                $envio = enviarCodigoVerificacao($email, $nome, $codigo);

                $_SESSION["verificar_email"] = $email;
                if (!$envio["ok"]) {
                    $_SESSION["verificar_aviso"] =
                        "A conta foi criada, mas não conseguimos enviar o email automaticamente. " .
                        "Usa o botão \"Reenviar código\" nesta página para tentar de novo.";
                }

                header("Location: " . BASE_URL . "/auth/verificar_email.php");
                exit;
            } else {
                $erro = "Erro ao criar conta. Tente novamente.";
            }
        }
    }
}
?>

<?php include BASE_PATH . '/includes/header.php'; ?>

<div class="register-container register-container-wide">
    <h2>Criar Conta</h2>

    <a href="<?= BASE_URL ?>/auth/google_login.php" class="btn-google">
        <i class="ti ti-brand-google"></i> Criar conta com Google
    </a>
    <div class="login-separador"><span>ou preenche os teus dados</span></div>

    <?php if (!empty($erro)): ?>
        <p class="erro"><?= htmlspecialchars($erro) ?></p>
    <?php endif; ?>

    <form method="POST" action="<?= BASE_URL ?>/auth/registo.php" enctype="multipart/form-data" class="register-form" id="formRegisto">

        <input type="text" name="nome" placeholder="Nome completo" value="<?= htmlspecialchars($_POST['nome'] ?? '') ?>" required>

        <input type="email" name="email" placeholder="Email" value="<?= htmlspecialchars($_POST['email'] ?? '') ?>" required>

        <input type="password" name="password" placeholder="Password" required>

        <select name="perfil" id="perfilSelect" required>
            <option value="">Selecione o tipo de conta</option>
            <option value="comprador" <?= $perfilPreSelecionado === 'comprador' ? 'selected' : '' ?>>Comprador</option>
            <option value="anunciante" <?= $perfilPreSelecionado === 'anunciante' ? 'selected' : '' ?>>Anunciante</option>
            <option value="lojista" <?= $perfilPreSelecionado === 'lojista' ? 'selected' : '' ?>>Lojista (tenho um stand/loja)</option>
        </select>

        <input type="text" name="cidade" placeholder="Cidade" value="<?= htmlspecialchars($_POST['cidade'] ?? '') ?>">

        <input type="text" name="telefone" placeholder="Telefone" value="<?= htmlspecialchars($_POST['telefone'] ?? '') ?>">

        <!-- Campos extra, só visíveis quando perfil = lojista -->
        <div id="camposLojista" class="lojista-fields" style="display:none;">

            <div class="lojista-fields-title">
                <i class="ti ti-building-store"></i> Dados da tua loja
            </div>

            <input type="text" name="nome_loja" placeholder="Nome da loja / stand" value="<?= htmlspecialchars($_POST['nome_loja'] ?? '') ?>">

            <textarea name="descricao_loja" placeholder="Breve descrição da loja (especialidade, anos de experiência, etc.)" rows="3"><?= htmlspecialchars($_POST['descricao_loja'] ?? '') ?></textarea>

            <input type="text" name="morada_loja" placeholder="Morada da loja" value="<?= htmlspecialchars($_POST['morada_loja'] ?? '') ?>">

            <label class="campo-label">Logótipo da loja (opcional)
                <input type="file" name="logo_loja" accept="image/*">
            </label>

            <label class="campo-label">Plano
                <select name="plano_lojista" id="planoSelect">
                    <option value="basico" <?= ($_POST['plano_lojista'] ?? '') === 'basico' ? 'selected' : '' ?>>Básico — Grátis</option>
                    <option value="profissional" <?= ($_POST['plano_lojista'] ?? '') === 'profissional' ? 'selected' : '' ?>>Profissional — €19,90/mês</option>
                    <option value="premium" <?= ($_POST['plano_lojista'] ?? '') === 'premium' ? 'selected' : '' ?>>Premium — €39,90/mês</option>
                </select>
            </label>
            <p class="lojista-fields-nota">
                Sem pagamento neste momento — apenas escolhes o plano pretendido.
                Vê os detalhes em <a href="<?= BASE_URL ?>/index.php#planos" target="_blank">Planos para lojistas</a>.
            </p>
        </div>

        <button type="submit">Criar Conta</button>
    </form>
</div>

<script>
(function () {
    const select = document.getElementById('perfilSelect');
    const campos = document.getElementById('camposLojista');

    function atualizar() {
        const ehLojista = select.value === 'lojista';
        campos.style.display = ehLojista ? 'block' : 'none';

        // required dinâmico só quando visível, para não bloquear outros perfis
        document.querySelector('[name="nome_loja"]').required = ehLojista;
    }

    select.addEventListener('change', atualizar);
    atualizar();
})();
</script>

<?php include BASE_PATH . '/includes/footer.php'; ?>
