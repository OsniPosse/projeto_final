<?php
require_once __DIR__ . '/../config/bootstrap.php';

if ($_SERVER["REQUEST_METHOD"] === "POST") {

    $email = trim($_POST["email"]);
    $password = $_POST["password"];

    $sql = "SELECT * FROM utilizadores WHERE email = ?";
    $stmt = $pdo->prepare($sql);
    $stmt->execute([$email]);
    $user = $stmt->fetch(PDO::FETCH_ASSOC);

    if ($user && $user["password"] && password_verify($password, $user["password"])) {
         if ((int)$user["verificado"] !== 1) {
            $_SESSION["verificar_email"] = $email;
            header("Location: " . BASE_URL . "/auth/verificar_email.php");
            exit;
        }

        iniciarSessaoUtilizador($user);

        header("Location: " . BASE_URL . "/index.php");
        exit;

    } else {

        $_SESSION["login_erro"] = "Email ou password incorretos";
        header("Location: " . BASE_URL . "/index.php");
        exit;

    }
}
?>
