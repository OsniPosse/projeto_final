<!DOCTYPE html>
<html lang="pt">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>AutoMarket</title>
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/@tabler/icons-webfont@latest/tabler-icons.min.css">
    <link rel="stylesheet" href="<?= BASE_URL ?>/style.css">
</head>

<body>

<nav class="navbar">

    <div  class="logo" ><a href="<?= BASE_URL ?>/index.php" class="logo">CarroAI
    </a></div>

    <div class="nav-categorias">
        <a href="<?= BASE_URL ?>/index.php?tipo=carro">Carros</a>
        <a href="<?= BASE_URL ?>/index.php?tipo=mota">Motas</a>
        <a href="<?= BASE_URL ?>/index.php?tipo=pesado">Pesados</a>
        <a href="<?= BASE_URL ?>/index.php#stands">Stands</a>
    </div>

    <form class="nav-search" action="<?= BASE_URL ?>/buscar.php" method="GET">
        <i class="ti ti-search"></i>
        <input type="text" name="q" placeholder="Pesquisar marca, modelo, ano..." required>
    </form>

    <div class="nav-actions">

        <?php if (!estaLogado()): ?>

            <!-- BOTÃO LOGIN -->
            <button class="btn-login" onclick="document.getElementById('modalLogin').style.display='flex'">
                <i class="ti ti-user"></i> Entrar
            </button>

        <?php else: ?>

            <!-- MENU DO UTILIZADOR -->
            <div class="user-menu">
                <span class="user-name">
                    <i class="ti ti-user"></i> <?= htmlspecialchars($_SESSION["user_nome"]) ?>
                </span>

                <div class="user-dropdown">
                    <a href="<?= BASE_URL ?>/anuncios/meus_anuncios.php">Meus anúncios</a>
                    <a href="<?= BASE_URL ?>/anuncios/novo_anuncio.php">Criar anúncio</a>
                    <a href="<?= BASE_URL ?>/anuncios/favoritos.php">Meus favoritos</a>
                    <?php if (($_SESSION["user_perfil"] ?? '') === 'lojista'): ?>
                        <a href="<?= BASE_URL ?>/loja/lojista.php"><i class="ti ti-building-store"></i> Meu Stand</a>
                    <?php else: ?>
                        <a href="<?= BASE_URL ?>/index.php#planos"><i class="ti ti-building-store"></i> Criar Stand</a>
                    <?php endif; ?>
                    <a href="<?= BASE_URL ?>/auth/logout.php" style="color:#e63946;">Sair</a>
                </div>
            </div>

        <?php endif; ?>

        <!-- BOTÃO ANUNCIAR -->
        <button class="btn-anunciar"
            onclick="<?php echo estaLogado() ? "window.location='" . BASE_URL . "/anuncios/novo_anuncio.php'" : "alert('Faça login para anunciar');"; ?>">
            <i class="ti ti-plus"></i> Anunciar Grátis
        </button>

    </div>
</nav>


<?php
// Erro de login vindo de login.php (ex: password incorreta)
$erro = $_SESSION["login_erro"] ?? "";
unset($_SESSION["login_erro"]);

// Aviso a pedir login, vindo do auth_guard (exigirLogin())
$avisoLoginNecessario = isset($_GET["login_necessario"]);
?>

<!-- MODAL LOGIN -->
<div id="modalLogin" class="modal-login" <?= (!empty($erro) || $avisoLoginNecessario) ? "style='display:flex;'" : "" ?>>
    <div class="modal-content">
        <h3>Entrar</h3>

        <?php if (!empty($erro)) echo "<p class='erro'>" . htmlspecialchars($erro) . "</p>"; ?>
        <?php if ($avisoLoginNecessario): ?>
            <p class="erro">Precisas de entrar para continuares.</p>
        <?php endif; ?>

        <a href="<?= BASE_URL ?>/auth/google_login.php" class="btn-google">
            <i class="ti ti-brand-google"></i> Continuar com Google
        </a>

        <div class="login-separador"><span>ou</span></div>

        <form method="POST" action="<?= BASE_URL ?>/auth/login.php">
            <input type="email" name="email" placeholder="Email" required>
            <input type="password" name="password" placeholder="Password" required>
            <button type="submit">Entrar</button>

            <a href="<?= BASE_URL ?>/auth/registo.php" style="font-size:13px;margin-top:10px;color:#1a1a2e;">Criar conta</a>
        </form>

        <span class="close" onclick="document.getElementById('modalLogin').style.display='none'">Fechar</span>
    </div>
</div>
