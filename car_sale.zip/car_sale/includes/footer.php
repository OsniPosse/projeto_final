<footer class="footer">
    <div class="footer-cols">
        <div>
            <div>
                <a href="<?= BASE_URL ?>/index.php" class="footer-link">AutoMarket</a>
            </div>
            <a href="<?= BASE_URL ?>/index.php#sobre" class="footer-link">Sobre nós</a>
            <a href="<?= BASE_URL ?>/index.php#como-funciona" class="footer-link">Como funciona</a>
            <a href="<?= BASE_URL ?>/index.php#planos" class="footer-link">Planos para lojistas</a>
        </div>

        <div>
            <a href="<?= BASE_URL ?>/index.php?estado=novo" class="footer-link">Carros novos</a>
            <a href="<?= BASE_URL ?>/index.php?estado=usado" class="footer-link">Carros usados</a>
            <a href="<?= BASE_URL ?>/filtro.php" class="footer-link">Pesquisa avançada</a>
        </div>

        <div>
            <a href="<?= BASE_URL ?>/anuncios/novo_anuncio.php" class="footer-link">Criar anúncio</a>
            <a href="<?= BASE_URL ?>/loja/lojista.php" class="footer-link">Área do lojista</a>
        </div>
    </div>

    <div class="footer-bottom">
        <span class="footer-copy">© 2025 AutoMarket. Todos os direitos reservados.</span>
        <div class="footer-socials">
            <i class="ti ti-brand-instagram"></i>
            <i class="ti ti-brand-facebook"></i>
            <i class="ti ti-brand-linkedin"></i>
        </div>
    </div>
</footer>

</body>
</html>
