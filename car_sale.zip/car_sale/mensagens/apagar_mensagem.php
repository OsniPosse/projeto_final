<?php
require_once __DIR__ . '/../config/bootstrap.php';

if (!isset($_SESSION["user_id"])) {
    header("Location: index.php");
    exit;
}

$id = (int)($_POST["id"] ?? 0);
$user_id = $_SESSION["user_id"];

// Só o destinatário pode apagar a mensagem
$sql = "DELETE FROM mensagens
        WHERE id = ?
        AND destinatario_id = ?";

$stmt = $pdo->prepare($sql);
$stmt->execute([$id, $user_id]);

header("Location: meus_anuncios.php");
exit;