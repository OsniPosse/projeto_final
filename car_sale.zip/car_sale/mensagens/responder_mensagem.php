<?php
require_once __DIR__ . '/../config/bootstrap.php';

session_start();

if (!isset($_SESSION["user_id"])) {
    header("Location: index.php");
    exit;
}

$remetente_id = $_SESSION["user_id"];
$destinatario_id = $_POST["destinatario_id"];
$veiculo_id = $_POST["veiculo_id"];
$mensagem = trim($_POST["mensagem"]);

if ($mensagem === "") {
    die("Mensagem vazia.");
}

$sql = "
    INSERT INTO mensagens (remetente_id, destinatario_id, veiculo_id, mensagem, criada_em)
    VALUES (?, ?, ?, ?, NOW())
";

$stmt = $pdo->prepare($sql);
$stmt->execute([$remetente_id, $destinatario_id, $veiculo_id, $mensagem]);

header("Location: meus_anuncios.php?resposta=ok");
exit;
