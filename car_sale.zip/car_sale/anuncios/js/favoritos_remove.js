document.addEventListener("DOMContentLoaded", () => {
    const buttons = document.querySelectorAll(".fav-remove-btn");

    buttons.forEach(btn => {
        btn.addEventListener("click", async () => {
            const id = btn.dataset.id;

            const formData = new FormData();
            formData.append("veiculo_id", id);

            const req = await fetch("anuncios/api/favoritos_remove.php", {
                method: "POST",
                body: formData
            });

            const res = await req.json();

            if (res.status === "ok") {
                btn.closest(".car-card").remove();

                // se não restarem favoritos, mostrar mensagem
                if (document.querySelectorAll(".car-card").length === 0) {
                    document.querySelector(".cars-grid").innerHTML =
                        `<div class="no-favs">
                            <i class="ti ti-heart-off"></i>
                            <p>Não tem veículos favoritos.</p>
                            <a href="index.php" class="btn-voltar">Ver anúncios</a>
                        </div>`;
                }
            } else {
                alert(res.msg);
            }
        });
    });
});
