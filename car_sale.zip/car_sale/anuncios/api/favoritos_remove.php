<?php
session_start();
header("Content-Type: application/json");

require_once __DIR__ . '/../config/bootstrap.php';

if (!isset($_SESSION["user_id"])) {
    echo json_encode(["status" => "error", "msg" => "Precisa fazer login"]);
    exit;
}

$utilizador_id = $_SESSION["user_id"];
$veiculo_id = (int)($_POST["veiculo_id"] ?? 0);

if ($veiculo_id <= 0) {
    echo json_encode(["status" => "error", "msg" => "Veículo inválido"]);
    exit;
}

$sqlDelete = "DELETE FROM favoritos WHERE utilizador_id = ? AND veiculo_id = ?";
$stmt = $pdo->prepare($sqlDelete);
$stmt->execute([$utilizador_id, $veiculo_id]);

echo json_encode(["status" => "ok", "msg" => "Removido dos favoritos"]);
exit;
